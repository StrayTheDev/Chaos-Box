# Spamton_NEO created via BDEngine

execute as @e[tag=spamton_neo_root,type=block_display] at @s run tag @s remove animation_pause
execute as @e[tag=spamton_neo_root,type=block_display] at @s run tag @s remove animation_loop
execute as @e[tag=spamton_neo_root,type=block_display] at @s run function spamton_neo:k/pipis_popper/keyframe_0
function spamton_neo:a_s/pipis/play_sound