execute store result score random tmp run random value 1..100
execute store result score random2 tmp run random value 1..100
execute store result score random3 tmp run random value 1..100



execute if score random2 tmp matches 1..90 at @r[team=pvp] facing 0 ~ 0 run tp @e[tag=Boss-Base] ^ ^ ^10
execute if score random2 tmp matches 30..70 at @n[tag=Boss-Base] positioned ~ ~3 ~ run function spamton_neo:model/projectiles/bullet
execute if score random2 tmp matches 30..40 at @n[tag=Boss-Base] positioned ~ ~3 ~ run function spamton_neo:model/projectiles/bullet
execute if score random2 tmp matches 30..40 at @n[tag=Boss-Base] positioned ~ ~3 ~ run function spamton_neo:model/projectiles/bullet
execute if score random2 tmp matches 30..40 at @n[tag=Boss-Base] positioned ~ ~3 ~ run function spamton_neo:model/projectiles/bullet
execute if score random2 tmp matches 30..40 at @n[tag=Boss-Base] positioned ~ ~3 ~ run function spamton_neo:model/projectiles/bullet
execute if score random2 tmp matches 40..60 at @n[tag=Boss-Base] positioned ~ ~3 ~ run function spamton_neo:model/projectiles/mini

execute if score random tmp matches 1..60 run function spamton_neo:a/ambient/play_anim
execute if score random tmp matches 61..75 run function spamton_neo:a/pipis_popper/play_anim
execute if score random tmp matches 76..88 run function spamton_neo:a/flying_heads/play_anim
execute if score random tmp matches 89..100 run function spamton_neo:a/laser/play_anim

execute as @e[tag=Boss] run data merge entity @s {teleport_duration:10}
execute as @e[tag=Boss] run rotate @s ~ 0

execute if score random3 tmp matches 1..5 run tellraw @a [{text:"Spamton ",color:light_purple},{text:"NEO",color:gold},{text:": Now's your chance to be a [BIG SHOT]! ",color:white}]
execute if score random3 tmp matches 6..10 run tellraw @a [{text:"Spamton ",color:light_purple},{text:"NEO",color:gold},{text:": i think he's coming for me, answer the phone...",color:white}]
execute if score random3 tmp matches 10..15 run tellraw @a [{text:"Spamton ",color:light_purple},{text:"NEO",color:gold},{text:": We'll turn [Shmoes and Daves] into [Rosen Graves]",color:white}]
execute if score random3 tmp matches 16..20 run tellraw @a [{text:"Spamton ",color:light_purple},{text:"NEO",color:gold},{text:": Mike...",color:white}]
execute if score random3 tmp matches 99..100 run tellraw @a [{text:"Spamton ",color:light_purple},{text:"NEO",color:gold},{text:": BEHOLD: MY [special attack]! spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton spam a ton",color:white}]