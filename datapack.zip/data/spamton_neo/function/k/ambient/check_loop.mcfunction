# Spamton_NEO created via BDEngine

execute as @e[tag=spamton_neo_root,type=block_display] if entity @s[tag=animation_loop] at @s run function spamton_neo:k/ambient/keyframe_0