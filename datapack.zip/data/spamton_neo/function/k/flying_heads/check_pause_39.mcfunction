# Spamton_NEO created via BDEngine

execute as @e[tag=spamton_neo_root,type=block_display] unless entity @s[tag=animation_pause] at @s run function spamton_neo:k/flying_heads/keyframe_40