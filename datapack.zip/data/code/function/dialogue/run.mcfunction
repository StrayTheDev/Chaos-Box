$tellraw @a[distance=..5] ["<",{"text": "$(name)","color":"$(color)"},">",{"text":" $(text)"}]
$playsound minecraft:$(sound)