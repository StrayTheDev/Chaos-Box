execute store result score .global tmp run data get entity @n[type=marker] data.line
scoreboard players add .global tmp 1
execute store result entity @n[type=marker] data.line int 1.0 run scoreboard players get .global tmp
$execute if data entity @n[type=marker] data.random store result entity @n[type=marker] data.line int 1.0 run random value 0..$(linecount)
$data modify entity @n[type=marker] data.text set from entity @n[type=marker] data.lines[$(line)]
$execute unless data entity @n[type=marker] data.lines[$(line)] run data merge entity @n[type=marker] {data:{line:0}}
scoreboard players set @n[type=marker] timer 100
