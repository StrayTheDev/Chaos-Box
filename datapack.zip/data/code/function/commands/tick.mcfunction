scoreboard players add @a spawnCooldown 1

execute as @a store result score @s dummyX run data get entity @s Motion[0] 50000
execute as @a store result score @s dummyY run data get entity @s Motion[1] 50000
execute as @a store result score @s dummyZ run data get entity @s Motion[2] 50000

execute as @a run scoreboard players set @s dummy 0
execute as @a run scoreboard players operation @s dummy += @s dummyX
execute as @a run scoreboard players operation @s dummy += @s dummyY
execute as @a run scoreboard players operation @s dummy += @s dummyZ
execute as @a run scoreboard players add @s dummy 7841

execute as @a if predicate code:still run scoreboard players add @s cooldownTime 1
execute as @a unless predicate code:still run scoreboard players set @s cooldownTime 0


tp @a[scores={spawn=1..,cooldownTime=10..}] 0 4 -44 0 0
team join spawn @a[scores={spawn=1..,cooldownTime=10..}]
execute as @a[scores={spawn=1..,cooldownTime=10..}] at @s run playsound entity.enderman.teleport master @s ~ ~ ~
tellraw @a[scores={spawn=1..,cooldownTime=..10}] ["",{"text":"[","color":"gold"},{"text":"invalid request","color":"red"},{"text":"] ","color":"gold"},{"text":"you need to stand still!","color":"dark_red"}]

scoreboard players set @a[scores={spawn=1..,cooldownTime=10..}] spawnCooldown 0
scoreboard players set @a spawn 0



execute as @a[scores={rckrll=1..}] run function give_up:play
scoreboard players set @a rckrll 0

execute as @a[scores={echest=1..}] run inventory @s enderchest
scoreboard players set @a[scores={echest=1..}] echest 0

execute as @a[scores={communitychest=1..}] run inventory @s block 60 8 -51
scoreboard players set @a[scores={communitychest=1..}] communitychest 0

execute as @a[scores={crafting=1..}] run inventory @s block 60 7 -51
scoreboard players set @a[scores={crafting=1..}] crafting 0

execute as @a[scores={.menu=1..}] run dialog show @s code:menu
scoreboard players set @a .menu 0

scoreboard players enable @a .menu
scoreboard players enable @a communitychest
scoreboard players enable @a echest
scoreboard players enable @a crafting
scoreboard players enable @a rckrll
scoreboard players enable @a spawn

 
