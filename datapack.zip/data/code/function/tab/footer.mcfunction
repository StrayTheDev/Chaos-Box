execute if score footer tab matches 0 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Don't die.
execute if score footer tab matches 1 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Build farms in the Sandbox!
execute if score footer tab matches 2 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Soda's bad for you
execute if score footer tab matches 3 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Use imposter's knife on Spamton
execute if score footer tab matches 4 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Buy CHAOS BOX™ at CHAOS Co.
execute if score footer tab matches 5 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Free saturation at the Sauna!
execute if score footer tab matches 6 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>you should /vote (please)
execute if score footer tab matches 7 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Don't go down the hallway.
execute if score footer tab matches 8 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>We have a Discord!
execute if score footer tab matches 9 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Press THE BUTTON in the lobby
execute if score footer tab matches 10 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Survive disasters to earn ⓒ
execute if score footer tab matches 11 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Turn off weather sounds
execute if score footer tab matches 12 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Buy at the Mall!
execute if score footer tab matches 13 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Underground is a great place to be
execute if score footer tab matches 15 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>The Bees can't get you in water.
execute if score footer tab matches 16 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Actual tutorial coming soon™
execute if score footer tab matches 17 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>RELEASE THE BEES
execute if score footer tab matches 18 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Also try Battle Train
execute if score footer tab matches 19 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>try /trigger rckrll
execute if score footer tab matches 20 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>The Code is Load
execute if score footer tab matches 21 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Chaos Box has no lag (real)
execute if score footer tab matches 22 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Hypixel copied Chaos Box
execute if score footer tab matches 23 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>antidisestablishmentarianism
execute if score footer tab matches 24 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Now's your chance to be a [BIG SHOT]!
execute if score footer tab matches 25 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>the Sidequest house is useless
execute if score footer tab matches 26 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>have some kelp
execute if score footer tab matches 27 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>minecraft but natural disasters
execute if score footer tab matches 28 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>🕈☟✡ 👎✋👎 ✡⚐🕆 ❄☼✌☠💧☹✌❄☜ ❄☟✋💧
execute if score footer tab matches 29 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>We don't talk about the great purge
execute if score footer tab matches 30 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>hey you. yeah you. vote now.
execute if score footer tab matches 31 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>stop reading tab and focus on surviving
execute if score footer tab matches 32 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>dying has a negative effect on your survival
execute if score footer tab matches 33 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>what even is this
execute if score footer tab matches 34 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>It's legit a moose
execute if score footer tab matches 35 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>I guess we doin circles now (I should tell my boss)
execute if score footer tab matches 36 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>It's not dember ☹
execute if score footer tab matches 37 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>have you ever heard of legitimoose.com?
execute if score footer tab matches 38 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>real og's remember the freedev days
execute if score footer tab matches 39 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>most of these tips aren't really tips
execute if score footer tab matches 40 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>CHAOS, CHAOS
execute if score footer tab matches 41 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>hiding underground counters most events
execute if score footer tab matches 42 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>if someone compares this to Roblox one more time...
execute if score footer tab matches 43 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>You can read tips in the tab menu
execute if score footer tab matches 44 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>LETS GO GAMBLING! (we have a casino)
execute if score footer tab matches 45 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>SOON™ HAS ARRIVED, 1.21.7 IS HERE
execute if score footer tab matches 46 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Try /trigger communitychest
execute if score footer tab matches 47 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Try /trigger crafting
execute if score footer tab matches 48 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Try /trigger echest
execute if score footer tab matches 49 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Try /trigger rckrll
execute if score footer tab matches 50 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Try /trigger spawn
execute if score footer tab matches 51 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Try /trigger .menu
execute if score footer tab matches 52 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>the sky islands... WE STOLE THEM!
execute if score footer tab matches 53 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Hello gods of Earth, we are from *glitch*, communicating to tell you to PLEASE STOP STEALING OU- *line cuts*
execute if score footer tab matches 54 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Chaos Co. is not liable for any injuries.
execute if score footer tab matches 55 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>DRIVING IN MY CAR RIGHT AFTER A BEER!
execute if score footer tab matches 56 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Try sacrificing your friends for loot.
execute if score footer tab matches 57 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>The floor is not lava. Yet.
execute if score footer tab matches 58 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Our devs average 3 hours of sleep.
execute if score footer tab matches 59 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>We didn't code that bug. It coded itself.
execute if score footer tab matches 60 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Tip: Chaos is unavoidable. Embrace it.
execute if score footer tab matches 61 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>Everything is working as intended.
execute if score footer tab matches 62 run playerlist @a footer set <green><b>[TIP]:</b> <aqua>AFKing is a bold strategy.
