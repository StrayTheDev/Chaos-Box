scoreboard players add header tab.timer 1
execute if score header tab.timer matches 3.. run scoreboard players set header tab.timer 0

execute if score header tab.timer matches 0 run scoreboard players add header tab 1
execute if score header tab matches 9.. run scoreboard players set header tab 0


scoreboard players add footer tab.timer 1
execute if score footer tab.timer matches 200.. run scoreboard players set footer tab.timer 0


execute if score footer tab.timer matches 1 store result score footer tab run random value 0..62

function code:tab/header
function code:tab/footer