team leave @s
execute if entity @s[tag=player] run tellraw @s [{text:"Welcome back, ",color:"blue"},{"selector":"@s",color:"gold"},"!"]
execute unless entity @s[tag=player] run tellraw @a [{text:"Welcome, ",color:"blue"},{"selector":"@s",color:"gold"},", to ",{text:"ⒸⒽⒶⓄⓈ ⒷⓄⓍ",color:"red"},"!"]
scoreboard players enable @s spawn
scoreboard players enable @s rckrll
scoreboard players enable @s echest
scoreboard players enable @s communitychest
scoreboard players enable @s crafting
scoreboard players enable @s .menu
bossbar set minecraft:boss players @s
attribute @s scale base reset
attribute @s movement_speed base reset
attribute @s step_height base reset
attribute @s jump_strength base reset
team join spawn
tp @s 0 4 -44
tag @s add joined
tag @s add player

function big_shot_loop:stop

execute unless items entity @s inventory.* * unless items entity @s hotbar.* * run function code:starter_kit