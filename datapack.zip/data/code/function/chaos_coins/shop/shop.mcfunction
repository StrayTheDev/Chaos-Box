$execute if score @s chaos_coins matches $(price).. run playsound entity.experience_orb.pickup player @s
$execute if score @s chaos_coins matches $(price).. run tellraw @s {"text":"$(msg)","color":"green"}

$scoreboard players set .global tmp $(price)
$execute if score @s chaos_coins < .global tmp run tellraw @s [{"text":"▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌ ","color":"dark_gray"},{"text":"Insufficient Funds ($(price) required)","color":"dark_red"},{"text":" ▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌","color":"dark_gray"}]
execute if score @s chaos_coins < .global tmp run playsound entity.villager.no player @s


$execute if score @s chaos_coins matches $(price).. run $(function)
$execute if score @s chaos_coins matches $(price).. run scoreboard players remove @s chaos_coins $(price)