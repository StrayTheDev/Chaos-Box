execute store result score spamton tmp run clear @s music_disc_mellohi[custom_name=[{"text":"Key","italic":false,"color":"light_purple"},{"text":"gen","italic":false,"color":"gold"}],lore=[["",{"text":"Make me a ","italic":false,"color":"light_purple"},{"text":"[BIG SHOT]","italic":false,"color":"gold"}]],jukebox_playable="minecraft:11", tooltip_display={hidden_components:["jukebox_playable"]}] 1

playsound entity.bee.loop hostile @a ~ ~ ~ 10

execute if score spamton tmp matches 0 run tellraw @s [{"text":"find... the keygen... city...","color":"dark_red"}]

execute if score spamton tmp matches 1.. run tellraw @s [{"text":"you used the keygen... but nothing happened.","color":"dark_red"}]
execute if score spamton tmp matches 1.. run schedule function code:boss_fights/neo/dialogue-1 15s replace