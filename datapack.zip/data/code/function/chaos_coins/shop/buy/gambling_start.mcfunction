execute as @a[team=gambling] unless score @s chaos_coins matches 50.. run ride @s dismount
execute as @a[team=gambling] unless score @s chaos_coins matches 50.. run tellraw @a [{"selector":"@s"},{"text":" is broke, and has been ejected from the game. L","color":"green"}]
execute as @a[team=gambling] unless score @s chaos_coins matches 50.. run team join spawn @s
execute as @a[team=gambling] run scoreboard players remove @s chaos_coins 50
execute as @a[team=gambling] run scoreboard players add pot chaos_coins 50
tag @r[team=gambling] add winner
scoreboard players operation @a[tag=winner] chaos_coins += pot chaos_coins
execute if entity @a[tag=winner] run tellraw @a [{"selector":"@n[tag=winner]"},{"text":" Won a Jackpot of ","color":"green"},{"score":{"name":"pot","objective":"chaos_coins"}},{"text":"Ⓒ!"}]

scoreboard players set pot chaos_coins 0
tag @a[tag=winner] remove winner
playsound minecraft:entity.experience_orb.pickup master @a 85.55 5.00 -63.32