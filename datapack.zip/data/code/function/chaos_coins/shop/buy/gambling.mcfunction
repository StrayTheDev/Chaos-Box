playsound block.note_block.bit master @s ~ ~ ~ 99999999
execute store result score random gambling run random value 0..100
execute store result score random tmp run random value 0..9
title @s title [{"text":"["},{"score": {"name":"random","objective":"tmp"}},{"text":"]"}]



title @s times 0 90 10

execute if score @s gambling matches 1 if score random gambling matches 0..55 run title @s title {"text":"✘","color":"dark_red"}
execute if score @s gambling matches 1 if score random gambling matches 56..99 run title @s title {"text":"✔","color":"green"}
execute if score @s gambling matches 1 if score random gambling matches 100 run title @s title {"text":"☄☄☄","color":"gold"}
execute if score @s gambling matches 1 if score random gambling matches 0..60 run playsound entity.villager.no master @s ~ ~ ~ 9999999
execute if score @s gambling matches 1 if score random gambling matches 61..99 run playsound entity.villager.yes master @s ~ ~ ~ 9999999
execute if score @s gambling matches 1 if score random gambling matches 100 run playsound ui.toast.challenge_complete master @s ~ ~ ~ 9999999
$execute if score @s gambling matches 1 if score random gambling matches 61..99 run scoreboard players add @s chaos_coins $(wager)
$execute if score @s gambling matches 1 if score random gambling matches 61..99 run scoreboard players add @s chaos_coins $(wager)

execute if score @s gambling matches 1 if score random gambling matches 100 run scoreboard players set 100 tmp 100
$execute if score @s gambling matches 1 if score random gambling matches 100 run scoreboard players set winnings tmp $(wager)
execute if score @s gambling matches 1 if score random gambling matches 100 run scoreboard players operation winnings tmp *= 100 tmp
execute if score @s gambling matches 1 if score random gambling matches 100 run scoreboard players operation @s chaos_coins += winnings tmp

execute if score @s gambling matches 1 if score random gambling matches 0..55 run title @s subtitle {"text":"nothing...","color":"dark_red"}
execute if score @s gambling matches 1 if score random gambling matches 56..99 run title @s subtitle {"text":"YOU WIN! x2ⓒ","color":"green"}
execute if score @s gambling matches 1 if score random gambling matches 100 run title @s subtitle {"text":"JACKPOT! x100ⓒ","color":"gold"}


scoreboard players remove @s gambling 1