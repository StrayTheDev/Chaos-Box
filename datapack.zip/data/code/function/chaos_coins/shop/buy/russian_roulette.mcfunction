execute store result score gambling tmp run random value 1..6
execute if score gambling tmp matches 1 run kill @s
execute if score gambling tmp matches 1 run scoreboard players set @s chaos_coins 0
execute unless score gambling tmp matches 1 run tellraw @s ["<",{"text":"▌☄▌Vlad▌▐","color":"green"},{"text":"> Very good, comrade.","italic":true,"color":"white"}," +200Ⓒ"]
execute unless score gambling tmp matches 1 run scoreboard players add @s chaos_coins 200