$scoreboard players set .global tmp $(wager)

$execute if score @s chaos_coins < .global tmp run tellraw @s [{"text":"▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌ ","color":"dark_gray"},{"text":"You Lost Everything! ($(wager) required to gamble)","color":"dark_red"},{"text":" ▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌","color":"dark_gray"}]
execute if score @s chaos_coins < .global tmp run playsound entity.villager.no player @s


execute if score @s chaos_coins >= .global tmp run scoreboard players set @s gambling 1
execute if score @s chaos_coins >= .global tmp run function code:chaos_coins/shop/buy/gambling with entity @n[type=marker] data
$execute if score @s chaos_coins >= .global tmp run scoreboard players remove @s chaos_coins $(wager)