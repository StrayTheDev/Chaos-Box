execute if score @s chaos_coins matches 20.. run playsound entity.experience_orb.pickup player @s
execute if score @s chaos_coins matches 20.. run tellraw @s {"text":"Equipped Legitisims!","color":"green"}

scoreboard players set .global tmp 20
execute unless entity @s[tag=cosmetic.legitisims] if score @s chaos_coins < .global tmp run tellraw @s [{"text":"▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌ ","color":"dark_gray"},{"text":"Insufficient Funds (20 required)","color":"dark_red"},{"text":" ▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌","color":"dark_gray"}]
execute unless entity @s[tag=cosmetic.legitisims] if score @s chaos_coins < .global tmp run playsound entity.villager.no player @s


execute unless entity @s[tag=cosmetic.legitisims] if score @s chaos_coins matches 20.. run tag @s add cosmetic.legitisims
execute unless entity @s[tag=cosmetic.legitisims] if score @s chaos_coins matches 20.. run scoreboard players remove @s chaos_coins 20
execute on passengers run kill @s
execute if entity @s[tag=cosmetic.legitisims] run scoreboard players set @s cosmetic 5