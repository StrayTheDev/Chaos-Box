execute if score @s chaos_coins matches 200.. run playsound entity.experience_orb.pickup player @s
execute if score @s chaos_coins matches 200.. run tellraw @s {"text":"Equipped Back Sheath!","color":"green"}

scoreboard players set .global tmp 200
execute unless entity @s[tag=cosmetic.back] if score @s chaos_coins < .global tmp run tellraw @s [{"text":"▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌ ","color":"dark_gray"},{"text":"Insufficient Funds (200 required)","color":"dark_red"},{"text":" ▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌","color":"dark_gray"}]
execute unless entity @s[tag=cosmetic.back] if score @s chaos_coins < .global tmp run playsound entity.villager.no player @s


execute unless entity @s[tag=cosmetic.back] if score @s chaos_coins matches 200.. run tag @s add cosmetic.back
execute unless entity @s[tag=cosmetic.back] if score @s chaos_coins matches 200.. run scoreboard players remove @s chaos_coins 200
execute on passengers run kill @s
execute if entity @s[tag=cosmetic.back] run scoreboard players set @s cosmetic 6