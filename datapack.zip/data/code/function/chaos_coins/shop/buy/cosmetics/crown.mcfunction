execute if score @s chaos_coins matches 250.. run playsound entity.experience_orb.pickup player @s
execute if score @s chaos_coins matches 250.. run tellraw @s {"text":"Equipped Crown of the Blood God!","color":"green"}

scoreboard players set .global tmp 250
execute unless entity @s[tag=cosmetic.crown] if score @s chaos_coins < .global tmp run tellraw @s [{"text":"▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌ ","color":"dark_gray"},{"text":"Insufficient Funds (250 required)","color":"dark_red"},{"text":" ▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌","color":"dark_gray"}]
execute unless entity @s[tag=cosmetic.crown] if score @s chaos_coins < .global tmp run playsound entity.villager.no player @s


execute unless entity @s[tag=cosmetic.crown] if score @s chaos_coins matches 250.. run tag @s add cosmetic.crown
execute unless entity @s[tag=cosmetic.crown] if score @s chaos_coins matches 250.. run scoreboard players remove @s chaos_coins 250
execute on passengers run kill @s
execute if entity @s[tag=cosmetic.crown] run scoreboard players set @s cosmetic 1