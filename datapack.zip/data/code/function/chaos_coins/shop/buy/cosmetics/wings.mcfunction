execute if score @s chaos_coins matches 1000.. run playsound entity.experience_orb.pickup player @s
execute if score @s chaos_coins matches 1000.. run tellraw @s {"text":"Equipped Wings of Freedom!","color":"green"}

scoreboard players set .global tmp 1000
execute unless entity @s[tag=cosmetic.wings] if score @s chaos_coins < .global tmp run tellraw @s [{"text":"▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌ ","color":"dark_gray"},{"text":"Insufficient Funds (1000 required)","color":"dark_red"},{"text":" ▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌","color":"dark_gray"}]
execute unless entity @s[tag=cosmetic.wings] if score @s chaos_coins < .global tmp run playsound entity.villager.no player @s


execute unless entity @s[tag=cosmetic.wings] if score @s chaos_coins matches 1000.. run tag @s add cosmetic.wings
execute unless entity @s[tag=cosmetic.wings] if score @s chaos_coins matches 1000.. run scoreboard players remove @s chaos_coins 1000
execute on passengers run kill @s
execute if entity @s[tag=cosmetic.wings] run scoreboard players set @s cosmetic 4