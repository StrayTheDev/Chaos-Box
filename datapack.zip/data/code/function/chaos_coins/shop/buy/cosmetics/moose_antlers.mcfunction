execute if score @s chaos_coins matches 500.. run playsound entity.experience_orb.pickup player @s
execute if score @s chaos_coins matches 500.. run tellraw @s {"text":"Equipped Legitimate Moose!","color":"green"}

scoreboard players set .global tmp 500
execute unless entity @s[tag=cosmetic.moose_antlers] if score @s chaos_coins < .global tmp run tellraw @s [{"text":"▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌ ","color":"dark_gray"},{"text":"Insufficient Funds (500 required)","color":"dark_red"},{"text":" ▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌","color":"dark_gray"}]
execute unless entity @s[tag=cosmetic.moose_antlers] if score @s chaos_coins < .global tmp run playsound entity.villager.no player @s


execute unless entity @s[tag=cosmetic.moose_antlers] if score @s chaos_coins matches 500.. run tag @s add cosmetic.moose_antlers
execute unless entity @s[tag=cosmetic.moose_antlers] if score @s chaos_coins matches 500.. run scoreboard players remove @s chaos_coins 500
execute on passengers run kill @s
execute if entity @s[tag=cosmetic.moose_antlers] run scoreboard players set @s cosmetic 2