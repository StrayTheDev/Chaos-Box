execute if score @s chaos_coins matches 300.. run playsound entity.experience_orb.pickup player @s
execute if score @s chaos_coins matches 300.. run tellraw @s {"text":"Equipped Tree!","color":"green"}

scoreboard players set .global tmp 300
execute unless entity @s[tag=cosmetic.tree] if score @s chaos_coins < .global tmp run tellraw @s [{"text":"▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌ ","color":"dark_gray"},{"text":"Insufficient Funds (300 required)","color":"dark_red"},{"text":" ▌","color":"dark_gray"},{"text":"⚠","color":"gold"},{"text":"▌","color":"dark_gray"}]
execute unless entity @s[tag=cosmetic.tree] if score @s chaos_coins < .global tmp run playsound entity.villager.no player @s


execute unless entity @s[tag=cosmetic.tree] if score @s chaos_coins matches 300.. run tag @s add cosmetic.tree
execute unless entity @s[tag=cosmetic.tree] if score @s chaos_coins matches 300.. run scoreboard players remove @s chaos_coins 300
execute on passengers run kill @s
execute if entity @s[tag=cosmetic.tree] run scoreboard players set @s cosmetic 3