execute as @e[tag=chair] if data entity @s interaction on target at @s positioned ^ ^ ^2 run ride @s mount @n[tag=chair]

execute as @e[type=interaction,tag=!npc,tag=!chair,nbt={interaction:{}}] at @s run data modify storage minecraft:interaction function set string entity @s CustomName 1 -1
execute as @e[type=interaction,tag=!npc,tag=!chair,nbt={interaction:{}}] at @s unless data entity @n[type=marker] data.shop on target run function code:chaos_coins/shop/run with entity @n[type=marker] data
execute as @e[type=interaction,tag=!npc,tag=!chair,nbt={interaction:{}}] at @s if data entity @n[type=marker] data.shop on target run function code:chaos_coins/shop/shop with entity @n[type=marker] data

execute as @e[type=interaction,tag=npc,nbt={interaction:{}}] at @s on target run function code:dialogue/line with entity @n[type=marker] data
execute as @e[type=interaction,tag=npc,nbt={interaction:{}}] at @s on target run function code:dialogue/line2 with entity @n[type=marker] data
execute as @e[type=interaction,tag=npc,nbt={interaction:{}}] at @s on target run function code:dialogue/run with entity @n[type=marker] data



execute as @a[team=spawn] at @s if block ~ ~-1 ~ smooth_stone run effect give @s speed 1 3 false


execute as @a if items entity @s weapon.* command_block_minecart run function code:load
execute as @a if items entity @s weapon.* command_block_minecart run title @a title {"text":"The Code is Load","color":"green"}
execute as @a if items entity @s weapon.* command_block_minecart run title @a subtitle {"text":"a player has loaded the code","color":"green"}
execute as @a if items entity @s weapon.* command_block_minecart run clear @s command_block_minecart

execute as @a if items entity @s weapon.* minecraft:enchanted_book[minecraft:enchantment_glint_override=false] on attacker run tellraw @a [{"selector":"@s"},{"text":"just got Uno Reversed!","color":"green"}]
execute as @a if items entity @s weapon.* minecraft:enchanted_book[minecraft:enchantment_glint_override=false] on attacker run damage @s 20 player_attack at ~ ~ ~
execute as @a if items entity @s weapon.* minecraft:enchanted_book[minecraft:enchantment_glint_override=false] on attacker run title @s title {"text":"YOU JUST GOT UNO REVERSED","color":"green"}
execute as @a if items entity @s weapon.* minecraft:enchanted_book[minecraft:enchantment_glint_override=false] on attacker run playsound item.totem.use master @a ~ ~ ~
execute as @a at @s if items entity @s weapon.* minecraft:enchanted_book[minecraft:enchantment_glint_override=false] on attacker as @n run clear @s minecraft:enchanted_book[minecraft:enchantment_glint_override=false] 1

execute as @e[tag=hotbar] at @s on vehicle run data modify entity @n[tag=hotbar] item.id set from entity @p Inventory[0].id

execute as @e[scores={gambling=1..}] run function code:chaos_coins/shop/buy/gambling {wager:100}
team join spawn @a[team=gambling]
execute as @e[tag=chair,tag=gambling] on passengers run team join gambling @s

execute as @e[tag=rotate-eyes] at @s rotated as @n[tag=joined] anchored eyes run rotate @s ~ ~
execute as @e[tag=rotate-feet] at @s rotated as @n[tag=joined] anchored feet run rotate @s ~ 0
execute as @e[tag=riding] run data merge entity @s {teleport_duration:1}
execute as @e[tag=riding] unless predicate code:riding run kill @s
execute as @e[type=interaction,nbt={interaction:{}}] at @s run data remove entity @s interaction
