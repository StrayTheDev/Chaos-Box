##Trails
execute at @e[tag=ender-trail] run particle minecraft:dragon_breath ~ ~0.1 ~ 0.2 0.2 0.2 0 5 normal
execute at @e[tag=fire-trail] run particle flame ~ ~0.1 ~ 0.25 0.1 0.25 0 2 normal
execute at @e[tag=soul-fire-trail] run particle soul_fire_flame ~ ~0.1 ~ 0.25 0.1 0.25 0 2 normal
execute at @e[tag=lava-trail] run particle minecraft:falling_lava ~ ~ ~ 0.25 0.0 0.25 0 10 normal
execute at @e[tag=water-trail] run particle minecraft:dripping_water ~ ~ ~ 0.25 0.0 0.25 0 10 normal
execute at @e[tag=crying-trail] run particle minecraft:falling_obsidian_tear ~ ~ ~ 0.25 0.0 0.25 0 10 normal
execute at @e[tag=spore-trail] run particle minecraft:falling_spore_blossom ~ ~0.1 ~ 0.25 0.0 0.25 0 10 normal

##Auras
execute at @e[tag=ender-aura] run particle minecraft:portal ~ ~1.2 ~ 0.3 0.6 0.3 0 10 normal
execute at @e[tag=soul-aura] run particle minecraft:soul ~ ~1.2 ~ 0.3 0.6 0.3 0 1 normal
execute at @e[tag=smoke-aura] run particle minecraft:smoke ~ ~1.2 ~ 0.3 0.6 0.3 0 1 normal
execute at @e[tag=blue-blaze-aura] run particle minecraft:trial_spawner_detection_ominous ~ ~1.2 ~ 0.5 0.6 0.5 0 2 normal
execute at @e[tag=red-blaze-aura] run particle minecraft:trial_spawner_detection ~ ~1.2 ~ 0.5 0.6 0.5 0 2 normal
execute at @e[tag=blue-skull-aura] run particle minecraft:trial_omen ~ ~1.2 ~ 0.3 0.6 0.3 0 1 normal
execute at @e[tag=red-skull-aura] run particle minecraft:raid_omen ~ ~1.2 ~ 0.3 0.6 0.3 0 1 normal

##Rotating
execute at @e[tag=shriek] run particle minecraft:shriek{delay:0} ~ ~2 ~ 0 0 0 0 10 normal
execute at @e[tag=cherry_leaves] run particle minecraft:cherry_leaves ~-0.5 ~2.5 ~ 0.3 0.1 0.2 0 3