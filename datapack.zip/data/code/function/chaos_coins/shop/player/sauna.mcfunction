effect give @s regeneration 1 2
effect give @s saturation 1 0