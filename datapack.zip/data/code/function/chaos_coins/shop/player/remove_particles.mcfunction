tag @p remove ender-trail
tag @p remove ender-aura
tag @p remove fire-trail
tag @p remove soul-aura
tag @p remove soul-fire-trail
tag @p remove lava-trail
tag @p remove water-trail
tag @p remove crying-trail
tag @p remove spore-trail
tag @p remove smoke-aura
tag @p remove blue-blaze-aura
tag @p remove red-blaze-aura
tag @p remove red-skull-aura
tag @p remove blue-skull-aura
scoreboard players set @s cosmetic 0
execute as @e[distance=..3] run ride @s dismount