execute if score @s cosmetic matches 1 run function code:chaos_coins/shop/items/cosmetics/crown
execute if score @s cosmetic matches 2 run function code:chaos_coins/shop/items/cosmetics/moose_antlers
execute if score @s cosmetic matches 3 run function code:chaos_coins/shop/items/cosmetics/tree
execute if score @s cosmetic matches 4 run function code:chaos_coins/shop/items/cosmetics/wings
execute if score @s cosmetic matches 5 run function code:chaos_coins/shop/items/cosmetics/legitisims
execute if score @s cosmetic matches 6 run function code:chaos_coins/shop/items/cosmetics/back