tag @a[tag=survived,team=!pvp] remove survived 
function code:chaos_coins/shop/tick
function code:chaos_coins/shop/player/particle