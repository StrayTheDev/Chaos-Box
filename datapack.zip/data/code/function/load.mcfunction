setworldspawn 0 3 -44 0 

forceload add 24 -59 -24 -27

schedule function code:reload_displays 1s
execute unless entity @p[team=pvp] run schedule clear code:map_chooser/schedule/10sec
execute unless entity @p[team=pvp] run schedule clear code:map_chooser/schedule/30sec
execute unless entity @p[team=pvp] run schedule clear code:map_chooser/schedule/1min
execute unless entity @p[team=pvp] run schedule clear code:map_chooser/schedule/2min
execute unless entity @p[team=pvp] run schedule clear code:map_chooser/schedule/5min
execute unless entity @p[team=pvp] run schedule clear code:map_chooser/schedule/start
execute unless entity @p[team=pvp] run function code:map_chooser/schedule/start
function code:disaster_system/load_disasters
#function player_motion:internal/technical/load

difficulty hard
gamerule showDeathMessages false
gamerule announceAdvancements false
gamerule doMobSpawning false
gamerule mobGriefing true
gamerule tntExplosionDropDecay true
gamerule doFireTick true
gamerule doImmediateRespawn true
gamerule keepInventory false
gamerule randomTickSpeed 12
gamerule commandModificationBlockLimit 999999999
gamerule locatorBar false
gamerule spawnChunkRadius 0
gamerule spawnRadius 0

team add dead
team add pvp
team add spawn
team add the_end
team add sandbox
team add map
team add gambling

scoreboard players set .timer tmp 200
scoreboard objectives add player.deathDetection deathCount
scoreboard objectives add carrot minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add left minecraft.custom:minecraft.leave_game
scoreboard objectives add tmp dummy
scoreboard objectives add constant dummy
scoreboard objectives add stats.time_survived dummy
scoreboard objectives add stats.deaths deathCount
scoreboard objectives add stats.deaths2 dummy
scoreboard objectives add stats.kills minecraft.custom:minecraft.player_kills
scoreboard objectives add christmas_point_amount trigger
scoreboard objectives add disasters dummy
scoreboard players set 20 constant 20
scoreboard players set 60 constant 60
scoreboard players set 1 tmp 1
scoreboard objectives add chaos_coins dummy
scoreboard objectives add nbs_BIGSHOTloo dummy
scoreboard objectives add nbs_BIGSHOTloo_t dummy
scoreboard players set speed nbs_BIGSHOTloo 80
scoreboard objectives add posX dummy
scoreboard objectives add posY dummy
scoreboard objectives add posZ dummy
scoreboard objectives add posX1 dummy
scoreboard objectives add posY1 dummy
scoreboard objectives add posZ1 dummy
scoreboard objectives add id dummy
scoreboard objectives add death1 deathCount
scoreboard objectives add stats.time_survived1 dummy
scoreboard objectives add stats.ts_rank dummy
scoreboard objectives add tab dummy
scoreboard objectives add tab.timer dummy
scoreboard objectives add tnt_velocity dummy
scoreboard objectives add gambling dummy "gambling"
scoreboard objectives add rckrll trigger
scoreboard objectives add spawn trigger
scoreboard objectives add echest trigger
scoreboard objectives add communitychest trigger
scoreboard objectives add crafting trigger
scoreboard objectives add .menu trigger
scoreboard objectives add timer dummy
scoreboard objectives add cosmetic dummy

scoreboard objectives add motion_x1 dummy
scoreboard objectives add motion_y1 dummy
scoreboard objectives add motion_z1 dummy

scoreboard objectives add motion_x2 dummy
scoreboard objectives add motion_y2 dummy
scoreboard objectives add motion_z2 dummy

tellraw @a [{"text":"▄▄▄▄▄▄▄▄▄▄▄▄▄▄","color":"dark_gray"},"\n",{"text":"⏸⏸⏸⏸⏸","color":"dark_gray"},{"text":"ⒸⒽⒶⓄⓈ","color":"dark_red"},{"text":" ⒷⓄⓍ","color":"red"},{"text":"⏸⏸⏸⏸⏸","color":"dark_gray"},"\n",{"text":"|⏸⏸⏸⏸","color":"dark_gray"},{"text":"The Code is Load","color":"green"},{"text":"⏸⏸⏸⏸⏸","color":"dark_gray"},"\n",{"text":"▀▀▀▀▀▀▀▀▀▀▀▀▀▀","color":"dark_gray"}]
playsound block.note_block.bell master @a 0 0 0 999999 1.414214
playsound block.note_block.bell master @a 0 0 0 999999 0.890899
playsound block.note_block.bell master @a 0 0 0 999999 1.059463

# pointless note