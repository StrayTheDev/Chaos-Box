execute as @a run function code:player_tick
execute as @e[type=item,nbt={Age:1000s}] run kill @s

# Respawn Player
execute as @a[x=4,dx=-8,y=3,dy=5,z=-25,dz=-1] store result storage rand.pos y int 1.0 run random value 0..200
execute as @a[x=4,dx=-8,y=3,dy=5,z=-25,dz=-1] run function code:spawning with storage rand.pos


execute as @a[scores={cosmetic=1..},predicate=!code:rider] at @s run function code:chaos_coins/shop/items/cosmetics/tick

###################################################################################

particle minecraft:electric_spark 3.5 5 -33.50 0.3 0.1 0.3 0 1
kill @e[tag=!safe,type=!experience_orb,type=!armor_stand,type=!marker,type=!player,type=!interaction,type=!block_display,type=!item_display,type=!text_display,type=!item,x=-20,y=3,z=-60,dx=200,dy=20,dz=30]


## DISASTER SYSTEM

# Main Disaster Loop
function code:disaster_system/randomizer/tick1 with storage code:disaster_system
execute if score .timer disasters matches ..0 run function code:disaster_system/randomizer/end1 with storage code:disaster_system
execute if score .timer disasters matches ..0 run function code:disaster_system/randomizer/start_next
execute if score .timer disasters matches 1.. run scoreboard players remove .timer disasters 1



###################################################################################


execute if score boss tmp matches 1 run function code:disaster_system/spamton/tick

##functions
function code:commands/tick
function code:chaos_coins/tick
function code:tab/tick
execute as @e[tag=motion_projectile,tag=!motion_added] at @s run function code:disaster_system/.misc/motion/launch




#Sandbox Stuff

execute as @a[team=sandbox] at @s if block ~ ~ ~ bedrock run kill @s
execute positioned 14.5 6.00 -65.5 run kill @e[type=!player,tag=!safe,distance=..5]
execute unless blocks 11 4 -61 17 7 -72 -100 100 -100 all run fill 11 4 -61 17 7 -72 air destroy


#make dev tunnel infinite
execute positioned 406.5 6.5 -29.5 as @e[distance=..18] at @s run tag @s add infiniteturn
execute as @e[tag=infiniteturn] at @s run teleport @s ~ ~ ~ ~180 ~
execute as @e[tag=infiniteturn] at @s store result score @s posX run data get entity @s Pos[0] 1000
execute as @e[tag=infiniteturn] at @s store result score @s posZ run data get entity @s Pos[2] 1000
scoreboard players set 370500 constant 370500
scoreboard players set -29500 constant -29500
scoreboard players set -1 constant -1
execute as @e[tag=infiniteturn] at @s run scoreboard players operation @s posX -= 370500 constant
execute as @e[tag=infiniteturn] at @s run scoreboard players operation @s posZ -= -29500 constant
execute as @e[tag=infiniteturn] at @s run scoreboard players operation @s posX *= -1 constant
execute as @e[tag=infiniteturn] at @s run scoreboard players operation @s posZ *= -1 constant
execute as @e[tag=infiniteturn] at @s run scoreboard players operation @s posX += 370500 constant
execute as @e[tag=infiniteturn] at @s run scoreboard players operation @s posZ += -29500 constant
execute as @e[tag=infiniteturn] at @s run function code:infinite_hallway/main
execute as @e[tag=infiniteturn] at @s run tag @s remove infiniteturn

#370500 -29500