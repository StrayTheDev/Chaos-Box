execute store result score randomFunction tmp run random value 1..11

tp @a[team=pvp] 0 4 -44 0 0
team join spawn @a[team=pvp]
kill @e[x=-25,dx=50,y=-100,dy=400,z=-25,dz=50,type=!player]
kill @e[type=item]

execute if score randomFunction tmp matches 1 run function code:map_chooser/maps/beach
execute if score randomFunction tmp matches 2 run function code:map_chooser/maps/sky_islands
execute if score randomFunction tmp matches 3 run function code:map_chooser/maps/castle
execute if score randomFunction tmp matches 4 run function code:map_chooser/maps/chaos_tower
execute if score randomFunction tmp matches 5 run function code:map_chooser/maps/chaos
execute if score randomFunction tmp matches 6 run function code:map_chooser/maps/city
execute if score randomFunction tmp matches 7 run function code:map_chooser/maps/lobby
execute if score randomFunction tmp matches 8 run function code:map_chooser/maps/forest
execute if score randomFunction tmp matches 9 run function code:map_chooser/maps/windmill
execute if score randomFunction tmp matches 10 run function code:map_chooser/maps/bridges
execute if score randomFunction tmp matches 11 run function code:map_chooser/maps/petals
execute if score randomFunction tmp matches 12 run function code:map_chooser/maps/color
execute if score randomFunction tmp matches 13 run function code:map_chooser/maps/kitpvp
execute if score randomFunction tmp matches 14 run function code:map_chooser/maps/battle_train
execute if score randomFunction tmp matches 15 run function code:map_chooser/maps/block_fortress
execute if score randomFunction tmp matches 16 run function code:map_chooser/maps/altitude
function code:map_chooser/schedule/start