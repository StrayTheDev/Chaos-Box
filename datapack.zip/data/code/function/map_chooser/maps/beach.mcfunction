tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" Beach","color":"aqua"}]
team modify map suffix ["",{"text":" [","color":"aqua",bold:false},{"text":"Beach","color":"aqua"},{"text":"]","color":"aqua",bold:false}]


fill -25 -64 -25 26 300 25 air
place template code:beach -25 -64 -25 none none 1


summon minecraft:armadillo 10.45 6.00 16.80 {Silent:1b,DeathLootTable:"minecraft:empty",Health:9999999999f,attributes:[{id:"minecraft:generic.armor",base:10},{id:"minecraft:generic.max_health",base:999},{id:"minecraft:generic.armor_toughness",base:10},{id:"minecraft:generic.gravity",base:0.02},{id:"minecraft:generic.movement_speed",base:0},{id:"minecraft:generic.safe_fall_distance",base:999},{id:"minecraft:generic.scale",base:2},{id:"minecraft:generic.burning_time",base:0},{id:"minecraft:generic.water_movement_efficiency",base:0}]}
effect give @e[type=armadillo] regeneration infinite 100 true
effect give @e[type=armadillo] slow_falling infinite 100 true