tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" Mystical Forest","color":"aqua"}]
team modify map suffix [{"text":" [","color":"aqua",bold:false},{"text":"Mystical Forest","color":"aqua"},{"text":"]","color":"aqua",bold:false}]

forceload add 1000 1153 1050 1203
fill -25 -64 -25 26 300 25 air
clone 1000 -64 1153 1050 318 1203 -25 -64 -25 strict
