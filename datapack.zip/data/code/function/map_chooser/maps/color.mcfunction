tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" Spire of Color","color":"aqua"}]
team modify map suffix ["",{"text":" [","color":"aqua",bold:false},{"text":"Spire of Color","color":"aqua"},{"text":"]","color":"aqua",bold:false}]

forceload add 1044 1000 1094 1050
fill -25 -64 -25 26 300 25 air
clone 1044 -64 1000 1094 319 1050 -25 -64 -25 strict
