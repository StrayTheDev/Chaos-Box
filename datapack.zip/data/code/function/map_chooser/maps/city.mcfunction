tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" City","color":"aqua"}]
team modify map suffix [{"text":" [","color":"aqua",bold:false},{"text":"City","color":"aqua"},{"text":"]","color":"aqua",bold:false}]


fill -25 -64 -25 26 300 25 air
place template code:city -25 -64 -25