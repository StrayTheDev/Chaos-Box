tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" Redstone's KitPVP","color":"aqua"}]
tellraw @a ["",{"text":"in collaboration with:","color":"green",bold:false},{"text":" Redstone's KitPVP","color":"blue",click_event:{action:"suggest_command",command:"/world 5301e4eb-c3a7-461c-ad01-c61e7fb54959"},hover_event:{action:"show_text",value:"Click to visit Redstone's KitPVP!"}}]
team modify map suffix ["",{"text":" [","color":"aqua",bold:false},{"text":"Redstone's KitPVP","color":"aqua"},{"text":"]","color":"aqua",bold:false}]

forceload add 1000 1102 1050 1152
fill -25 -64 -25 26 300 25 air
clone 1000 -64 1102 1050 318 1152 -25 -64 -25 strict
