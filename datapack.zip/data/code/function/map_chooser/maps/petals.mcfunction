tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" The Palace of Pink Petals","color":"aqua"}]
team modify map suffix [{"text":" [","color":"aqua",bold:false},{"text":"Pink Petal Palace","color":"aqua"},{"text":"]","color":"aqua",bold:false}]

forceload add 1097 1000 1147 1050
fill -25 -64 -25 26 300 25 air
clone 1097 -64 1000 1147 318 1050 -25 -64 -25 strict
