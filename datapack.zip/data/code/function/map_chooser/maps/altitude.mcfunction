tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" Altitude","color":"aqua"}]
tellraw @a ["",{"text":"in collaboration with:","color":"green",bold:false},{"text":" Altitude","color":"blue",click_event:{action:"suggest_command",command:"/world 5a344b3f-1950-4d34-a659-1826c50a7fe8"},hover_event:{action:"show_text",value:"Click to visit Altitude!"}}]
team modify map suffix ["",{"text":" [","color":"aqua",bold:false},{"text":"Altitude","color":"aqua"},{"text":"]","color":"aqua",bold:false}]

forceload add 993 1051 1043 1101
fill -25 -64 -25 26 300 25 air
clone 993 -64 1051 1043 319 1101 -25 -64 -25 strict