tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" Block Fortress","color":"aqua"}]
tellraw @a ["",{"text":"in collaboration with:","color":"green",bold:false},{"text":" Block Fortress","color":"blue",click_event:{action:"suggest_command",command:"/world b75b05d3-ea3f-404e-a09e-eea9004b653c"},hover_event:{action:"show_text",value:"Click to visit Block Fortress!"}}]
team modify map suffix ["",{"text":" [","color":"aqua",bold:false},{"text":"Block Fortress","color":"aqua"},{"text":"]","color":"aqua",bold:false}]

forceload add 1044 948 1094 998
fill -25 -64 -25 26 300 25 air
clone 1094 -64 998 1044 318 948 -25 -64 -25 strict
