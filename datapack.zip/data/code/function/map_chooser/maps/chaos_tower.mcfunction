tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" Tower of True Chaos","color":"aqua"}]
team modify map suffix [{"text":" [","color":"aqua",bold:false},{"text":"Tower of Chaos","color":"aqua"},{"text":"]","color":"aqua",bold:false}]


fill -25 -64 -25 26 300 25 air
place template code:tower_of_chaos -25 -64 -25

summon minecraft:interaction -14 -47 -1 {Tags:[safe],Passengers:[{id:"minecraft:marker",Tags:[safe],data:{function:"fill ~ ~ ~ ~ ~120 ~ twisting_vines",shop:true,price:0,msg:""}}]}
summon text_display -14 -46 -1 {alignment:"center",billboard:"vertical",view_range:10,line_width:250,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]},text:'"Grow Beanstalk"'}
