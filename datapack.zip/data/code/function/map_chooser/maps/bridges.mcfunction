tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" Bridges to Nowhere","color":"aqua"}]
team modify map suffix ["",{"text":" [","color":"aqua",bold:false},{"text":"Bridges to Nowhere","color":"aqua"},{"text":"]","color":"aqua",bold:false}]

forceload add 1050 1102 1100 1152
fill -25 -64 -25 26 300 25 air
clone 1050 -64 1102 1100 318 1152 -25 -64 -25 strict
