tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" Sky Islands","color":"aqua"}]
team modify map suffix [{"text":" [","color":"aqua",bold:false},{"text":"Sky Islands","color":"aqua"},{"text":"]","color":"aqua",bold:false}]


fill -25 -64 -25 26 300 25 air
place template code:sky_islands -25 -64 -25 none none 1


summon interaction -3 -4.00 -8 {Tags:[safe],Passengers:[{id:"minecraft:marker",Tags:[safe],data:{shop:true,function:"summon minecraft:boat ~1.5 ~-1 ~-1.5 {NoGravity:true,Rotation:[90.0f,0.0f]}",price:10,msg:"off you go!"}}]}
summon oak_boat -1.0 -5.00 -9.0 {Tags:[safe],NoGravity:true,Rotation:[90.0f,0.0f]}
summon cow 19.0 -5.00 -16.0 {Tags:[safe],NoGravity:true,attributes:[{id:"minecraft:scale",base:3.0}]}