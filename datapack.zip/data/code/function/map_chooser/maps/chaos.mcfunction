tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" THE ULTIMATE CHAOS","color":"aqua"}]
team modify map suffix [{"text":" [","color":"aqua",bold:false},{"text":"THE ULTIMATE CHAOS","color":"aqua"},{"text":"]","color":"aqua",bold:false}]


fill -25 -64 -25 26 300 25 air
place template code:chaos -25 -64 -25



summon minecraft:interaction -21 96 -19 {width:1.2,height:1,Tags:[safe],Passengers:[{id:"minecraft:marker",Tags:[safe,teleporter],data:{function:"tp @e[tag=teleporter,limit=1,sort=random]",shop:true,price:0,msg:"Whoosh!"}}]}
summon minecraft:interaction 1 9 -23 {width:1.2,height:1,Tags:[safe],Passengers:[{id:"minecraft:marker",Tags:[safe,teleporter],data:{function:"tp @e[tag=teleporter,limit=1,sort=random]",shop:true,price:0,msg:"Whoosh!"}}]}
summon minecraft:interaction -1 -30 21 {width:1.2,height:1,Tags:[safe],Passengers:[{id:"minecraft:marker",Tags:[safe,teleporter],data:{function:"tp @e[tag=teleporter,limit=1,sort=random]",shop:true,price:0,msg:"Whoosh!"}}]}
summon minecraft:interaction 6 -40 -2 {width:1.2,height:1,Tags:[safe],Passengers:[{id:"minecraft:marker",Tags:[safe,teleporter],data:{function:"tp @e[tag=teleporter,limit=1,sort=random]",shop:true,price:0,msg:"Whoosh!"}}]}
summon minecraft:interaction 14 -55 15 {width:1.2,height:1,Tags:[safe],Passengers:[{id:"minecraft:marker",Tags:[safe,teleporter],data:{function:"tp @e[tag=teleporter,limit=1,sort=random]",shop:true,price:0,msg:"Whoosh!"}}]}
summon minecraft:interaction 11 14 13 {width:1.2,height:1,Tags:[safe],Passengers:[{id:"minecraft:marker",Tags:[safe,teleporter],data:{function:"tp @e[tag=teleporter,limit=1,sort=random]",shop:true,price:0,msg:"Whoosh!"}}]}
summon minecraft:interaction -5 46 1 {width:1.2,height:1,Tags:[safe],Passengers:[{id:"minecraft:marker",Tags:[safe,teleporter],data:{function:"tp @e[tag=teleporter,limit=1,sort=random]",shop:true,price:0,msg:"Whoosh!"}}]}
summon minecraft:interaction 13 92 -16 {width:1.2,height:1,Tags:[safe],Passengers:[{id:"minecraft:marker",Tags:[safe,teleporter],data:{function:"tp @e[tag=teleporter,limit=1,sort=random]",shop:true,price:0,msg:"Whoosh!"}}]}
