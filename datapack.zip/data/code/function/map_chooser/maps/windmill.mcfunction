tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" Windmill","color":"aqua"}]
team modify map suffix [{"text":" [","color":"aqua",bold:false},{"text":"Windmill","color":"aqua"},{"text":"]","color":"aqua",bold:false}]

forceload add 1050 1153 1100 1203
fill -25 -64 -25 26 300 25 air
clone 1050 -64 1153 1100 318 1203 -25 -64 -25 strict
