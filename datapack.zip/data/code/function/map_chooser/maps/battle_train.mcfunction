tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" Battle Train","color":"aqua"}]
tellraw @a ["",{"text":"in collaboration with:","color":"green",bold:false},{"text":" Battle Train","color":"blue",click_event:{action:"suggest_command",command:"/world de9b06f4-39ea-4143-b0db-e4db7060b842"},hover_event:{action:"show_text",value:"Click to visit Battle Train!"}}]
team modify map suffix ["",{"text":" [","color":"aqua",bold:false},{"text":"Battle Train","color":"aqua"},{"text":"]","color":"aqua",bold:false}]

forceload add 993 1000 1043 1050
fill -25 -64 -25 26 300 25 air
clone 993 -64 1000 1043 318 1050 -25 -64 -25 strict
