tellraw @a ["",{"text":"[MAP CHOSEN]:","color":"blue",bold:false},{"text":" Castle of Ruins","color":"aqua"}]
team modify map suffix ["",{"text":" [","color":"aqua",bold:false},{"text":"Castle of Ruins","color":"aqua"},{"text":"]","color":"aqua",bold:false}]

fill -25 -64 -25 26 300 25 air
place template code:castle -25 -64 -25 none none 1


summon minecraft:interaction 1 -23 15 {Tags:[safe],width:1.5,height:2.5,Passengers:[{id:"minecraft:marker",Tags:[safe],data:{function:"execute positioned ~ ~1 ~-2 run summon tnt ~ ~ ~ {block_state:{Name:\"minecraft:coal_block\"},fuse:35,Motion:[0.0,0.2,-0.6]}",shop:true,msg:"FIRE!",price:0}}]}
