schedule function code:map_chooser/schedule/clearlag 10s
schedule function code:map_chooser/schedule/5min 300s
schedule function code:map_chooser/schedule/2min 480s
schedule function code:map_chooser/schedule/1min 540s
schedule function code:map_chooser/schedule/30sec 570s
schedule function code:map_chooser/schedule/10sec 590s
schedule function code:map_chooser/choose_map 600s
schedule function code:map_chooser/schedule/start 600s