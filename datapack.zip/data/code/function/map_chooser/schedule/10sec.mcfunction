tellraw @a ["",{"text":"[Chaos Box]→","color":"blue",bold:false}," map resets in 10 seconds"]
execute as @a at @s run playsound minecraft:block.amethyst_cluster.hit master @s ~ ~ ~