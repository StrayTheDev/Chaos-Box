tellraw @a [{"text":"[Chaos Box]→","color":"blue",bold:false}," Cleared all Items!\n "]
execute as @a at @s run playsound minecraft:block.amethyst_cluster.hit master @s ~ ~ ~
kill @e[x=-25,dx=50,y=-100,dy=400,z=-25,dz=50,type=item,tag=!safe]
forceload remove all