tellraw @a ["",{"text":"[Chaos Box]→","color":"blue",bold:false}," map resets in 5 minutes\n "]
execute as @a at @s run playsound minecraft:block.amethyst_cluster.hit master @s ~ ~ ~