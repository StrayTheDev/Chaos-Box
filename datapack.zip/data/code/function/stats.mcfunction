scoreboard players operation @s stats.deaths = @s stats.deaths
scoreboard players operation @s stats.deaths2 = @s stats.deaths2

scoreboard players add @s[team=pvp,gamemode=survival] stats.time_survived 1
execute if score @s stats.deaths > @s stats.deaths2 run scoreboard players set @s stats.time_survived 0
execute if score @s stats.deaths > @s stats.deaths2 run scoreboard players operation @s stats.deaths2 = @s stats.deaths

scoreboard players operation seconds tmp = @s stats.time_survived
scoreboard players operation seconds tmp /= 20 constant
scoreboard players operation minutes tmp = seconds tmp
scoreboard players operation seconds tmp %= 60 constant
scoreboard players operation minutes tmp /= 60 constant
scoreboard players operation hours tmp = minutes tmp
scoreboard players operation minutes tmp %= 60 constant
scoreboard players operation hours tmp /= 60 constant

scoreboard players reset secondsfix tmp
scoreboard players reset minutessfix tmp
execute if score seconds tmp matches 0..9 run scoreboard players set secondsfix tmp 0
execute if score minutes tmp matches 0..9 run scoreboard players set minutesfix tmp 0

title @s actionbar [{"text":"Time Survived: ", "color": "blue"}, {"score":{"name":"hours","objective":"tmp"},"color":"gold"},{"text":":","color":"gray"},{"score":{"name":"minutesfix","objective":"tmp"},"color":"gold"},{"score":{"name":"minutes","objective":"tmp"},"color":"gold"},{"text":":","color":"gray"},{"score":{"name":"secondsfix","objective":"tmp"},"color":"gold"},{"score":{"name":"seconds","objective":"tmp"},"color":"gold"},{"text":" | ","color":"dark_gray"},{"text":"Chaos Coins: ","color":"blue"},{"text":"Ⓒ","color":"gold"},{"color":"gold","score":{"objective":"chaos_coins","name":"@s"}}]
