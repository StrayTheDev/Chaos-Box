data modify storage code:temp name set from storage code:data player.name
$execute store success score temp tmp run data modify storage code:temp name set from storage code:leaderboard $(score)[$(id)].name
$execute if score temp tmp matches 0 run data remove storage code:leaderboard $(score)[$(id)]

execute store result score id tmp run data get storage code:data player.id
scoreboard players operation id tmp += 1 tmp
execute store result storage code:data player.id int 1.0 run scoreboard players get id tmp
execute if score temp tmp matches 1 run function code:leaderboard/clear with storage code:data player
