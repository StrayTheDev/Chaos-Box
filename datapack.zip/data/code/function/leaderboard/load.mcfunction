$execute store result score temp tmp run data get storage code:leaderboard $(score)[$(id)].$(score) 1.0
$execute store result score temp2 tmp run data get storage code:data player.$(score) 1.0

$execute if score temp tmp < temp2 tmp run data modify storage code:leaderboard $(score) insert $(id) from storage code:data player

execute store result score id tmp run data get storage code:data player.id
scoreboard players operation id tmp += 1 tmp
execute store result storage code:data player.id int 1.0 run scoreboard players get id tmp
execute if score temp tmp >= temp2 tmp run function code:leaderboard/load with storage code:data player