execute store result storage code:data player.time int 1.0 run scoreboard players get @s stats.time_survived1
execute store result storage code:data player.deaths int 1.0 run scoreboard players get @s stats.deaths2
execute store result storage code:data player.coins int 1.0 run scoreboard players get @s chaos_coins
execute store result storage code:data player.kills int 1.0 run scoreboard players get @s stats.kills
data modify storage code:data player.name set from entity @s bukkit.lastKnownName

data merge storage code:data {player:{id:0,score:time}}
function code:leaderboard/clear with storage code:data player
data merge storage code:data {player:{id:0,score:time}}
function code:leaderboard/load with storage code:data player

data merge storage code:data {player:{id:0,score:deaths}}
function code:leaderboard/clear with storage code:data player
data merge storage code:data {player:{id:0,score:deaths}}
function code:leaderboard/load with storage code:data player

data merge storage code:data {player:{id:0,score:kills}}
function code:leaderboard/clear with storage code:data player
data merge storage code:data {player:{id:0,score:kills}}
function code:leaderboard/load with storage code:data player

data merge storage code:data {player:{id:0,score:coins}}
function code:leaderboard/clear with storage code:data player
data merge storage code:data {player:{id:0,score:coins}}
function code:leaderboard/load with storage code:data player

function code:leaderboard/display