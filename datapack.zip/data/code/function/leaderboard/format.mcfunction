$execute store result score seconds tmp run data get storage code:leaderboard time[$(id)].time 1.0
scoreboard players operation seconds tmp /= 20 constant
scoreboard players operation minutes tmp = seconds tmp
scoreboard players operation seconds tmp %= 60 constant
scoreboard players operation minutes tmp /= 60 constant
scoreboard players operation hours tmp = minutes tmp
scoreboard players operation minutes tmp %= 60 constant
scoreboard players operation hours tmp /= 60 constant

$data modify storage code:temp $(score)$(id).name set string storage code:leaderboard $(score)[$(id)].name
$data modify entity @s text set value [{color:"white",storage:"code:temp",nbt:"$(score)$(id).name"},{color:white,text:" - "},{color:gold,score:{name:"hours",objective:tmp}},{color:gold,text:":"},{color:gold,score:{name:"minutes",objective:tmp}},{color:gold,text:":"},{color:gold,score:{name:"seconds",objective:tmp}}]