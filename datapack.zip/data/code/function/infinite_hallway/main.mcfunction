execute store result storage code:infinite x double 0.001 run scoreboard players get @s posX
execute store result storage code:infinite z double 0.001 run scoreboard players get @s posZ
function code:infinite_hallway/teleport with storage code:infinite