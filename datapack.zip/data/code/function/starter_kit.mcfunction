give @s minecraft:stone_axe[enchantments={"code:soulbound":1},item_name={text:"Starter Axe"}]
give @s minecraft:stone_pickaxe[enchantments={"code:soulbound":1},item_name={text:"Starter Pickaxe"}]
give @s minecraft:bread[enchantments={"code:soulbound":1}] 32
effect give @s saturation 600