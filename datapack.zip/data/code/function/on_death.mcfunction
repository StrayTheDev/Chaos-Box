scoreboard players set @s player.deathDetection 0

attribute @s gravity base set 0.08
attribute @s scale base set 1
tp @s 0 4 -44


tag @s add owner
execute as @e[type=item] at @s if data entity @s Item.components.minecraft:enchantments.code:soulbound unless data entity @s Thrower run tp @s 0 4 -44
execute as @e[type=item] at @s if data entity @s Item.components.minecraft:enchantments.code:soulbound unless data entity @s Thrower run data merge entity @s {PickupDelay:0,Tags:[tp]}
execute as @e[type=item] at @s if data entity @s Item.components.minecraft:enchantments.code:soulbound unless data entity @s Thrower run data modify entity @s Owner set from entity @p[tag=owner] UUID
tag @s remove owner

team join dead @s

execute store result score .randomize tmp run random value 1..45

execute if score .randomize tmp matches 1 run tellraw @a [{"selector":"@s"},{"text":"died","color":"gold"}]
execute if score .randomize tmp matches 2 run tellraw @a [{"selector":"@s"},{"text":"died due to skill issue","color":"gold"}]
execute if score .randomize tmp matches 3 run tellraw @a [{"selector":"@s"},{"text":"was bad ☠","color":"gold"}]
execute if score .randomize tmp matches 4 run tellraw @a [{"selector":"@s"},{"text":"couldn't survive the box","color":"gold"}]
execute if score .randomize tmp matches 5 run tellraw @a [{"selector":"@s"},{"text":"took the L.","color":"gold"}]
execute if score .randomize tmp matches 6 run tellraw @a [{"selector":"@s"},{"text":"took one for the team","color":"gold"}]
execute if score .randomize tmp matches 7 run tellraw @a [{"selector":"@s"},{"text":"lagged","color":"gold"}]
execute if score .randomize tmp matches 8 run tellraw @a [{"selector":"@s"},{"text":"has been utterly obliterated","color":"gold"}]
execute if score .randomize tmp matches 9 run tellraw @a [{"selector":"@s"},{"text":"met an unfortunate fate","color":"gold"}]
execute if score .randomize tmp matches 10 run tellraw @a [{"selector":"@s"},{"text":"bid farewell to this cruel world","color":"gold"}]
execute if score .randomize tmp matches 11 run tellraw @a [{"selector":"@s"},{"text":"wasnt prepared for the chaos","color":"gold"}]
execute if score .randomize tmp matches 12 run tellraw @a [{"selector":"@s"},{"text":"learned the hard way","color":"gold"}]
execute if score .randomize tmp matches 13 run tellraw @a [{"selector":"@s"},{"text":"drank soda","color":"gold"}]
execute if score .randomize tmp matches 14 run tellraw @a [{"selector":"@s"},{"text":"got outplayed","color":"gold"}]
execute if score .randomize tmp matches 15 run tellraw @a [{"selector":"@s"},{"text":"forgot how to breath","color":"gold"}]
execute if score .randomize tmp matches 16 run tellraw @a [{"selector":"@s"},{"text":"is now dead","color":"gold"}]
execute if score .randomize tmp matches 17 run tellraw @a [{"selector":"@s"},{"text":"took too much damage","color":"gold"}]
execute if score .randomize tmp matches 18 run tellraw @a [{"selector":"@s"},{"text":"fell victim to the chaos","color":"gold"}]
execute if score .randomize tmp matches 19 run tellraw @a [{"selector":"@s"},{"text":"was killed in the chaos","color":"gold"}]
execute if score .randomize tmp matches 20 run tellraw @a [{"selector":"@s"},{"text":"dug straight down","color":"gold"}]
execute if score .randomize tmp matches 21 run tellraw @a [{"selector":"@s"},{"text":"had a bad time","color":"gold"}]
execute if score .randomize tmp matches 22 run tellraw @a [{"selector":"@s"},{"text":"Alt+F4'd","color":"gold"}]
execute if score .randomize tmp matches 23 run tellraw @a [{"selector":"@s"},{"text":"is bad at the game","color":"gold"}]
execute if score .randomize tmp matches 24 run tellraw @a [{"selector":"@s"},{"text":"should have played Koori Farming instead","color":"gold"}]
execute if score .randomize tmp matches 25 run tellraw @a [{"selector":"@s"},{"text":"is more dead than Mining Game","color":"gold"}]
execute if score .randomize tmp matches 26 run tellraw @a [{"selector":"@s"},{"text":"is more dead than Penguin Strategy","color":"gold"}]
execute if score .randomize tmp matches 27 run tellraw @a [{"selector":"@s"},{"text":"ran /kill @s","color":"gold"}]
execute if score .randomize tmp matches 28 run tellraw @a [{"selector":"@s"},{"text":"could easily have avoided that","color":"gold"}]
execute if score .randomize tmp matches 29 run tellraw @a [{"selector":"@s"},{"text":"thinks you should all /vote","color":"gold"}]
execute if score .randomize tmp matches 30 run tellraw @a [{"selector":"@s"},{"text":"is more dead than a Legitimoose player's sleep schedule","color":"gold"}]
execute if score .randomize tmp matches 31 run tellraw @a [{"selector":"@s"},{"text":"should have stuck to making sky block let's plays","color":"gold"}]
execute if score .randomize tmp matches 32 run tellraw @a [{"selector":"@s"},{"text":"should have grinded off camera a bit more","color":"gold"}]
execute if score .randomize tmp matches 33 run tellraw @a [{"selector":"@s"},{"text":"was shaped like a deer","color":"gold"}]
execute if score .randomize tmp matches 34 run tellraw @a [{"selector":"@s"},{"text":"needs to lock in","color":"gold"}]
execute if score .randomize tmp matches 35 run tellraw @a [{"selector":"@s"},{"text":"fought valiantly","color":"gold"}]
execute if score .randomize tmp matches 36 run tellraw @a [{"selector":"@s"},{"text":"paid to lose","color":"gold"}]
execute if score .randomize tmp matches 37 run tellraw @a [{"selector":"@s"},{"text":"ragequitbirdbaitmolded","color":"gold"}]
execute if score .randomize tmp matches 38 run tellraw @a [{"selector":"@s"},{"text":"was deleted from existence","color":"gold"}]
execute if score .randomize tmp matches 39 run tellraw @a [{"selector":"@s"},{"text":"failed the quick-time event","color":"gold"}]
execute if score .randomize tmp matches 40 run tellraw @a [{"selector":"@s"},{"text":"got caught lacking","color":"gold"}]
execute if score .randomize tmp matches 41 run tellraw @a [{"selector":"@s"},{"text":"pressed the wrong button","color":"gold"}]
execute if score .randomize tmp matches 42 run tellraw @a [{"selector":"@s"},{"text":"was not the main character","color":"gold"}]
execute if score .randomize tmp matches 43 run tellraw @a [{"selector":"@s"},{"text":"ran out of plot armor","color":"gold"}]
execute if score .randomize tmp matches 44 run tellraw @a [{"selector":"@s"},{"text":"accidentally speedran death","color":"gold"}]
execute if score .randomize tmp matches 45 run tellraw @a [{"selector":"@s"},{"text":"let their guard down","color":"gold"}]



gamemode adventure @s
team join spawn @s
function code:leaderboard/death