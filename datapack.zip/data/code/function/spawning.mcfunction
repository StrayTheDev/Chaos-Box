$spreadplayers 0 0 1 20 under $(y) true @s
effect give @s resistance 10 100 true
effect give @s slow_falling 10 0 true
team join pvp @s
