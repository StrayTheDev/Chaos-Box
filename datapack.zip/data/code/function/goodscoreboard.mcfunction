scoreboard objectives remove SidebarScoreboard
scoreboard objectives add SidebarScoreboard dummy
scoreboard objectives setdisplay sidebar SidebarScoreboard
scoreboard objectives modify SidebarScoreboard displayname {"text":"Natural Disaster","bold": true,"color": "green"}
scoreboard objectives setdisplay sidebar SidebarScoreboard
scoreboard players add Time SidebarScoreboard 1
team add TimeStuffix
team modify TimeStuffix suffix ":"
team join TimeStuffix Time

#$scoreboard players add $(min) SidebarScoreboard 0
#team add SecStuffix
#$team modify SecStuffix suffix ":$(sec)"
#$team join SecStuffix $(min)
#$scoreboard players add $(min)#