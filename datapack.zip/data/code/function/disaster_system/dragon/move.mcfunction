$execute facing $(x) $(y) $(z) run tp @s ^ ^ ^1
$rotate @s facing $(x) $(y) $(z)