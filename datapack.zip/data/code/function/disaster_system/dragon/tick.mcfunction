execute store result score random tmp run random value 1..50
execute as @e[type=ender_dragon] at @s if score random tmp matches 1 run function code:disaster_system/dragon/lock
execute as @e[type=ender_dragon] at @s run function code:disaster_system/dragon/move with storage code:dragon_lock