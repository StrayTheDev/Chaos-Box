execute store result score y tmp run data get entity @r Pos[1]
execute store result score x tmp run random value 1..2
execute store result score z tmp run random value 1..2
execute if score x tmp matches 1 run scoreboard players set x tmp -15
execute if score x tmp matches 2 run scoreboard players set x tmp 15
execute if score z tmp matches 1 run scoreboard players set z tmp -15
execute if score z tmp matches 2 run scoreboard players set z tmp 15
execute store result storage code:dragon_lock x int 1.0 run scoreboard players get x tmp
execute store result storage code:dragon_lock y int 1.0 run scoreboard players get y tmp
execute store result storage code:dragon_lock z int 1.0 run scoreboard players get z tmp