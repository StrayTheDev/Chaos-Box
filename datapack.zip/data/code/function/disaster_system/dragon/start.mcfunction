summon ender_dragon 0 0 50
execute as @e[type=ender_dragon] run function code:disaster_system/dragon/lock