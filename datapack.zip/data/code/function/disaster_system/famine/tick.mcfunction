# Old name: hunger255
effect give @a[team=pvp] hunger 1 1 true