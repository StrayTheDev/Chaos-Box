fill 25 -64 -25 25 300 24 bedrock
fill -25 -64 -25 -25 300 24 bedrock
schedule clear code:disaster_system/bergentruck/start