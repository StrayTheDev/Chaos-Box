execute as @e[tag=truck] at @s run clone 85 4 -19 93 7 -15 ~ ~ ~-2
execute as @e[tag=truck] at @s run tp @s ~-1 ~ ~
execute as @e[tag=truck] at @s run fill ~10 ~ ~-1 ~10 ~2 ~1 air
execute at @e[tag=truck] positioned ~-2 ~ ~ as @a[distance=..3] run damage @s 2 out_of_world at ~ ~ ~
execute at @e[tag=truck] positioned ~-2 ~ ~ as @a[distance=..3] run data merge entity @s {Motion:[-0.8,0.4,0.0]}
execute positioned -40.00 -64.0 -30.0 if entity @e[dx=5,dy=300,dz=50,tag=truck] run fill -26 -64 -25 -35 300 24 air
execute positioned -40.00 -64.0 -30.0 run kill @e[dx=5,dy=300,dz=50,tag=truck]
fill 25 -64 -25 25 300 24 black_concrete replace air
fill -25 -64 -25 -25 300 24 black_concrete replace air