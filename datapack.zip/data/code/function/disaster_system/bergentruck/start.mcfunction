summon marker 0 0 0 {Tags:[truck]}
execute as @e[tag=truck] run data modify entity @s Pos[1] set from entity @r[team=pvp] Pos[1]
execute as @e[tag=truck] run data modify entity @s Pos[2] set from entity @r[team=pvp] Pos[2]
execute as @e[tag=truck] at @s run tp @s 24 ~ ~
execute as @e[tag=truck] at @s facing 24 ~ 0 run tp @s ^ ^ ^2
execute as @e[tag=truck] at @s run playsound minecraft:item.mace.smash_ground_heavy block @a ~ ~ ~ 10
schedule function code:disaster_system/bergentruck/start 6s
