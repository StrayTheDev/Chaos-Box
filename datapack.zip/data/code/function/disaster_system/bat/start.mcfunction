summon bat 0 0 0 {Health:1,attributes:[{id:"minecraft:scale",base:5}],DeathLootTable:"minecraft:chaos_box"}
spreadplayers 0 0 10 10 false @e[type=bat]