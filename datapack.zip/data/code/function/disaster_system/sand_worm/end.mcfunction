kill @e[tag=worm]
fill -25 -64 -25 27 200 27 air replace test_block