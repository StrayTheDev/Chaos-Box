execute at @e[tag=worm] run setblock ~ ~ ~ test_block[mode=fail]
execute as @e[tag=worm] at @s if block ~ ~ ~ bedrock run kill @s