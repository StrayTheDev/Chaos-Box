summon marker 0 0 0 {Tags:[spread]}
spreadplayers 0 0 24 24 false @e[tag=spread]


execute at @e[tag=spread] run summon minecraft:hoglin ~ ~ ~ {Team:"msg",IsImmuneToZombification:true,Passengers:[{id:"minecraft:piglin",IsImmuneToZombification:true,equipment:{mainhand:{id:"minecraft:crossbow",count:1}},Team:"msg"}]}
execute at @e[tag=spread] run summon minecraft:hoglin ~ ~ ~ {Team:"msg",IsImmuneToZombification:true,Passengers:[{id:"minecraft:piglin",IsImmuneToZombification:true,equipment:{mainhand:{id:"minecraft:crossbow",count:1}},Team:"msg"}]}
execute at @e[tag=spread] run summon minecraft:hoglin ~ ~ ~ {Team:"msg",IsImmuneToZombification:true,Passengers:[{id:"minecraft:piglin_brute",IsImmuneToZombification:true,equipment:{mainhand:{id:"minecraft:golden_axe",count:1}, offhand:{id:"minecraft:golden_axe",count:1}},Team:"msg"}]}

kill @e[tag=spread]