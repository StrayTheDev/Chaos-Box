summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
summon spider 0 0 0 {Tags:["small","spread"],DeathLootTable:"minecraft:empty",attributes:[{base:0.1,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"},{base:0,id:"minecraft:jump_strength"}]}
spreadplayers 0 0 25 25 true @e[tag=spread]
tag @e[tag=spread] remove spread
time set midnight