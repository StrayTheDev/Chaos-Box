execute store result score random tmp run random value 0..10
execute if score random tmp matches 0 run summon tnt 0 0 0 {Tags:[spread],fuse:100,block_state:{Name:"chain_command_block"}}
execute as @e[tag=spread] at @s run function code:disaster_system/.misc/randomize_pos
tag @e[tag=spread] remove spread
execute as @e[type=tnt] at @s unless block ~ ~-3 ~ minecraft:air if block ~ ~ ~-0.1 air run summon area_effect_cloud ~ ~ ~ {custom_particle:{type:glow_squid_ink},Radius:1,RadiusPerTick:0.1,Duration:100,potion_contents:{custom_color:8439689,potion:poison,custom_effects:[{id:poison,duration:200,amplifier:2,show_particles:1b,show_icon:true},{id:hunger,duration:200,amplifier:2,show_particles:1b,show_icon:true},{id:nausea,duration:60,amplifier:0,show_particles:1b,show_icon:true},{id:darkness,duration:60,amplifier:0,show_particles:1b,show_icon:true}]}}
execute as @e[type=tnt] at @s unless block ~ ~-3 ~ minecraft:air if block ~ ~ ~-0.1 air run data merge entity @s {fuse:0}
execute as @e[type=area_effect_cloud] as @s run kill @e[type=area_effect_cloud,distance=0.1..0.5]