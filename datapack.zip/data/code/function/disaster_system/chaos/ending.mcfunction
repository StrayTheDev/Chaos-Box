scoreboard players set .timer tmp 200
gamerule randomTickSpeed 10
tellraw @a [{"text":"a","obfuscated":true},{"text":"BYE BYE!","color":"light_purple","bold":true,"obfuscated":false},{"text":"a","obfuscated":true}]

execute as @a run function big_shot_loop:stop
worldborder warning distance 0
scoreboard players set chaos tmp 0


fill 0 100 -50 0 102 -50 air

function code:disaster_system/load_disasters