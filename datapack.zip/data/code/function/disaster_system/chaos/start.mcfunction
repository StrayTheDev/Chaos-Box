scoreboard players set .timer tmp 20
scoreboard players set .timer disasters 0
gamerule randomTickSpeed 0
schedule function code:disaster_system/chaos/ending 60s
tellraw @a [{"text":"a","obfuscated":true},{"text":"CHAOS, CHAOS!","color":"light_purple","bold":true,"obfuscated":false},{"text":"a","obfuscated":true}]

execute as @a run function big_shot_loop:stop
execute as @a run function big_shot_loop:play
worldborder warning distance 999999
scoreboard players set chaos tmp 1

#fill 0 100 -50 0 101 -50 minecraft:repeating_command_block{auto:true,Command:"function code:disaster_system/randomizer/tick1 with storage code:disaster_system"}

data merge storage code:disaster_system {disasters:[\
{id:"australia", name:"Australia", "difficulty":"hard", description:"She comes from a land down under...", color:"gold"},\
{id:"acid_rain", name:"Acid Rain", difficulty:"hard", description:"Get under something", color:"aqua"},\
{id:"spiders", name:"Arachnophobia", difficulty:"impossible", description:"Spiders, spiders everywhere!", color:"aqua"},\
{id:"tnt_rain", name:"Tnt Rain", difficulty:"impossible", description:"TNT rains from the sky, a classic", color:"aqua"},\
{id:"tnt_rain_reverse", name:"Reverse Tnt Rain", difficulty:"hard", description:"TNT rains from below the map... for some reason", color:"aqua"},\
{id:"tnt_rain_sideways", name:"Sideways Tnt Rain", difficulty:"impossible", description:"TNT rains from ... the walls?", color:"aqua"},\
{id:"raid", name:"Illager Raid", difficulty:"hard", description:"Illagers start a raid", color:"yellow"},\
{id:"zombie_apocalypse", name:"Zombie Apocalypse", difficulty:"hard", description:"The dead rise, won't you join them?", color:"aqua"},\
{id:"slime", name:"Big Slime", difficulty:"hard", description:"Trust me, it's large", color:"aqua"},\
{id:"nuke", name:"Bob the Nuke", difficulty:"medium", description:"He just wants a hug ☹", color:"aqua"},\
{id:"surface", name:"Swappage", difficulty:"normal", description:"Get randomly teleported around the map", color:"aqua"},\
{id:"warden", name:"Peak Stealth Gameplay", difficulty:"medium", description:"truly the peakest of stealth gameplays", color:"aqua"},\
{id:"meteor_shower", name:"⚠ Meteor Shower Incoming! ⚠", difficulty:"impossible", description:"Will kill you and your ears", color:"red"},\
{id:"zeus", name:"Zeus's Wrath", difficulty:"impossible", description:"Zeus Shall Smite You!", color:"gold"},\
{id:"amogus", name:"Sus Amongus", difficulty:"medium", description:"amogus ඞ", color:"red"},\
{id:"meltdown", name:"Nuclear Meltdown (B.O.B. Inc.)", difficulty:"medium", description:"B.O.B. Inc. dumps excess nuclear waste into the map", color:"aqua"},\
{id:"wind", name:"A Windy Day", difficulty:"medium", description:"♬ I Believe I can Flyyyyyy ♬", color:"aqua"},\
{id:"tnt", name:"Keep Moving!", difficulty:"hard", description:"...or DIE", color:"red"},\
{id:"cave_in", name:"Cave In", difficulty:"normal", description:"Blocks around you collapse", color:"aqua"},\
{id:"diy", name:"DIY Chaos", difficulty:"normal", description:"I'm too lazy to make good events, make your own chaos", color:"aqua"},\
{id:"kelp_expand", name:"The Kelp Expanding", difficulty:"normal", description:"🌿 The kelp will consume us all! 🌿", color:"aqua"},\
{id:"pufferfish_bombs", name:"Aquatic Airstrike", difficulty:"hard", description:"⚠ Pufferfish Incoming ⚠", color:"aqua"},\
{id:"abduction", name:"Alien Abduction", difficulty: "hard", description: "take me to your leader", "color": "aqua"},\
{id:"supernova", name:"☄ SUPERNOVA ☄", difficulty: "hard", description: "the power of a dying star", "color": "light_purple"},\
{id:"magma", name:"Magma Hydra", difficulty: "medium", description: "Exponential growth functions, anyone?", "color": "aqua"},\
{id:"creaking", name:"Creaking Angels", difficulty: "hard", description: "don't blink.", "color": "aqua"},\
{id:"corruption", name:"Sculk Corruption", difficulty: "normal", description: "Beware the Warden", "color": "aqua"},\
{id:"lavachicken", name:"Lava Chicken", difficulty: "normal", description: "CHICKEN JOCKEY", "color": "aqua"},\
{id:"ghast", name:"Ghasts", difficulty: "hard", description: "It's a Balloon?", "color": "aqua"},\
{id:"probros_attempt", name:"Home Infestation", difficulty: "medium", description: "Coming straight from YOUR house!", "color": "aqua"},\
{id:"immortal_snail", name:"Immortal Snail", difficulty: "hard", description: "It will chase you to the ends of the earth", "color": "aqua"},\
{id:"laser_pointere", name:"Laser Pointere", difficulty: "hard", description: "So I haveth a laser pointere...", "color": "aqua"},\
{id:"sunburn", name:"Sunburn", difficulty: "medium", description: "Burn in the Daylight", "color": "aqua"},\
{id:"lasers", name:"Laser Face", difficulty:"medium", description:"shoot a laser from your face", color:"aqua"},\
{id:"flood", name:"Flood Risk", difficulty:"hard", description:"Stay out of the water", color:"aqua"},\
{id:"worldborder", name:"World Border", difficulty:"medium", description:"Avoid the incoming wall", color:"aqua"},\
{id:"sinkhole", name:"Sinkhole", difficulty:"medium", description:"somebody forgot to check if the foundation was stable", color:"aqua"},\
{id:"crystals", name:"Crystal Ritual", difficulty:"medium", description:"Try not to interrupt it", color:"aqua"},\
{id:"bergentruck", name:"Bergentrück", difficulty:"hard", description:"DRIVING IN MY CAR, RIGHT AFTER A BEER!", color:"gold"},\
{id:"withers", name:"Wither Apocalypse", difficulty: "impossible", description: "Nowhere is safe.", "color": "aqua"},\
]}
#the number of disasters is (<number of this line> - 10)
# can confirm - Ragebird7200

execute store result storage code:disaster_system disasters_len int 1 run data get storage code:disaster_system disasters