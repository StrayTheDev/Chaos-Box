time set midnight
# Summon 50 zombies
kill @e[tag=apocalypse]

summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Roosevelt"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Strategist272"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Ebony"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Noah"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Thelma"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Gale"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Beatrice"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Marvin"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Sergio"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Annette"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Grover"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Janelle"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Nathaniel"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Julie"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Arturo"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Hilton"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Graig"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Dana"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Chasity"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Jeffry"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Dianna"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Lolita"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Jeramy"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Abby"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Arnulfo"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Judson"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"John"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Elisha"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Claudio"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Maricela"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Branden"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Lester"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Nona"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Josie"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Harriet"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Clemente"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Thaddeus"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Pansy"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Shad"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Gerard"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Keisha"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Marci"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Gregorio"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"aaTimmya"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Veronica"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Tonia"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Johanna"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Marco"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"William"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Darwin"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Leroy"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Spamton G. Spamton"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"idk the grave was unmarked"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"A zombie"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Dani"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"The Sanity of Strategist272"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"sans. sans the skeleton."}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Jojo"}}
summon minecraft:zombie 0 0 0 {Tags:["apocalypse"],equipment:{head:{id:"minecraft:leather_helmet",count:1b}},CustomName:{"text":"Some Dead Guy"}}

spreadplayers 0 0 0 25 false @e[tag=apocalypse]