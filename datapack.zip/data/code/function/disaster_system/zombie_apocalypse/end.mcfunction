time set 3000
execute as @e[tag=apocalypse] run data merge entity @s {equipment:{feet:{}, legs:{}, chest:{}, head:{count:0,id:air}}}