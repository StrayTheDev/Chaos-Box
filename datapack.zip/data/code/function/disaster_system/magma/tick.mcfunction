execute as @e[type=magma_cube] run data merge entity @s {Size:2,Invulnerable:true}
execute as @e[type=magma_cube] run data modify entity @s Health set value 200
execute store result score random tmp run random value 0..30
execute if score random tmp matches 0 run kill @e[type=magma_cube,limit=1,sort=random]