execute as @e[type=magma_cube] run data merge entity @s {Invulnerable:false}
kill @e[type=magma_cube]
kill @e[type=magma_cube]
kill @e[type=magma_cube]