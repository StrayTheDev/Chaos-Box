function code:disaster_system/diy/start
