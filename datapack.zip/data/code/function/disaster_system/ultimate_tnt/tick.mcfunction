function code:disaster_system/tnt/tick
function code:disaster_system/tnt_rain/tick
function code:disaster_system/tnt_rain_reverse/tick
function code:disaster_system/tnt_rain_sideways/tick

summon creeper 0 0 0 {Tags:["small","spread"],DeathLootTable:"",attributes:[{base:0.7,id:"minecraft:scale"},{base:1,id:"minecraft:max_health"}]}
spreadplayers 0 0 0 25 false @e[tag=spread]
tag @e[tag=spread] remove spread