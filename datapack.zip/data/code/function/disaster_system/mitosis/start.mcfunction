execute positioned 0 0 0 positioned over motion_blocking run summon shulker ~ ~ ~

scoreboard players set mitosis tmp 0
scoreboard players set speed tmp 60