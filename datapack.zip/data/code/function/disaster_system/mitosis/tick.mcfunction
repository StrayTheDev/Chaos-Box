scoreboard players add mitosis tmp 1
scoreboard players operation mitosis tmp %= speed tmp

execute if score mitosis tmp matches 2 at @e[type=shulker] run summon shulker ~ ~ ~ {DeathLootTable:"entities/bat"}

execute as @e[type=shulker] at @s if entity @e[type=shulker,distance=0.1..1.5] run tp @s 0 -500 0