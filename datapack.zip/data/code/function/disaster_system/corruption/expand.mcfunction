summon marker ~1 ~ ~ {Tags:[expand]}
summon marker ~-1 ~ ~ {Tags:[expand]}
summon marker ~ ~1 ~ {Tags:[expand]}
summon marker ~ ~-1 ~ {Tags:[expand]}
summon marker ~ ~ ~1 {Tags:[expand]}
summon marker ~ ~ ~-1 {Tags:[expand]}