fill -25 -63 -25 25 319 25 minecraft:air replace minecraft:dried_kelp_block
kill @e[x=-25,dx=50,y=-100,dy=400,z=-25,dz=50,type=marker]