scoreboard players add corruption tmp 1
scoreboard players operation corruption tmp %= speed tmp

kill @e[tag=expand,y=-70,dy=6]

execute as @e[tag=expand] at @s if block ~ ~ ~ bedrock run kill @s
execute if score corruption tmp matches 2 as @e[tag=expand] at @s run setblock ~ ~ ~ sculk
execute as @e[tag=expand] at @s if block 25 ~ -26 minecraft:bedrock run kill @s
execute as @e[tag=expand] at @s if block 25 ~ -26 minecraft:barrier run kill @s
execute as @e[tag=expand] at @s if block ~ ~ ~ air run kill @s
execute if score corruption tmp matches 2 as @e[tag=expand,limit=50,sort=random] at @s run function code:disaster_system/corruption/expand
execute as @e[tag=expand] at @s if block ~ ~ ~ sculk run kill @s