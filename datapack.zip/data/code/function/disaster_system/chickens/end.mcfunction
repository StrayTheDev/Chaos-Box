kill @e[type=vindicator]
kill @e[type=chicken]