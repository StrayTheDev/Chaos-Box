kill @e[type=!player,tag=!safe]
function code:reload_displays