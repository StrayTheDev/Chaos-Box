




# MAKE SURE THE id MATCHES WITH THE FUNCTIONS PATHS!!! For example, the start functions will be called as (id)/start !!!
data merge storage code:disaster_system_double {disasters:[\
{id:"acid_rain", name:"Acid Rain", difficulty:"hard", description:"Get under something", color:"aqua"},\
{id:"tnt_rain", name:"Tnt Rain", difficulty:"impossible", description:"TNT rains from the sky, a classic", color:"aqua"},\
{id:"tnt_rain_reverse", name:"Reverse Tnt Rain", difficulty:"hard", description:"TNT rains from below the map... for some reason", color:"aqua"},\
{id:"tnt_rain_sideways", name:"Sideways Tnt Rain", difficulty:"impossible", description:"TNT rains from ... the walls?", color:"aqua"},\
{id:"virus", name:"Covid-19", difficulty:"medium", description:"Social distancing is required for this event", color:"aqua"},\
{id:"zombie_apocalypse", name:"Zombie Apocalypse", difficulty:"hard", description:"The dead rise, won't you join them?", color:"aqua"},\
{id:"tsunami_lava", name:"Lava Rises", difficulty:"medium", description:"Get to the high ground", color:"aqua"},\
{id:"bees", name:"Swarm", difficulty:"hard", description:"RELEASE THE BEES!", color:"aqua"},\
{id:"warden", name:"Peak Stealth Gameplay", difficulty:"medium", description:"truly the peakest of stealth gameplays", color:"aqua"},\
{id:"meteor_shower", name:"⚠ Meteor Shower Incoming! ⚠", difficulty:"impossible", description:"Will kill you and your ears", color:"red"},\
{id:"zeus", name:"Zeus's Wrath", difficulty:"impossible", description:"L Bozo get smitten", color:"gold"},\
{id:"snow", name:"Blizzard", difficulty:"normal", description:"MERRY CHRISTMAS!", color:"aqua"},\
{id:"wither_rain", name:"Withering Rain", difficulty:"medium", description:"Acid rain but more deadly", color:"aqua"},\
{id:"meltdown", name:"Nuclear Meltdown (B.O.B. Inc.)", difficulty:"medium", description:"B.O.B. Inc. dumps excess nuclear waste into the map", color:"aqua"},\
{id:"wind", name:"A Windy Day", difficulty:"medium", description:"♬ I Believe I can Flyyyyyy ♬", color:"aqua"},\
{id:"3hm", name:"3 Heart Mode", difficulty:"hard", description:"New hardcore challenge just dropped?", color:"aqua"},\
{id:"tnt", name:"Keep Moving!", difficulty:"hard", description:"...or DIE", color:"red"},\
{id:"time_slow", name:"Time Dilation", difficulty:"medium", description:"Penguin Strategy troop speed be like:", color:"aqua"},\
{id:"roots", name:"Roots in the Sky", difficulty:"normal", description:"Strange roots overtake the map", color:"aqua"},\
{id:"kelp_expand", name:"The Kelp Expanding", difficulty:"normal", description:"🌿 The kelp will consume us all! 🌿", color:"aqua"},\
{id:"mitosis", name:"Cellular Mitosis", difficulty:"medium", description:"The Box becomes a life-sized Petri Dish (Shulker Edition)", color:"aqua"},\
{id:"shuffle", name:"World Corruption", difficulty:"normal", description:"what on earth is going on here", color:"aqua"},\
{id:"black_hole", name:"Black Hole", difficulty: "hard", description: "The event horizon approaches", "color": "black"},\
{id:"abduction", name:"Alien Abduction", difficulty: "hard", description: "take me to your leader", "color": "aqua"},\
{id:"supernova", name:"☄ SUPERNOVA ☄", difficulty: "hard", description: "the power of a dying star", "color": "light_purple"},\
{id:"magma", name:"Magma Hydra", difficulty: "medium", description: "Exponential growth functions, anyone?", "color": "aqua"},\
{id:"creaking", name:"Creaking Angels", difficulty: "hard", description: "don't blink.", "color": "aqua"},\
{id:"ghast", name:"Ghasts", difficulty: "hard", description: "It's a Balloon?", "color": "aqua"},\
{id:"probros_attempt", name:"Home Infestation", difficulty: "medium", description: "Infesting", "color": "aqua"},\
{id:"immortal_snail", name:"Immortal Snail", difficulty: "hard", description: "It will chase you to the ends of the earth", "color": "aqua"},\
{id:"laser_pointere", name:"Laser Pointere", difficulty: "hard", description: "So I haveth a laser pointere...", "color": "aqua"},\
{id:"frogs", name:"All-Eating Frogs", difficulty:"medium", description:"Devourers of all that moves", color:"aqua"},\
{id:"dragon", name:"A.D.H.D.", difficulty:"hard", description:"Attention-Deficient Hyperactive Dragon", color:"dark_purple"},\
{id:"sunburn", name:"Sunburn", difficulty: "medium", description: "Burn in the Daylight", "color": "aqua"},\
{id:"bergentruck", name:"Bergentrück", difficulty:"hard", description:"DRIVING IN MY CAR, RIGHT AFTER A BEER!", color:"gold"},\
]}




execute store result storage code:disaster_system_double disasters_len int 1 run data get storage code:disaster_system_double disasters
function code:disaster_system/double/start_next with storage code:disaster_system_double

function code:disaster_system/double/message with storage code:event.double disaster_1
function code:disaster_system/double/message with storage code:event.double disaster_2