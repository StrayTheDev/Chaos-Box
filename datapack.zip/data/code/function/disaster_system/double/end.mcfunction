function code:disaster_system/randomizer/end2 with storage code:event.double disaster_1
function code:disaster_system/randomizer/end2 with storage code:event.double disaster_2

data remove storage code:event.double disaster_1
data remove storage code:event.double disaster_2