$data modify storage code:event.double disaster_1 set from storage code:disaster_system_double disasters[$(disaster_1)]
$data modify storage code:event.double disaster_2 set from storage code:disaster_system_double disasters[$(disaster_2)]

execute store result score randoom tmp run random value 1..10
execute if score random tmp matches 1 run data modify storage code:event.double disaster_1 set value {id:"supernova", name:"☄ SUPERNOVA ☄", difficulty: "hard", description: "the power of a dying star", "color": "light_purple"}
execute if score random tmp matches 1 run data modify storage code:event.double disaster_2 set value {id:"black_hole", name:"Black Hole", difficulty: "hard", description: "The event horizon approaches", "color": "black"}

execute if score random tmp matches 2 run data modify storage code:event.double disaster_1 set value {id:"warden", name:"Peak Stealth Gameplay", difficulty:"medium", description:"truly the peakest of stealth gameplays", color:"aqua"}
execute if score random tmp matches 2 run data modify storage code:event.double disaster_2 set value {id:"laser_pointere", name:"Laser Pointere", difficulty: "hard", description: "So I haveth a laser pointere...", "color": "aqua"}

execute if score random tmp matches 3 run data modify storage code:event.double disaster_1 set value {id:"mitosis", name:"Cellular Mitosis", difficulty:"medium", description:"The Box becomes a life-sized Petri Dish (Shulker Edition)", color:"aqua"}
execute if score random tmp matches 3 run data modify storage code:event.double disaster_2 set value {id:"roots", name:"Roots in the Sky", difficulty:"normal", description:"Strange roots overtake the map", color:"aqua"}

execute if score random tmp matches 4 run data modify storage code:event.double disaster_1 set value {id:"meteor_shower", name:"⚠ Meteor Shower Incoming! ⚠", difficulty:"impossible", description:"Will kill you and your ears", color:"red"}
execute if score random tmp matches 4 run data modify storage code:event.double disaster_2 set value {id:"zeus", name:"Zeus's Wrath", difficulty:"impossible", description:"L Bozo get smitten", color:"gold"}

execute if score random tmp matches 5 run data modify storage code:event.double disaster_1 set value {id:"tsunami_lava", name:"Lava Rises", difficulty:"medium", description:"Get to the high ground", color:"aqua"}
execute if score random tmp matches 5 run data modify storage code:event.double disaster_2 set value {id:"tsunami_water", name:"Tsunami", difficulty:"normal", description:"Please stop swimming to the top and dying it happens every time", color:"aqua"}
