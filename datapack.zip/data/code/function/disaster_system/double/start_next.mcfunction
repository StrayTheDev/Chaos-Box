$execute store result score .randomize disasters run random value 1..$(disasters_len)
scoreboard players remove .randomize disasters 1
execute store result storage code:event.double disaster_1 int 1 run scoreboard players get .randomize disasters

$execute store result score .randomize disasters run random value 1..$(disasters_len)
scoreboard players remove .randomize disasters 1
execute store result storage code:event.double disaster_2 int 1 run scoreboard players get .randomize disasters

function code:disaster_system/double/select_random with storage code:event.double