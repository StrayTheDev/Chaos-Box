function code:disaster_system/randomizer/tick2 with storage code:event.double disaster_1
function code:disaster_system/randomizer/tick2 with storage code:event.double disaster_2
