# - By Ap
summon marker 0 50 0 {Tags:["SummonLightning"]}

spreadplayers 0 0 1 24 false @e[tag=SummonLightning]
execute as @e[tag=SummonLightning] at @s run tp @s ~ ~30 ~
execute as @e[tag=SummonLightning] at @s run summon lightning_bolt ~ ~-30 ~
execute as @e[tag=SummonLightning] at @s run kill @s
