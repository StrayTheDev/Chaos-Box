execute store result score random tmp run random value 1..15
execute if score random tmp matches 1 run summon axolotl 0 0 0 {Tags:[spread],attributes:[{Name:"max_health",Base:1.0}],Passengers:[{id:"minecraft:pufferfish",Invulnerable:true},{id:"minecraft:pufferfish",Invulnerable:true},{id:"minecraft:pufferfish",Invulnerable:true},{id:"minecraft:pufferfish",Invulnerable:true},{id:"minecraft:pufferfish",Invulnerable:true},{id:"minecraft:pufferfish",Invulnerable:true},{id:"minecraft:pufferfish",Invulnerable:true},{id:"minecraft:pufferfish",Invulnerable:true},{id:"minecraft:pufferfish",Invulnerable:true},{id:"minecraft:pufferfish",Invulnerable:true}]}
execute as @e[tag=spread] at @s run function code:disaster_system/.misc/randomize_pos
tag @e[tag=spread] remove spread
