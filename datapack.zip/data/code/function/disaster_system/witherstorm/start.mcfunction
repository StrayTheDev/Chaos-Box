summon marker 0 10 27 {Tags:[witherstorm-base]}
execute positioned 0 10 40 run function code:models/witherstorm
execute positioned 0 10 40 run function code:models/witherstorm_head
execute as @e[tag=witherstorm-head] run rotate @s facing 0 0 0
summon marker 0.0 0.0 0.0 { UUID: [I;12,-34,56,-78], Tags:["safe"] }


effect give @a darkness 2
summon minecraft:wither 0 400 0 {NoAI:1b,Invulnerable:1b,CustomName:'Wither Storm'}
scoreboard players set 8 tmp 8
scoreboard players operation .timer tmp *= 8 tmp

