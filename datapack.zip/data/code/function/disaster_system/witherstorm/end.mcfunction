execute at @e[tag=witherstorm-head-base] run summon tnt ~ ~ ~ {fuse:1}
execute at @e[tag=witherstorm-head-1] run summon ender_dragon ~ ~ ~ {Health:0}
kill @e[type=wither]
kill @e[tag=witherstorm]
kill @e[tag=witherstorm-base]
kill @e[tag=witherstorm-head]
kill @e[tag=witherstorm-head-base]
execute as @e[type=block_display,tag=event.black_hole_block] at @s run function code:disaster_system/.misc/raycast/replace_falling_block with entity @s block_state
kill 0000000c-ffff-ffde-0000-0038ffffffb2
function code:reload_displays

fill -25 -64 25 -25 128 -25 bedrock
fill 25 -64 25 25 128 -25 bedrock
fill -25 -64 -25 25 128 -25 bedrock
fill 25 -64 25 -25 128 25 bedrock
fill 4 7 -25 -4 4 -25 minecraft:barrier

