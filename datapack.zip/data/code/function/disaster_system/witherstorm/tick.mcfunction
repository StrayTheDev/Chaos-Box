execute as @e[tag=witherstorm] positioned as @e[tag=witherstorm-base] run tp @s ~ ~ ~
execute as @e[tag=witherstorm-head-1] positioned as @e[tag=witherstorm] run tp @s ~ ~ ~
execute as @e[tag=witherstorm-head-2] positioned as @e[tag=witherstorm] run tp @s ~-5 ~ ~2
execute as @e[tag=witherstorm-head-3] positioned as @e[tag=witherstorm] run tp @s ~5 ~ ~2


execute store result score random tmp run random value 1..100
execute if score random tmp matches 1..5 as @e[tag=witherstorm-head-base,limit=1,sort=random] at @r[team=pvp] on passengers run rotate @s facing ~ ~ ~
execute as @e[tag=witherstorm-base] at @s run tp @s ~ ~ ~-0.02

execute as @e[type=marker,tag=witherstorm-base] store result entity @s Rotation[0] float 1 run random value -180..180
execute as @e[type=marker,tag=witherstorm-base] store result entity @s Rotation[1] float 1 run random value -90..90
execute as @e[type=marker,tag=witherstorm-base] at @s run function code:disaster_system/.misc/raycast/raycast
execute as @e[type=marker,tag=witherstorm-base] store result entity @s Rotation[0] float 1 run random value -180..180
execute as @e[type=marker,tag=witherstorm-base] store result entity @s Rotation[1] float 1 run random value -90..90
execute as @e[type=marker,tag=witherstorm-base] at @s run function code:disaster_system/.misc/raycast/raycast
execute as @e[type=marker,tag=witherstorm-base] store result entity @s Rotation[0] float 1 run random value -180..180
execute as @e[type=marker,tag=witherstorm-base] store result entity @s Rotation[1] float 1 run random value -90..90
execute as @e[type=marker,tag=witherstorm-base] at @s run function code:disaster_system/.misc/raycast/raycast
execute as @e[type=marker,tag=witherstorm-base] store result entity @s Rotation[0] float 1 run random value -180..180
execute as @e[type=marker,tag=witherstorm-base] store result entity @s Rotation[1] float 1 run random value -90..90
execute as @e[type=marker,tag=witherstorm-base] at @s run function code:disaster_system/.misc/raycast/raycast
execute as @e[type=marker,tag=witherstorm-base] store result entity @s Rotation[0] float 1 run random value -180..180
execute as @e[type=marker,tag=witherstorm-base] store result entity @s Rotation[1] float 1 run random value -90..90
execute as @e[type=marker,tag=witherstorm-base] at @s run function code:disaster_system/.misc/raycast/raycast
execute as @e[type=marker,tag=witherstorm-base] store result entity @s Rotation[0] float 1 run random value -180..180
execute as @e[type=marker,tag=witherstorm-base] store result entity @s Rotation[1] float 1 run random value -90..90
execute as @e[type=marker,tag=witherstorm-base] at @s run function code:disaster_system/.misc/raycast/raycast

execute as @e[tag=witherstorm-head,limit=1,sort=random] at @s run function code:disaster_system/witherstorm/raycast
execute as @e[tag=witherstorm-head] run data merge entity @s {teleport_duration:10}

execute as @e[type=block_display,tag=event.black_hole_block] at @s run tp @s ^ ^ ^1 facing entity @n[type=marker,tag=witherstorm-base]
execute as @e[type=block_display,tag=event.black_hole_block] at @s if entity @e[tag=witherstorm-base,distance=..3] run kill @s

execute at @e[tag=witherstorm-head-base] as @e[type=!block_display,type=!marker,distance=..5] run damage @s 5 wither by @n[tag=witherstorm-head-base]

execute at @e[tag=witherstorm-head-base] run playsound entity.bee.loop master @a ~ ~ ~ 1 0.1 0.1
particle minecraft:ash 0 40 0 12 50 12 0 10000 normal @a[team=pvp]