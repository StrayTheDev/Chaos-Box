# 0000000c-ffff-ffde-0000-0038ffffffb2
execute unless entity @n[tag=witherstorm-head-base] run return fail

execute at @s facing entity @n[tag=witherstorm-head-base] feet positioned 0.0 0.0 0.0 as 0000000c-ffff-ffde-0000-0038ffffffb2 run tp @s ^ ^ ^0.4 ~ ~

data modify entity @s Motion set from entity 0000000c-ffff-ffde-0000-0038ffffffb2 Pos