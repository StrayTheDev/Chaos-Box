execute as @e[type=turtle] at @s run rotate @s ~6 ~
