kill @e[type=turtle]
kill @e[type=blaze]