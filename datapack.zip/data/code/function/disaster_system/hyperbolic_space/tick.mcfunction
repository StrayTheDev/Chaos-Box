execute if score h.x.i tmp >= h.x.m tmp run scoreboard players operation h.x.c tmp = h.x.i tmp
execute if score h.x.i tmp >= h.x.m tmp run scoreboard players operation h.x.c tmp *= h.x.i tmp
execute if score h.x.i tmp >= h.x.m tmp run scoreboard players operation h.x.c tmp += h.r.l tmp
execute if score h.x.i tmp >= h.x.m tmp run scoreboard players operation h.x.c tmp /= h.c.s tmp
execute if score h.x.i tmp >= h.x.m tmp run scoreboard players operation h.x.c tmp /= h.t.t tmp
execute if score h.x.i tmp >= h.x.m tmp run scoreboard players operation h.x.c tmp += h.m.h tmp
execute if score h.x.i tmp >= h.x.m tmp store result storage code:hyperbolic ax double 1 run scoreboard players get h.x.i tmp
execute if score h.x.i tmp >= h.x.m tmp store result storage code:hyperbolic ix double 1 run scoreboard players get h.x.i tmp
execute if score h.x.i tmp >= h.x.m tmp store result storage code:hyperbolic az double 1 run scoreboard players get h.c.s tmp
execute if score h.x.i tmp >= h.x.m tmp store result storage code:hyperbolic iz double 1 run scoreboard players get h.x.m tmp
execute if score h.x.i tmp >= h.x.m tmp store result storage code:hyperbolic cy double 1 run scoreboard players get h.x.c tmp
execute if score h.x.i tmp >= h.x.m tmp run function code:disaster_system/hyperbolic_space/curve with storage code:hyperbolic
execute if score h.x.i tmp >= h.x.m tmp run scoreboard players operation h.x.i tmp += h.n.o tmp

execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp run scoreboard players operation h.z.c tmp = h.z.i tmp
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp run scoreboard players operation h.z.c tmp *= h.z.i tmp
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp run scoreboard players operation h.z.c tmp += h.r.l tmp
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp run scoreboard players operation h.z.c tmp /= h.c.s tmp
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp run scoreboard players operation h.z.c tmp *= h.n.o tmp
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp run scoreboard players operation h.z.c tmp += h.c.s tmp
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp run scoreboard players operation h.z.c tmp /= h.t.t tmp
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp run scoreboard players operation h.z.c tmp += h.m.h tmp
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp store result storage code:hyperbolic az double 1 run scoreboard players get h.z.i tmp
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp store result storage code:hyperbolic iz double 1 run scoreboard players get h.z.i tmp
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp store result storage code:hyperbolic ax double 1 run scoreboard players get h.c.s tmp
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp store result storage code:hyperbolic ix double 1 run scoreboard players get h.z.m tmp
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp store result storage code:hyperbolic cy double 1 run scoreboard players get h.z.c tmp
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp run function code:disaster_system/hyperbolic_space/curve with storage code:hyperbolic
execute unless score h.x.i tmp >= h.x.m tmp if score h.z.i tmp >= h.z.m tmp run scoreboard players operation h.z.i tmp += h.n.o tmp
