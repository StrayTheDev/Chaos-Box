kill @e[tag=event.black_hole_block]
kill @e[tag=alien_laser]
playsound block.beacon.deactivate master @a 0 0 0 1000
execute as @a[team=pvp] run attribute @s gravity modifier remove alien