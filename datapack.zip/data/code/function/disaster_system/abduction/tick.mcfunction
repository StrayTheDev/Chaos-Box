summon marker 0 0 0 {Tags:[spread],Rotation:[0.0f,90.0f]}
summon marker 0 0 0 {Tags:[spread],Rotation:[0.0f,90.0f]}
summon marker 0 0 0 {Tags:[spread],Rotation:[0.0f,90.0f]}
execute as @e[tag=spread] at @s run function code:disaster_system/.misc/randomize_pos
execute as @e[tag=spread] at @s run function code:disaster_system/.misc/raycast/raycast
kill @e[tag=spread]


effect give @e[x=-25,dx=50,y=-100,dy=400,z=-25,dz=50,limit=1,sort=random] levitation 5 4

execute as @e[type=block_display,tag=event.black_hole_block] at @s run tp @s ~ ~0.6 ~ ~2 ~-2

playsound block.beacon.ambient master @a 0 0 0 1000
stopsound @a * block.beacon.ambient

execute as @a[team=pvp] run attribute @s gravity modifier add alien -0.9 add_multiplied_base 
execute as @a[team=!pvp] run attribute @s gravity modifier remove alien

