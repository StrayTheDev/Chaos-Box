summon minecraft:block_display -24 -64 24 {block_state:{Name:"minecraft:lime_stained_glass",Properties:{}},transformation:[48f,0f,0f,0f,0f,400f,0f,0f,0f,0f,-48.0f,0f,0f,0f,0f,1f],brightness:{sky:15,block:15},Tags:[alien_laser],view_range:99999}
playsound block.beacon.activate master @a 0 0 0 1000


summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0
summon cow 0 0 0

spreadplayers 0 0 0 24 false @e[type=cow]