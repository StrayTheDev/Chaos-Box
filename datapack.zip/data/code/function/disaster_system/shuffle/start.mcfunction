kill @e[tag=spread]
summon marker 0 0 0 {Tags:[spread]}