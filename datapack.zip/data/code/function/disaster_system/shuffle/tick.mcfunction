spreadplayers 0 0 22 22 false @e[tag=spread]

execute store result score random tmp run random value 1..7

execute if score random tmp matches 1 run execute at @e[tag=spread] run clone ~-1 ~-1 ~-1 ~1 ~-1 ~1 ~-1 ~ ~-1 masked move
execute if score random tmp matches 2 run execute at @e[tag=spread] run clone ~-1 ~-1 ~-1 ~1 ~-1 ~1 ~-1 ~-2 ~-1 masked move
execute if score random tmp matches 3 run execute at @e[tag=spread] run fill ~-1 ~-1 ~-1 ~1 ~-1 ~1 air destroy
execute if score random tmp matches 4 run execute at @e[tag=spread] run clone ~-1 ~-1 ~-1 ~1 ~-1 ~1 ~ ~ ~-1 masked move
execute if score random tmp matches 5 run execute at @e[tag=spread] run clone ~-1 ~-1 ~-1 ~1 ~-1 ~1 ~-1 ~ ~ masked move
execute if score random tmp matches 6 run execute at @e[tag=spread] run clone ~-1 ~-1 ~-1 ~1 ~-1 ~1 ~-1 ~ ~-2 masked move
execute if score random tmp matches 7 run execute at @e[tag=spread] run clone ~-1 ~-1 ~-1 ~1 ~-1 ~1 ~-2 ~ ~-1 masked move
