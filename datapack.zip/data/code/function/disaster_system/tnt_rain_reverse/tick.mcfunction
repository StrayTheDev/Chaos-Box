execute store result score random tmp run random value 1..5
execute if score random tmp matches 1 run summon tnt 0 0 0 {NoGravity:true,Tags:[spread,reverse],fuse:300,explosion_power:3}
spreadplayers 0 0 24 24 true @e[tag=spread]
execute as @e[tag=spread] at @s run tp @s ~ -100 ~
tag @e[tag=spread] remove spread

execute as @e[tag=reverse] run data merge entity @s {Motion:[0.0,0.6,0.0],Glowing:true}
team join owner @e[type=tnt,tag=reverse]