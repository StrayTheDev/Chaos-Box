execute as @a[team=pvp] run data merge entity @s {abilities:{mayfly:true,flying:true}}
tellraw @a[team=pvp] {text:"You can now fly!",color:green}