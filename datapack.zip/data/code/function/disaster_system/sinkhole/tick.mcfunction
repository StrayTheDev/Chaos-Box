execute as @e[tag=spread] at @s run function code:disaster_system/.misc/randomize_pos

execute store result storage code:event.sinkhole random.amount int 1.0 run random value 0..10
execute as @e[tag=spread] at @s facing 0 ~ 0 run function code:disaster_system/sinkhole/center with storage code:event.sinkhole random

execute at @e[tag=spread] positioned over motion_blocking align xy run particle block_crumble{block_state:{Name:"sand"}} ~ ~-49 ~ 0.5 50 0.5 0 5000
execute at @e[tag=spread] positioned over motion_blocking align xy run playsound entity.wither.break_block block @a ~ ~ ~ 0.01
execute at @e[tag=spread] positioned over motion_blocking align xy run clone ~-1 -63 ~-1 ~1 300 ~1 ~-1 -64 ~-1 strict masked move