fill -25 -64 -25 25 300 25 air replace minecraft:anvil
fill -25 -64 -25 25 300 25 air replace minecraft:chipped_anvil
fill -25 -64 -25 25 300 25 air replace minecraft:damaged_anvil
kill @e[type=falling_block]