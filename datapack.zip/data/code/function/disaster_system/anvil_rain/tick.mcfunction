summon falling_block 0 0 0 {BlockState:{Name:"damaged_anvil"},Tags:[spread],FallHurtAmount:100}
summon falling_block 0 0 0 {BlockState:{Name:"damaged_anvil"},Tags:[spread],FallHurtAmount:100}
summon falling_block 0 0 0 {BlockState:{Name:"damaged_anvil"},Tags:[spread],FallHurtAmount:100}
execute as @e[tag=spread] at @s run function code:disaster_system/.misc/randomize_pos
tag @e[tag=spread] remove spread