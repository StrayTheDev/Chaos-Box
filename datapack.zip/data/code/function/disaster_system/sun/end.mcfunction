time set 1300
effect clear @a darkness