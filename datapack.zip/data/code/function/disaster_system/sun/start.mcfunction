time set 17000
effect give @a[team=pvp] darkness infinite 0 true
summon creeper 0 300 0 {PersistenceRequired:true,attributes:[{id:"max_health",base:1000}],powered:1b,ExplosionRadius:10b,Fuse:700,ignited:1b,CustomName:{"text":"The SUN","color":"gold","bold":true,"italic":false},active_effects:[{id:"minecraft:glowing",amplifier:10b,duration:2000,show_particles:0b},{id:"minecraft:slow_falling",amplifier:1b,duration:2000,show_particles:0b}]}
