execute as @a[team=!spawn,predicate=code:sky] run effect give @s wither 1 1
execute as @e[type=!player,predicate=code:sky] run effect give @s wither 1 1