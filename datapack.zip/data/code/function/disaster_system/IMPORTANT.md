(if you cant see this properly, click the document with the magnifying glass icon at the top right of the editor (first of 3 icons))
# Creating an event

### Steps
1. Create your event in code:disaster_system/<event_id>/event_functions. The start, tick and end functions are automatically called, if they exist in the folder. (Having all the functions present is not necessary.)
2. Add your event's information in the load_disasters.mcfunction file. (Follow what's already going on) 
> **The ID in there MUST be the same as the <event_id> as described in step 1.**

3. That's it! As easy as that!

### Notes

- The logic of the event system is stored in disaster_system/randomizer. (please dont mess with this stuff though!!!)
- All players in the arena can be selected with '@a[team=pvp]' (for now at least :/)
- You can change the message for other difficulties in disaster_system/randomizer/start1.mcfunction (And also the time in-between events ;) )
- You can force start events with "disaster_system/randomizer/force_event {event_id:9}"   OR more easily with "disaster_system/randomizer/list_events"