give @a[team=pvp] water_bucket
execute as @a[team=pvp] run attribute @s gravity base set 0
execute as @a[team=pvp] at @s run tp @s 0 150 0
schedule function code:disaster_system/mlg/drop 5s