execute as @a[team=pvp] at @s run tp @s ~ 100 ~
execute as @a[team=pvp] run attribute @s gravity base set 0.08