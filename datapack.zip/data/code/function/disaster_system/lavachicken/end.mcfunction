stopsound @a * music_disc.lava_chicken
kill @e[tag=food_rain_food]
execute as @e[type=chicken] run damage @s 100 in_fire at 0 0 0
kill @e[type=zombie]