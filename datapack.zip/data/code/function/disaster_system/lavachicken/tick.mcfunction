execute store result score $FoodRain tmp run random value 1..300
execute if score $FoodRain tmp matches 1..10 run summon chicken 0 50 0 {Fire:9999,Tags:["food_rain_food"],active_effects:[{id:"fire_resistance",duration:99999}]}
execute if score $FoodRain tmp matches 11..20 run summon chicken 0 50 0 {Passengers:[{id:"minecraft:zombie",IsBaby:true,HasVisualFire:false,active_effects:[{id:"fire_resistance",duration:99999}]}],Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 21..30 run summon item 0 50 0 {Item:{id:"minecraft:cooked_chicken"},Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 31..40 run summon item 0 50 0 {Item:{id:"minecraft:flint_and_steel"},Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 41..50 run summon item 0 50 0 {Item:{id:"minecraft:poisonous_potato"},Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 51..60 run summon falling_block 0 50 0 {BlockState:{Name:"minecraft:fire"},Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 65 run summon falling_block 0 50 0 {BlockState:{Name:"minecraft:lava"},Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 71..80 run summon falling_block 0 50 0 {BlockState:{Name:"minecraft:crafting_table"},Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 297 run tellraw @a ["<",{text:"▌⚑▌ ▐Jack Black▌",color:gold},{text:"> ",color:white},{text:"CHICKEN JOCKEY",color:white}]
execute if score $FoodRain tmp matches 298 run tellraw @a ["<",{text:"▌⚑▌ ▐Jack Black▌",color:gold},{text:"> ",color:white},{text:"FLINT AND STEEL",color:white}]
execute if score $FoodRain tmp matches 299 run tellraw @a ["<",{text:"▌⚑▌ ▐Jack Black▌",color:gold},{text:"> ",color:white},{text:"THE NETHER",color:white}]
execute if score $FoodRain tmp matches 300 run tellraw @a ["<",{text:"▌⚑▌ ▐Jack Black▌",color:gold},{text:"> ",color:white},{text:"First, we mine. Then, we craft. LET'S MINECRAFT",color:white}]

execute as @e[tag=food_rain_food] at @s run function code:disaster_system/.misc/randomize_pos
tag @e[tag=food_rain_food] remove food_rain_food
