execute as @e[type=marker,tag=flood] at @s run fill ~-24 ~50 ~-24 ~24 -64 ~24 air replace water
kill @e[tag=flood]