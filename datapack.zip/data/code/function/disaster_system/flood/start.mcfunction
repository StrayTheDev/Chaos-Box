summon marker 0 -64 0 {Tags:["flood"]}
execute as @e[tag=flood] run function code:disaster_system/.misc/rain
execute as @e[tag=flood] at @s run tp @s ~ -64 ~