execute as @e[type=marker,tag=flood] at @s run tp @s ~ ~0.15 ~
execute as @e[type=marker,tag=flood] at @s run fill ~ ~ ~ ~ ~ ~ water keep
execute as @e[type=marker,tag=flood] at @s run fill ~-24 ~-20 ~-24 ~24 ~ ~24 water replace water[level=1]
execute as @a[team=pvp,predicate=code:in_water] run damage @s 3 drown