summon ghast 0 50 0 {equipment:{body:{id:"dried_ghast",count:1}},drop_chances:{body:1}}
summon ghast 0 50 0 {equipment:{body:{id:"dried_ghast",count:1}},drop_chances:{body:1}}
summon ghast 0 50 0 {equipment:{body:{id:"dried_ghast",count:1}},drop_chances:{body:1}}
summon ghast 0 50 0 {equipment:{body:{id:"dried_ghast",count:1}},drop_chances:{body:1}}
summon ghast 0 50 0 {equipment:{body:{id:"dried_ghast",count:1}},drop_chances:{body:1}}
summon ghast 0 50 0 {equipment:{body:{id:"dried_ghast",count:1}},drop_chances:{body:1}}
summon ghast 0 50 0 {equipment:{body:{id:"dried_ghast",count:1}},drop_chances:{body:1}}
summon ghast 0 50 0 {equipment:{body:{id:"dried_ghast",count:1}},drop_chances:{body:1}}
summon ghast 0 50 0 {equipment:{body:{id:"dried_ghast",count:1}},drop_chances:{body:1}}

execute as @e[type=ghast] run function code:disaster_system/.misc/randomize_pos
execute as @e[type=ghast] at @s run tp @s ~ ~-60 ~
