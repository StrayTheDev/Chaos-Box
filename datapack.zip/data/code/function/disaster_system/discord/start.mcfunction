title @a times 10 80 10
title @a title [{"text":"JOIN THE DISCORD","bold":true,"color":"#5662F5"}]
title @a subtitle [{"text":"it is quite cool","color":"gray"}]
tellraw @a ["Join the Chaos Box Discord ",{"text":"HERE","clickEvent":{"action":"open_url","value":"https://discord.gg/YEFDSDtGyk"},"hoverEvent":{"action":"show_text","contents":"https://discord.gg/YEFDSDtGyk"},"bold":true,"color":"blue"}," to keep up with the chaos! "]

execute at @a run playsound entity.player.levelup master @a ~ ~ ~ 100