$setblock ~ ~ ~ $(Name)
kill @s