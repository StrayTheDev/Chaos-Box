scoreboard players add steps black_hole_raycast_steps 1
execute if score steps black_hole_raycast_steps matches 75.. run return run scoreboard players set steps black_hole_raycast_steps 0
execute unless block ~ ~ ~ air unless block ~ ~ ~ cave_air unless block ~ ~ ~ void_air unless block ~ ~ ~ water unless block ~ ~ ~ lava unless block ~ ~ ~ light run return run function code:disaster_system/.misc/raycast/raycast_hit
execute positioned ^ ^ ^1 run function code:disaster_system/.misc/raycast/raycast