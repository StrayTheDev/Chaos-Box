$summon falling_block ~ ~ ~ {BlockState:{Name:"$(Name)"}}
kill @s