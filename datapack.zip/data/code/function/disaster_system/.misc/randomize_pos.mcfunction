execute store result score @s tmp run random value 50..100

execute store result storage rand.pos X double 1.0 run random value -24..24
execute store result storage rand.pos Y double 1.0 run scoreboard players get @s tmp
execute store result storage rand.pos Z double 1.0 run random value -24..24

function code:disaster_system/.misc/rain with storage rand.pos