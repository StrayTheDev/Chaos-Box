loot spawn ~ ~ ~ mine ~ ~ ~ netherite_pickaxe[enchantments={silk_touch:1}]
data modify storage code:black_hole blockstate set from entity @n[type=item] Item
kill @n[type=item]