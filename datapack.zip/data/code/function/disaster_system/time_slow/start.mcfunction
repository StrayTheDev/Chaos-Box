tick rate 10
scoreboard players set 2 tmp 2
scoreboard players operation .timer tmp /= 2 tmp