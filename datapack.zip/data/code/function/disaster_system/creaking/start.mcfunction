summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:8}]}
spreadplayers 0 0 0 25 false @e[tag=spread]
tag @e[tag=spread] remove spread
time set midnight