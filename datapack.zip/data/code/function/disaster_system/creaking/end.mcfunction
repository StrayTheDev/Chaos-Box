kill @e[tag=small]
time set 3000