execute store result score random tmp run random value 1..10

execute if score random tmp matches 1 run summon creaking 0 0 0 {Tags:["small","spread"],Invulnerable:true,attributes:[{id:"minecraft:attack_damage",base:6}]}
spreadplayers 0 0 0 25 false @e[tag=spread]
tag @e[tag=spread] remove spread