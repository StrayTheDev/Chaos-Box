#executed with macro "listing"
$data modify storage code:disaster_system tmp set from storage code:disaster_system disasters[$(listing)]
$data modify storage code:disaster_system tmp.index set value $(listing)
function code:disaster_system/randomizer/list_events3 with storage code:disaster_system tmp

#loop again (doing it here in case the message fails)
function code:disaster_system/randomizer/list_events1