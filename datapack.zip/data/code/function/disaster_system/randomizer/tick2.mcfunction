$function code:disaster_system/$(id)/tick {id:"$(id)", name:"$(name)", difficulty:"$(difficulty)"}
$execute if score chaos tmp matches 1 run function code:disaster_system/$(id)/tick {id:"$(id)", name:"$(name)", difficulty:"$(difficulty)"}
$execute if score chaos tmp matches 1 run function code:disaster_system/$(id)/tick {id:"$(id)", name:"$(name)", difficulty:"$(difficulty)"}