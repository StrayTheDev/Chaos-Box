


# Gets the range back to [0,len-1]
$execute store result score .randomize disasters run random value 1..$(disasters_len)
scoreboard players remove .randomize disasters 1

# - Normal Disaster Picker
# - Disaster Rigger! Useful for testing - Apmaster2 (MAKE 100% Sure you comment the bottom line after testing!) You will have to change the number to the number of your event :D
#scoreboard players set .randomize disasters 1

execute store result storage code:disaster_system selected_disaster int 1 run scoreboard players get .randomize disasters

function code:disaster_system/randomizer/select_random with storage code:disaster_system
tag @a[team=pvp] add survived