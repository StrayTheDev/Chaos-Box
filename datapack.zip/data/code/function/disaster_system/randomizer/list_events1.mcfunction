#Start of the loop. Do not call directly!
scoreboard players add .listing tmp 1

execute store result storage code:disaster_system tmp.listing int 1 run scoreboard players get .listing tmp

execute if score .listing tmp < .listing_max tmp run return run function code:disaster_system/randomizer/list_events2 with storage code:disaster_system tmp
#If this executes, we're done. Cleanup!
data remove storage code:disaster_system tmp