

#executed with macros index, name, desc, id, difficulty and color
$tellraw @s {click_event:{action:"run_command",command:"/function code:disaster_system/randomizer/force_event {event_index:$(index)}"},color:"$(color)",text:"[$(name)]   ($(index))",underlined:false,hover_event:{action:"show_text",value:{text:"Click to force start $(name)"}}}
