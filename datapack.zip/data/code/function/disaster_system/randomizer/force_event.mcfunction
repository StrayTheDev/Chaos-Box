# Debug function. Forces an event do be called. Requires the "event_index" macro variable 
#that represents the index of the event in the disaster_system.disasters storage array.

#end old event properly
scoreboard players set .timer disasters 0
function code:disaster_system/randomizer/end1 with storage code:disaster_system

scoreboard players operation .timer disasters = .timer tmp
scoreboard players operation .timer disasters += .timer tmp
#initialize new event
$data merge storage code:disaster_system {selected_disaster:$(event_index)}
$data modify storage code:disaster_system selected_disaster set from storage code:disaster_system disasters[$(event_index)]

#start!
function code:disaster_system/randomizer/start1 with storage code:disaster_system selected_disaster
