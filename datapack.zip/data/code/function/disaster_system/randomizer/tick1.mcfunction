$function code:disaster_system/randomizer/tick2 with storage code:disaster_system disasters[$(selected_disaster)]
