# Actually start Next Disaster

#$tellraw @a {bold: true,color: "gold",text: "TEST: STARTING -> $(name) DIFFICULTY: $(difficulty), DESCRIPTION: $(description)"}
$execute if data storage code:disaster_system {selected_disaster:{difficulty:"normal"}} run tellraw @a [{text:"Event Approaching: "},{text:"[$(name)]",hover_event:{action:"show_text",value:{text:"$(description)"}},bold:false,color:"$(color)",underlined:true},{text:" ",bold:false,color:"aqua"},{text:"(normal)",italic:true,color:"gray"}]

# - By Apmaster2 - Added Color compat also by Apmaster2 ;)
$execute if data storage code:disaster_system {selected_disaster:{difficulty:"medium"}} run tellraw @a [{text:"Event Approaching: "},{text:"[$(name)]",hover_event:{action:"show_text",value:{text:"$(description)"}},bold:false,color:"$(color)",underlined:true},{text:" ",bold:false,color:"aqua"},{text:"(medium)",italic:true,color:"gold"}]
$execute if data storage code:disaster_system {selected_disaster:{difficulty:"hard"}} run tellraw @a [{text:"Event Approaching: "},{text:"[$(name)]",hover_event:{action:"show_text",value:{text:"$(description)"}},bold:false,color:"$(color)",underlined:true},{text:" ",bold:false,color:"aqua"},{text:"(hard)",italic:true,color:"red"}]
$execute if data storage code:disaster_system {selected_disaster:{difficulty:"impossible"}} run tellraw @a [{text:"Event Approaching: "},{text:"[$(name)]",hover_event:{action:"show_text",value:{text:"$(description)"}},bold:false,color:"$(color)",underlined:true},{text:" ",bold:false,color:"aqua"},{text:"(impossible)",italic:true,color:"dark_red"}]
$execute if data storage code:disaster_system {selected_disaster:{difficulty:"special"}} run tellraw @a [{text:"A Special Event Approaches... ",color:"dark_red"},{text:"[$(name)]",hover_event:{action:"show_text",value:{text:"$(description)"}},bold:false,color:"$(color)",underlined:true},{text:" ",bold:false,color:"dark_red"}]
execute if data storage code:disaster_system {selected_disaster:{difficulty:"special"}} run title @a title {text:"Special Event",color:"dark_red"}
$execute if data storage code:disaster_system {selected_disaster:{difficulty:"special"}} run title @a subtitle {text:"$(name)",color:"dark_red"}
execute if data storage code:disaster_system {selected_disaster:{difficulty:"special"}} run title @a times 20 60 100
###########################################################

$team modify sidebar suffix  [{text:" [",bold:false,color:"$(color)"},{text:"$(name)",color:"$(color)"},{text:"]",bold:false,color:"$(color)"}]


# Use of schedule to add a little bit of delay before the event actually starts. Change here if needed
$execute unless score chaos tmp matches 1 run schedule function code:disaster_system/$(id)/start 100t
$execute if score chaos tmp matches 1 run function code:disaster_system/$(id)/start
# {id:"$(id)", name:"$(name)", difficulty:"$(difficulty)"}
scoreboard players operation .timer disasters = .timer tmp
scoreboard players operation .timer disasters += .timer tmp
scoreboard players operation .timer disasters += .timer tmp
scoreboard players operation .timer disasters += .timer tmp
# Set timer on success! Change here if needed

