#Debug function. Sends all events in chat of the executor. Clicking on even force-starts it
execute store result score .listing_max tmp run data get storage code:disaster_system disasters_len
scoreboard players set .listing tmp -1

function code:disaster_system/randomizer/list_events1
