$function code:disaster_system/randomizer/end2 with storage code:disaster_system disasters[$(selected_disaster)]
# Reset timer (ONLY USED IF THE START LOGIC FAILED (CODE DIDNT REACH start1's end!!))
# Start next event

# function code:disaster_system/randomizer/setmax_start
