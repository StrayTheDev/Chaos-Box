$function code:disaster_system/$(id)/end {id:"$(id)", name:"$(name)", difficulty:"$(difficulty)"}


scoreboard players set normal tmp 3
scoreboard players set medium tmp 5
scoreboard players set hard tmp 10
scoreboard players set impossible tmp 25

execute if score chaos tmp matches 0 run scoreboard players set .timer tmp 200
$scoreboard players operation @a[tag=survived] chaos_coins += $(difficulty) tmp
$tellraw @a[tag=survived] [{"text":"You Survived! ","color":"green"},{"text":"+","color":"dark_green"},{"color":"dark_green","score":{"objective":"tmp","name":"$(difficulty)"}},{"color":"dark_green","text":"Ⓒ"}]
xp add @a[tag=survived] 25 points

kill @e[x=-25,dx=50,y=-100,dy=400,z=-25,dz=50,type=marker,tag=!safe]