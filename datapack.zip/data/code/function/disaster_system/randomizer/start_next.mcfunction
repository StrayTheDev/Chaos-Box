#New randomising code. starts here, no args required.
scoreboard players operation .timer disasters = .timer tmp
scoreboard players operation .timer disasters += .timer tmp

function code:disaster_system/randomizer/start_next1 with storage code:disaster_system
