worldborder center 0 -100
worldborder set 255
worldborder set 155 40
worldborder damage amount 1
worldborder damage buffer 0
worldborder warning distance 5