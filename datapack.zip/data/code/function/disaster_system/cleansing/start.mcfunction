# idk what this is :/
# nobody does
# summon armor_stand 23 40 -23 {Invisible:true,Invulnerable:true,NoGravity:true,Tags:[cleaning_guy]}
#this has been here since the very beginning so it stays