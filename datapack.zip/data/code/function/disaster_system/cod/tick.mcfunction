summon cod 0 0 0 {Tags:[spread],Invulnerable:true,NoGravity:true}
spreadplayers 0 0 24 24 true @e[tag=spread]
execute as @e[tag=spread] at @s run tp @s ~ ~50 ~
data merge entity @n[tag=spread] {Motion:[0.0,-0.98,0.0]}
tag @e[tag=spread] remove spread
