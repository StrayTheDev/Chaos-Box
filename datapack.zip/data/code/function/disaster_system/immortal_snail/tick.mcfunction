execute as @e[tag=event.snail] at @s run rotate @s facing entity @p[team=pvp]
execute as @e[tag=event.snail] at @s run tp @s ^ ^ ^0.15
execute as @e[tag=event.snail] at @s run data merge entity @s {teleport_duration:5}
execute as @e[tag=event.snail] at @s run kill @n[distance=..1,tag=!event.snail]
execute as @e[tag=event.snail] at @s run fill ~ ~ ~ ~ ~ ~ air destroy
execute as @e[tag=event.snail] at @s unless entity @p[team=pvp] run rotate @s facing 0 0 0
