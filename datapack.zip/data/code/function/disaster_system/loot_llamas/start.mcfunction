
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"minecraft:chests/end_city_treasure",attributes:[{id:"max_health",base:1}]}
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"minecraft:chests/village/village_weaponsmith",attributes:[{id:"max_health",base:1}]}
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"minecraft:chests/shipwreck_treasure",attributes:[{id:"max_health",base:1}]}
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"minecraft:chests/bastion_treasure",attributes:[{id:"max_health",base:1}]}
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"minecraft:chests/spawn_bonus_chest",attributes:[{id:"max_health",base:1}]}
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"minecraft:chests/ancient_city",attributes:[{id:"max_health",base:1}]}
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"minecraft:chests/trial_chambers/reward_ominous_unique",attributes:[{id:"max_health",base:1}]}
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"minecraft:chests/ruined_portal",attributes:[{id:"max_health",base:1}]}
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"minecraft:chests/village/village_toolsmith",attributes:[{id:"max_health",base:1}]}
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"minecraft:chests/village/village_armorer",attributes:[{id:"max_health",base:1}]}
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"chests/desert_pyramid",attributes:[{id:"max_health",base:1}]}
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"chests/buried_treasure",attributes:[{id:"max_health",base:1}]}
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"chests/desert_pyramid",attributes:[{id:"max_health",base:1}]}
summon minecraft:trader_llama 0 100 0 {Health:1,DeathLootTable:"minecraft:chaos_box",attributes:[{id:"max_health",base:1}]}


spreadplayers 0 0 1 24 false @e[type=trader_llama]