execute as @a[team=pvp] at @s run fill ~-4 ~-4 ~-10 ~4 ~10 ~4 sand replace #mineable/shovel
execute as @a[team=pvp] at @s run fill ~-4 ~-4 ~-10 ~4 ~10 ~4 gravel replace #mineable/pickaxe
playsound entity.wither.break_block block @a 0 0 0 9999