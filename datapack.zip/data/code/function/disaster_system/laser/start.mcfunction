summon marker 0 0 0 {Tags:[rift]}
spreadplayers 0 0 20 20 false @e[tag=rift]
execute as @e[tag=rift] at @s run tp @s ~ -64 ~
execute as @e[tag=rift] at @s run summon block_display ~-0.5 ~-0.5 ~-0.5 {Passengers:[{id:"minecraft:block_display",block_state:{Name:"minecraft:red_stained_glass",Properties:{}},transformation:[4f,0f,0f,-2f,0f,400f,0f,0f,0f,0f,4f,-2f,0f,0f,0f,1f],brightness:{sky:15,block:15},Tags:[laser]},{id:"minecraft:block_display",block_state:{Name:"minecraft:red_concrete",Properties:{}},transformation:[3.5f,0f,0f,-1.75f,0f,400f,0f,0f,0f,0f,3.5f,-1.75f,0f,0f,0f,1f],brightness:{sky:15,block:15},Tags:[laser]}],Tags:[laser]}
execute as @a run playsound block.end_portal.spawn master @a 0 0 0 99999
