execute as @e[tag=rift] at @s run summon tnt ~ ~-5 ~ {fuse:1}
execute as @e[tag=rift] at @s run summon end_crystal ~ ~ ~
execute as @e[tag=rift] at @s run summon tnt ~ ~5 ~ {fuse:1}
execute as @e[tag=rift] at @s run tp @s ~ ~1 ~
execute as @e[tag=rift] at @s run particle dust_pillar{block_state:redstone_block} ~-5 -64 ~-5 ~5 320 ~5 0 100
execute as @e[tag=laser] at @s run tp @s ~ ~ ~ ~5 ~
execute as @e[tag=rift] at @s run particle dust{color:[1.000,0.000,0.000],scale:4} ~ 32 ~ 1.5 96 1.5 0 100 force