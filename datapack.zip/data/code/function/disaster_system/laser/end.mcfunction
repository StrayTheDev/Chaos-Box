kill @e[tag=rift]
kill @e[tag=laser]