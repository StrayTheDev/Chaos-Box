scoreboard players add kelp tmp 1
scoreboard players operation kelp tmp %= speed tmp

execute as @e[tag=expand] at @s unless block ~ ~ ~ air run kill @s
kill @e[tag=expand,y=-70,dy=6]

execute if score kelp tmp matches 2 as @e[tag=expand] at @s run setblock ~ ~ ~ dried_kelp_block
execute if score kelp tmp matches 2 as @e[tag=expand,limit=500,sort=random] at @s run function code:disaster_system/kelp_expand/expand
execute as @e[tag=expand] at @s if block 25 ~ -26 minecraft:bedrock run kill @s