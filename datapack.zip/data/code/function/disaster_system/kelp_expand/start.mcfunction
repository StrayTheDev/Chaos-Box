execute positioned 0 0 0 positioned over motion_blocking run summon marker ~ ~ ~ {Tags:[expand]}
execute as @e[tag=expand] at @s run tp @s ~ ~5 ~

scoreboard players set kelp tmp 0
scoreboard players set speed tmp 20