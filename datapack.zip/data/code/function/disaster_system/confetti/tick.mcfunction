execute store result score confetti tmp run random value 1..300
execute positioned as @e[tag=confetti] if score confetti tmp matches 10 run fill ~-3 ~30 ~-3 ~3 ~30 ~3 red_concrete_powder
execute positioned as @e[tag=confetti] if score confetti tmp matches 20 run fill ~-3 ~30 ~-3 ~3 ~30 ~3 blue_concrete_powder
execute positioned as @e[tag=confetti] if score confetti tmp matches 30 run fill ~-3 ~30 ~-3 ~3 ~30 ~3 lime_concrete_powder
execute positioned as @e[tag=confetti] if score confetti tmp matches 40 run fill ~-3 ~30 ~-3 ~3 ~30 ~3 yellow_concrete_powder
execute positioned as @e[tag=confetti] if score confetti tmp matches 50 run fill ~-3 ~30 ~-3 ~3 ~30 ~3 pink_concrete_powder
execute positioned as @e[tag=confetti] if score confetti tmp matches 60 run fill ~-3 ~30 ~-3 ~3 ~30 ~3 light_blue_concrete_powder
execute positioned as @e[tag=confetti] if score confetti tmp matches 70 run fill ~-3 ~30 ~-3 ~3 ~30 ~3 magenta_concrete_powder
execute positioned as @e[tag=confetti] if score confetti tmp matches 80 run fill ~-3 ~30 ~-3 ~3 ~30 ~3 orange_concrete_powder


execute positioned as @n[tag=confetti] if score confetti tmp matches 0..10 run summon tnt ~ ~20 ~ {fuse:1}
execute positioned as @n[tag=confetti] if score confetti tmp matches 20..30 run summon tnt ~1 ~20 ~-1 {fuse:1}
execute positioned as @n[tag=confetti] if score confetti tmp matches 40..50 run summon tnt ~1 ~20 ~1 {fuse:1}
execute positioned as @n[tag=confetti] if score confetti tmp matches 60..70 run summon tnt ~-1 ~20 ~-1 {fuse:1}
execute positioned as @n[tag=confetti] if score confetti tmp matches 80..90 run summon tnt ~-1 ~20 ~1 {fuse:1}