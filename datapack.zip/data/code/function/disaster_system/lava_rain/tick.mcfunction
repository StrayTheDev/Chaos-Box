particle minecraft:falling_lava 0 40 0 15 1 15 5000 1
particle minecraft:falling_lava 0 40 0 15 1 15 5000 1
particle minecraft:falling_lava 0 40 0 15 1 15 5000 1

summon falling_block 0 50 0 {BlockState:{Name:"fire"},Tags:["lava_rain_lava"]}

spreadplayers 0 0 1 20 false @e[tag=lava_rain_lava]
execute as @e[tag=lava_rain_lava] at @s run tp @s ~ ~30 ~
tag @e[tag=lava_rain_lava] remove lava_rain_lava

execute as @a[team=pvp,predicate=code:sky] run data merge entity @s {Fire:5}