tellraw Legitermoose ["",{"text":"Hello Mr. The Moose sir. You pay for the server, so you get the ultimate Pay to Win prize: +1000","color":"green"},{"text":"ⓒ","color":"green"},{"text":" for you contribution","color":"green"}]
tellraw NobleSkye ["",{"text":"You are NobleSkye, the #1 Donator. you get extra +100","color":"green"},{"text":"ⓒ","color":"green"},{"text":" for you contribution","color":"green"}]
tellraw @a[tag=is_fm] ["",{"text":"You are Full Moose! you get +30","color":"green"},{"text":"ⓒ","color":"green"}]
tellraw @a[tag=is_am,tag=!is_am] ["",{"text":"You are Apprentice Moose! you get +15","color":"green"},{"text":"ⓒ","color":"green"}]
tellraw @a[tag=!is_fm,tag=!is_am] ["",{"text":"You did not buy a rank. no pay, no win.","color":"gray"}]

scoreboard players add NobleSkye chaos_coins 100
scoreboard players add Legitermoose chaos_coins 1000
scoreboard players add @a[tag=is_fm] chaos_coins 30
scoreboard players add @a[tag=is_am] chaos_coins 15