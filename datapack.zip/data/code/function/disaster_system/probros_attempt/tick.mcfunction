summon silverfish 0 50 0 {Tags:["silver_fish"],active_effects:[{id:"slow_falling",duration:300}]}



execute as @e[tag=silver_fish] at @s run function code:disaster_system/.misc/randomize_pos
tag @e[tag=silver_fish] remove silver_fish

effect give @a[team=pvp] minecraft:infested infinite 5