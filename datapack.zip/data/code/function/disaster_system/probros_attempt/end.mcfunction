kill @e[type=silverfish]
effect clear @a[team=pvp] infested 
