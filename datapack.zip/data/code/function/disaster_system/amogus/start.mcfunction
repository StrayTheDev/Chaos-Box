# also made by EnderShameimaru
execute as @r[team=pvp] at @s run function code:disaster_system/amogus/amogus
