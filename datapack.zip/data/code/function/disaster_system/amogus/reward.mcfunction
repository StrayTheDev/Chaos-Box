playsound entity.ender_dragon.growl master @a 0 0 0 9999
tellraw @a [{selector:"@s"},{text:" was the imposter!",color:dark_red}]
scoreboard players add @s chaos_coins 100
playsound entity.experience_orb.pickup master @s ~ ~ ~ 1
tellraw @s [{text:"+100Ⓒ",color:green}]
advancement revoke @s only code:sus