execute store result score random tmp run random value 1..80
execute if score random tmp matches 1 run execute at @a[team=pvp,gamemode=survival] run summon tnt ~ ~ ~ {fuse:100,explosion_power:3}