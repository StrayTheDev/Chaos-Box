kill @e[type=frog]
