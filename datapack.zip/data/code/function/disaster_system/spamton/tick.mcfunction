kill @e[type=area_effect_cloud]
execute as @e[tag=Boss,tag=!Boss-Base] at @s run rotate @s facing entity @p
execute as @e[tag=Boss,tag=!Boss-Base] at @s run rotate @s ~180 0
execute at @e[tag=Boss-Hitbox] run fill ~-1.8 ~0.1 ~-1.8 ~1.8 ~4.2 ~1.8 air destroy
tp @e[tag=spamton_neo_root] @n[tag=Boss-Base]

execute as @e[tag=Boss-Bullet] at @s run tp @s ^ ^ ^0.3
execute as @e[tag=Boss-Bullet] at @s run damage @p[dx=0,dy=0,dz=0] 8 magic
execute as @e[tag=Boss-Bullet] at @s unless block ~ ~ ~ air run kill @s

execute as @e[tag=Boss-Rotate] rotated as @s run rotate @s ~15 ~

execute as @e[tag=Boss-Face] run rotate @s facing entity @p
execute as @e[tag=Boss-Face] rotated as @s run rotate @s ~180 0

scoreboard players remove 3t tmp 1
execute if score 3t tmp matches ..0 run scoreboard players set 3t tmp 15
execute if score 3t tmp matches 1 at @e[tag=Boss-Head] run function spamton_neo:model/projectiles/bullet

execute positioned 0 0 0 store result bossbar neo value run data get entity @n[tag=Boss-Hitbox] Health

execute as @e[tag=Boss-Base] unless entity @n[tag=Boss-Hitbox] run function spamton_neo:model/delete
