data modify storage code:disaster_system selected_disaster set value {id:"spamton", name:"Spamton NEO", difficulty:"special", description:"Now's your chance to be a [[BIG SHOT]]!", color:"light_purple"}
function code:disaster_system/randomizer/start1 with storage code:disaster_system selected_disaster
execute positioned 50.77 22.00 -34.42 as @a[distance=..10] store result storage rand.pos y int 1.0 run random value 0..200
execute positioned 50.77 22.00 -34.42 as @a[distance=..10] run function code:spawning with storage rand.pos
