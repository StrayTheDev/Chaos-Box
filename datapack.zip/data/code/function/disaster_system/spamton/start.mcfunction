execute positioned 0 0 0 run function spamton_neo:model/create
scoreboard players set .timer disasters 999999999
scoreboard players set boss tmp 1
fill 26 22 -35 26 23 -35 minecraft:bedrock
execute positioned 51 22 -35 run tp @a[distance=..10] 0 4 -44