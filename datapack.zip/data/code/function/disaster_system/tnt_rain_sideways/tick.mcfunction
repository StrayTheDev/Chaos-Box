execute store result score random tmp run random value 1..10
execute if score random tmp matches 1 run summon tnt 0 0 0 {NoGravity:true,Tags:[spread,px,x],fuse:120,explosion_power:3}
execute if score random tmp matches 2 run summon tnt 0 0 0 {NoGravity:true,Tags:[spread,nx,x],fuse:120,explosion_power:3}
execute if score random tmp matches 3 run summon tnt 0 0 0 {NoGravity:true,Tags:[spread,pz,z],fuse:120,explosion_power:3}
execute if score random tmp matches 4 run summon tnt 0 0 0 {NoGravity:true,Tags:[spread,nz,z],fuse:120,explosion_power:3}


execute store result storage sideways pos1 int 1.0 run random value -24..24
execute store result storage sideways pos2 int 1.0 run random value -20..120


execute as @e[tag=spread,tag=px] at @s run data modify entity @s Pos[0] set value 24
execute as @e[tag=spread,tag=nx] at @s run data modify entity @s Pos[0] set value -24
execute as @e[tag=spread,tag=pz] at @s run data modify entity @s Pos[2] set value 24
execute as @e[tag=spread,tag=nz] at @s run data modify entity @s Pos[2] set value -24
execute as @e[tag=spread] run data modify entity @s Pos[1] set from storage sideways pos2
execute as @e[tag=x] run data modify entity @s Pos[2] set from storage sideways pos1
execute as @e[tag=z] run data modify entity @s Pos[0] set from storage sideways pos1
tag @e[tag=spread] remove spread

execute as @e[type=tnt,tag=px] run data modify entity @s Motion[0] set value -0.5
execute as @e[type=tnt,tag=nx] run data modify entity @s Motion[0] set value 0.5
execute as @e[type=tnt,tag=pz] run data modify entity @s Motion[2] set value -0.5
execute as @e[type=tnt,tag=nz] run data modify entity @s Motion[2] set value 0.5

tag @e[tag=x] remove x
tag @e[tag=z] remove z