effect clear @a[team=pvp] darkness
kill @e[type=wither]