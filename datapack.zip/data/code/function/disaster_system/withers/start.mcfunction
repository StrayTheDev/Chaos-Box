summon wither 0 0 0
summon wither 0 0 0
summon wither 0 0 0
summon wither 0 0 0
summon wither 0 0 0
summon wither 0 0 0
summon wither 0 0 0
summon wither 0 0 0
summon wither 0 0 0
summon wither 0 0 0
summon wither 0 0 0
summon wither 0 0 0
summon wither 0 0 0
summon wither 0 0 0
summon wither 0 0 0
spreadplayers 0 0 0 25 false @e[type=wither]