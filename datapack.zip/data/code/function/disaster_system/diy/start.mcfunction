give @a[team=pvp,gamemode=survival] tnt 32
give @a[team=pvp,gamemode=survival] flint_and_steel 1