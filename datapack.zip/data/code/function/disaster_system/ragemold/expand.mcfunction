summon marker ~1 ~ ~ {Tags:[expand]}
summon marker ~-1 ~ ~ {Tags:[expand]}
summon marker ~ ~1 ~ {Tags:[expand]}
summon marker ~ ~-1 ~ {Tags:[expand]}
summon marker ~ ~ ~1 {Tags:[expand]}
summon marker ~ ~ ~-1 {Tags:[expand]}
kill @e[type=item,nbt={Item:{id:"minecraft:nether_wart"}},distance=..3]
