scoreboard players add corruption tmp 1
scoreboard players operation corruption tmp %= speed tmp
execute store result score random tmp run random value 1..2

kill @e[tag=expand,y=-70,dy=6]

execute as @e[tag=expand] at @s if block ~ ~ ~ bedrock run kill @s
execute if score corruption tmp matches 2 as @e[tag=expand] at @s run setblock ~ ~ ~ nether_wart_block
execute as @e[tag=expand] at @s if block 25 ~ -26 minecraft:bedrock run kill @s
execute as @e[tag=expand] at @s if block ~ ~ ~ air unless block ~ ~-1 ~ air run setblock ~ ~ ~ nether_wart
execute as @e[tag=expand] at @s if block ~ ~ ~ nether_wart run kill @s
execute if score corruption tmp matches 2 as @e[tag=expand,limit=50,sort=random] at @s run function code:disaster_system/ragemold/expand
execute as @e[tag=expand] at @s if block ~ ~ ~ nether_wart_block run kill @s
execute as @a[team=pvp] at @s if entity @n[distance=..2,tag=expand] run damage @s 4