kill @e[x=-25,dx=50,y=-100,dy=400,z=-25,dz=50,type=marker]
gamerule randomTickSpeed 3