summon breeze_wind_charge 0 50 0 {Tags:["windy_day"],Motion:[0.0,-1.0,0.0],Silent:true}
summon breeze_wind_charge 0 50 0 {Tags:["windy_day"],Motion:[0.0,-1.0,0.0],Silent:true}
summon breeze_wind_charge 0 50 0 {Tags:["windy_day"],Motion:[0.0,-1.0,0.0],Silent:true}
summon breeze_wind_charge 0 50 0 {Tags:["windy_day"],Motion:[0.0,-1.0,0.0],Silent:true}

execute as @e[tag=windy_day] at @s run function code:disaster_system/.misc/randomize_pos
execute as @e[tag=windy_day] at @s run tp @s ~ ~-45 ~
execute as @e[type=breeze_wind_charge] run data merge entity @s {Motion:[0.0,-1.0,0.0]}
tag @e[tag=windy_day] remove windy_day
