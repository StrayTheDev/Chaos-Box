summon marker 0 0 0 {Tags:[expand]}
spreadplayers 0 0 10 10 true @e[tag=expand]
execute as @e[tag=expand] at @s run tp @s ~ ~20 ~