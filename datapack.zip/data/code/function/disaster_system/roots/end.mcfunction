fill -25 -63 -25 25 319 25 minecraft:air replace minecraft:warped_hyphae
kill @e[tag=expand]