

execute as @e[tag=expand,limit=10,sort=random] at @s run function code:disaster_system/roots/expand
execute as @e[tag=expand] at @s unless block ~ ~ ~ air run kill @s
execute as @e[tag=expand] at @s run setblock ~ ~ ~ warped_hyphae
execute positioned 0 -100 0 run kill @e[tag=expand,limit=1,sort=furthest]