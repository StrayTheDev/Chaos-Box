# - By Ap
execute store result score $FoodRain tmp run random value 1..80
execute if score $FoodRain tmp matches 1..20 run summon item 0 50 0 {Item:{id:"minecraft:bread"}, Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 21..25 run summon item 0 50 0 {Item:{id:"minecraft:apple"}, Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 26..29 run summon item 0 50 0 {Item:{id:"minecraft:baked_potato"}, Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 30 run summon item 0 50 0 {Item:{id:"minecraft:poisonous_potato"}, Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 31..35 run summon falling_block 0 50 0 {BlockState:{Name:"minecraft:melon"}, Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 36..40 run summon item 0 50 0 {Item:{id:"minecraft:golden_apple"}, Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 41..65 run summon item 0 50 0 {Item:{id:"minecraft:golden_carrot"}, Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 66..70 run summon falling_block 0 50 0 {BlockState:{Name:"minecraft:sweet_berry_bush",Properties:{age:"3"}}, Tags:["food_rain_food"]}
execute if score $FoodRain tmp matches 71..80 run summon falling_block 0 50 0 {BlockState:{Name:"minecraft:cake"}, Tags:["food_rain_food"]}

effect give @a[team=pvp,predicate=code:sky] saturation 1
execute as @e[tag=food_rain_food] at @s run function code:disaster_system/.misc/randomize_pos
tag @e[tag=food_rain_food] remove food_rain_food