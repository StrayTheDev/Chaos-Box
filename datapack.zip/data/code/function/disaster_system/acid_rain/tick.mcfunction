execute as @a[team=pvp,predicate=code:sky] run effect give @s poison 1 200
execute as @e[type=!player,predicate=code:sky] run effect give @s poison 1 200
execute store result score decay_rate tmp run random value 1..100

execute if score decay_rate tmp matches 1 run summon marker 0 0 0 {Tags:["acid_decay"]}
execute if score decay_rate tmp matches 2 run summon marker 0 0 0 {Tags:["acid_decay"]}
execute if score decay_rate tmp matches 3 run summon marker 0 0 0 {Tags:["acid_decay"]}
spreadplayers 0 0 1 23 false @e[tag=acid_decay]
execute at @e[tag=acid_decay] if score decay_rate tmp matches 1 run setblock ~ ~-1 ~ air destroy
execute at @e[tag=acid_decay] if score decay_rate tmp matches 2 run setblock ~ ~-1 ~ lime_concrete_powder destroy
execute at @e[tag=acid_decay] if score decay_rate tmp matches 3 run setblock ~ ~-1 ~ green_concrete_powder destroy