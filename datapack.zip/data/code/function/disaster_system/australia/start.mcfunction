execute as @e[x=-24,dx=48,y=-64,dy=384,z=-24,dz=48] run attribute @s gravity base set -0.02
execute as @e[x=-24,dx=48,y=-64,dy=384,z=-24,dz=48] at @s run playsound entity.evoker.cast_spell player @s
execute as @e[x=-24,dx=48,y=-64,dy=384,z=-24,dz=48] at @s run particle trial_spawner_detection ~ ~ ~ 0.25 0.5 0.25 0 20