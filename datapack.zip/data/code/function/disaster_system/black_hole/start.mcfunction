summon block_display 0 0.5 0 {Tags:["event.black_hole","safe"],brightness:{sky:0,block:0},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-1f,-1f,-1f],scale:[2f,2f,2f]},block_state:{Name:black_concrete}}
summon marker 0 0.5 0 {Tags:["event.black_hole","safe"]}
summon armor_stand 0 0.5 0 {Tags:["event.black_hole","safe"],Marker:true,Invisible:true,Silent:true}
summon marker 0.0 0.0 0.0 { UUID: [I;12,-34,56,-78], Tags:["safe"] }
scoreboard objectives add black_hole_raycast_steps dummy
scoreboard objectives add black_hole_fail_chance dummy
scoreboard objectives add black_hole_pickup_cooldown dummy
scoreboard objectives add black_hole_damage_cooldown dummy
scoreboard objectives add next_pos_x dummy
scoreboard objectives add next_pos_y dummy
scoreboard objectives add next_pos_z dummy

scoreboard players set @e[type=armor_stand,tag=event.black_hole] next_pos_x 0
scoreboard players set @e[type=armor_stand,tag=event.black_hole] next_pos_y 0
scoreboard players set @e[type=armor_stand,tag=event.black_hole] next_pos_z 0 