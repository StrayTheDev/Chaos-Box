execute at @e[type=marker,tag=event.black_hole] run particle squid_ink ~ ~ ~ 1 1 1 0.1 50 force

execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[0] float 1 run random value -180..180
execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[1] float 1 run random value -90..90

execute as @e[type=marker,tag=event.black_hole] at @s run function code:disaster_system/.misc/raycast/raycast

execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[0] float 1 run random value -180..180
execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[1] float 1 run random value -90..90

execute as @e[type=marker,tag=event.black_hole] at @s run function code:disaster_system/.misc/raycast/raycast

execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[0] float 1 run random value -180..180
execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[1] float 1 run random value -90..90

execute as @e[type=marker,tag=event.black_hole] at @s run function code:disaster_system/.misc/raycast/raycast

execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[0] float 1 run random value -180..180
execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[1] float 1 run random value -90..90

execute as @e[type=marker,tag=event.black_hole] at @s run function code:disaster_system/.misc/raycast/raycast

execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[0] float 1 run random value -180..180
execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[1] float 1 run random value -90..90

execute as @e[type=marker,tag=event.black_hole] at @s run function code:disaster_system/.misc/raycast/raycast

execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[0] float 1 run random value -180..180
execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[1] float 1 run random value -90..90

execute as @e[type=marker,tag=event.black_hole] at @s run function code:disaster_system/.misc/raycast/raycast

execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[0] float 1 run random value -180..180
execute as @e[type=marker,tag=event.black_hole] store result entity @s Rotation[1] float 1 run random value -90..90

execute as @e[type=marker,tag=event.black_hole] at @s run function code:disaster_system/.misc/raycast/raycast


execute as @e[type=block_display,tag=event.black_hole_block] at @s run tp @s ^ ^ ^0.6 facing entity @n[type=marker,tag=event.black_hole]
execute as @e[type=block_display,tag=event.black_hole_block] at @s if entity @e[type=marker,tag=event.black_hole,distance=..0.3] run kill @s

tp @e[type=marker,tag=event.black_hole] @n[type=armor_stand,tag=event.black_hole]
tp @e[type=block_display,tag=event.black_hole] @n[type=armor_stand,tag=event.black_hole]
execute as @e[type=block_display,tag=event.black_hole] at @s run tp @s ~ ~ ~ 0 0

execute as @e[type=armor_stand,tag=event.black_hole] store result score @s posX run data get entity @s Pos[0]
execute as @e[type=armor_stand,tag=event.black_hole] store result score @s posY run data get entity @s Pos[1]
execute as @e[type=armor_stand,tag=event.black_hole] store result score @s posZ run data get entity @s Pos[2]

execute as @e[type=armor_stand,tag=event.black_hole] if score @s posX = @s next_pos_x if score @s posY = @s next_pos_y if score @s posZ = @s next_pos_z run function code:disaster_system/black_hole/new_pos

execute as @e[type=armor_stand,tag=event.black_hole] store result storage code:black_hole next_pos.x int 1 run scoreboard players get @s next_pos_x
execute as @e[type=armor_stand,tag=event.black_hole] store result storage code:black_hole next_pos.y int 1 run scoreboard players get @s next_pos_y
execute as @e[type=armor_stand,tag=event.black_hole] store result storage code:black_hole next_pos.z int 1 run scoreboard players get @s next_pos_z
execute as @e[type=armor_stand,tag=event.black_hole] at @s run function code:disaster_system/.misc/raycast/move with storage code:black_hole next_pos

execute as @e[type=block_display,tag=event.black_hole_block] at @s if entity @e[type=marker,tag=event.black_hole,distance=..4] run data modify entity @s teleport_duration set value 1

execute as @e[type=armor_stand,tag=event.black_hole] at @s as @a[distance=..25] run function code:disaster_system/black_hole/pull

execute as @e[type=marker,tag=event.black_hole] at @s run playsound block.beacon.ambient ambient @a ~ ~ ~ 10 0.


execute as @e[tag=event.black_hole] at @s run damage @p[distance=..3] 10 fly_into_wall