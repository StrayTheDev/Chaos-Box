# 0000000c-ffff-ffde-0000-0038ffffffb2
execute unless entity @n[tag=event.black_hole] run return fail

execute at @s facing entity @n[tag=event.black_hole] feet positioned 0.0 0.0 0.0 as 0000000c-ffff-ffde-0000-0038ffffffb2 run tp @s ^ ^ ^0.2 ~ ~

data modify entity @s Motion set from entity 0000000c-ffff-ffde-0000-0038ffffffb2 Pos