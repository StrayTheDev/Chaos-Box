execute as @e[type=armor_stand,tag=event.black_hole] store result score @s next_pos_x run random value -24..24
execute as @e[type=armor_stand,tag=event.black_hole] store result score @s next_pos_y run random value -64..64
execute as @e[type=armor_stand,tag=event.black_hole] store result score @s next_pos_z run random value -24..24
