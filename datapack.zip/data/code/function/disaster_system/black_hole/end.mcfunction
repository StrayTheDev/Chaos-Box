execute as @a run ride @s dismount
kill @e[tag=event.black_hole]
execute as @e[type=block_display,tag=event.black_hole_block] at @s run function code:disaster_system/.misc/raycast/replace_falling_block with entity @s block_state
stopsound @a * block.beacon.ambient
kill @e[tag=event.black_hole_block]
kill 0000000c-ffff-ffde-0000-0038ffffffb2