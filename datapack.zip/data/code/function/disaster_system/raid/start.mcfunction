execute as @a at @s run playsound item.goat_horn.sound.2 hostile @s ~ ~ ~ 100 0.9
summon ravager 0 0 0 {Tags:[raider]}
execute store result score random tmp run random value 1..5

execute if score random tmp matches 1 run summon illusioner 0 0 0 {Tags:[raider,raid-leader],PatrolLeader:true}
execute if score random tmp matches 1 run summon pillager 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:crossbow,components:{enchantments:{quick_charge:5, piercing:10}}}}}
execute if score random tmp matches 1 run summon pillager 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:crossbow,components:{enchantments:{quick_charge:5, piercing:10}}}}}
execute if score random tmp matches 1 run summon pillager 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:crossbow,components:{enchantments:{quick_charge:5, piercing:10}}}}}
execute if score random tmp matches 1 run summon pillager 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:crossbow,components:{enchantments:{quick_charge:5, piercing:10}}}}}
execute if score random tmp matches 5 run summon evoker 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:totem_of_undying}, offhand:{id:totem_of_undying}}}
execute if score random tmp matches 1 run summon pillager 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:crossbow,components:{enchantments:{quick_charge:5, piercing:10}}}}}
execute if score random tmp matches 1 run summon pillager 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:crossbow,components:{enchantments:{quick_charge:5, piercing:10}}}}}
execute if score random tmp matches 1 run summon pillager 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:crossbow,components:{enchantments:{quick_charge:5, piercing:10}}}}}
execute if score random tmp matches 1 run summon pillager 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:crossbow,components:{enchantments:{quick_charge:5, piercing:10}}}}}
execute if score random tmp matches 5 run summon evoker 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:totem_of_undying}, offhand:{id:totem_of_undying}}}



execute if score random tmp matches 2 run summon pillager 0 0 0 {Tags:[raider,raid-leader],PatrolLeader:true,equipment:{mainhand:{id:crossbow,components:{enchantments:{quick_charge:5, piercing:10}}}}}
execute if score random tmp matches 2 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 2 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 2 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 2 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 5 run summon evoker 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:totem_of_undying}, offhand:{id:totem_of_undying}}}
execute if score random tmp matches 2 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 2 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 2 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 2 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 5 run summon evoker 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:totem_of_undying}, offhand:{id:totem_of_undying}}}



execute if score random tmp matches 3 run summon witch 0 0 0 {Tags:[raider,raid-leader],PatrolLeader:true}
execute if score random tmp matches 3 run summon witch 0 0 0 {Tags:[raider],PatrolLeader:false}
execute if score random tmp matches 3 run summon witch 0 0 0 {Tags:[raider],PatrolLeader:false}
execute if score random tmp matches 3 run summon witch 0 0 0 {Tags:[raider],PatrolLeader:false}
execute if score random tmp matches 3 run summon witch 0 0 0 {Tags:[raider],PatrolLeader:false}
execute if score random tmp matches 5 run summon evoker 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:totem_of_undying}, offhand:{id:totem_of_undying}}}
execute if score random tmp matches 3 run summon witch 0 0 0 {Tags:[raider],PatrolLeader:false}
execute if score random tmp matches 3 run summon witch 0 0 0 {Tags:[raider],PatrolLeader:false}
execute if score random tmp matches 3 run summon witch 0 0 0 {Tags:[raider],PatrolLeader:false}
execute if score random tmp matches 3 run summon witch 0 0 0 {Tags:[raider],PatrolLeader:false}
execute if score random tmp matches 5 run summon evoker 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:totem_of_undying}, offhand:{id:totem_of_undying}}}



execute if score random tmp matches 4 run summon evoker 0 0 0 {Tags:[raider,raid-leader],PatrolLeader:true,equipment:{mainhand:{id:totem_of_undying}, offhand:{id:totem_of_undying}}}
execute if score random tmp matches 4 run summon witch 0 0 0 {Tags:[raider],PatrolLeader:false}
execute if score random tmp matches 4 run summon pillager 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:crossbow,components:{enchantments:{quick_charge:5, piercing:10}}}}}
execute if score random tmp matches 4 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 4 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 5 run summon evoker 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:totem_of_undying}, offhand:{id:totem_of_undying}}}
execute if score random tmp matches 4 run summon witch 0 0 0 {Tags:[raider],PatrolLeader:false}
execute if score random tmp matches 4 run summon pillager 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:crossbow,components:{enchantments:{quick_charge:5, piercing:10}}}}}
execute if score random tmp matches 4 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 4 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 5 run summon evoker 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:totem_of_undying}, offhand:{id:totem_of_undying}}}



execute if score random tmp matches 5 run summon vindicator 0 0 0 {Tags:[raider,raid-leader],PatrolLeader:true}
execute if score random tmp matches 5 run summon illusioner 0 0 0 {Tags:[raider],PatrolLeader:false}
execute if score random tmp matches 5 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 5 run summon evoker 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:totem_of_undying}, offhand:{id:totem_of_undying}}}
execute if score random tmp matches 5 run summon pillager 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:crossbow,components:{enchantments:{quick_charge:5, piercing:10}}}}}
execute if score random tmp matches 5 run summon illusioner 0 0 0 {Tags:[raider],PatrolLeader:false}
execute if score random tmp matches 5 run summon vindicator 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:iron_axe,components:{enchantments:{sharpness:5, fire_aspect:10}}}}}
execute if score random tmp matches 5 run summon evoker 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:totem_of_undying}, offhand:{id:totem_of_undying}}}
execute if score random tmp matches 5 run summon pillager 0 0 0 {Tags:[raider],PatrolLeader:false,equipment:{mainhand:{id:crossbow,components:{enchantments:{quick_charge:5, piercing:10}}}}}



ride @e[tag=raid-leader,limit=1] mount @e[type=ravager,limit=1]

spreadplayers 0 0 25 25 true @e[type=ravager]
tp @e[tag=raider] @e[type=ravager,limit=1]