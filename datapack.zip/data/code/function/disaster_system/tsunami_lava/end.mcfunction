execute as @e[type=armor_stand,tag=lava_rising] at @s run fill ~-24 ~ ~-24 ~24 -64 ~24 air replace lava
kill @e[tag=lava_rising]