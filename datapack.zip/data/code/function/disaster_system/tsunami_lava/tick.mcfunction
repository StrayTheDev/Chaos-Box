execute as @e[type=armor_stand,tag=lava_rising] at @s run tp @s ~ ~0.07 ~
execute as @e[type=armor_stand,tag=lava_rising] at @s if blocks ~-24 ~ ~-24 ~24 ~ ~24 -24 319 -24 all run tp @s ~ ~0.45 ~
execute as @e[type=armor_stand,tag=lava_rising] at @s run fill ~-24 ~ ~-24 ~24 ~ ~24 lava keep