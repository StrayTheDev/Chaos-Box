execute store result score random tmp run random value 1..5
execute if score random tmp matches 1 run summon tnt 0 0 0 {Tags:[spread],fuse:300,explosion_power:3}
execute as @e[tag=spread] at @s run function code:disaster_system/.misc/randomize_pos
tag @e[tag=spread] remove spread
