




# MAKE SURE THE id MATCHES WITH THE FUNCTIONS PATHS!!! For example, the start functions will be called as (id)/start !!!
data merge storage code:disaster_system {disasters:[\
{id:"vote", name:"Vote Jumpscare", difficulty:"normal", description:"/vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote /vote ", color:"aqua"},\
{id:"australia", name:"Australia", "difficulty":"hard", description:"She comes from a land down under...", color:"gold"},\
{id:"discord", name:"Join the Discord", difficulty:"normal", description:"do it.", color:"aqua"},\
{id:"famine", name:"Famine", difficulty:"medium", description:"Everyone becomes hungry", color:"aqua"},\ 
{id:"acid_rain", name:"Acid Rain", difficulty:"medium", description:"Get under something", color:"aqua"},\
{id:"loot_llamas", name:"Loot Llamas", difficulty:"normal", description:"NO WAY IS THAT A FORTNITE REFERENCE", color:"aqua"},\
{id:"nothing", name:"Literally Nothing", difficulty:"normal", description:"Take the freebie", color:"aqua"},\
{id:"cod", name:"COD in minecraft", difficulty:"normal", description:"wanna play some COD?", color:"aqua"},\
{id:"spiders", name:"Arachnophobia", difficulty:"impossible", description:"Spiders, spiders everywhere!", color:"aqua"},\
{id:"soda", name:"Soda", difficulty:"normal", description:"Soda's bad for you", color:"aqua"},\
{id:"tnt_rain", name:"Tnt Rain", difficulty:"hard", description:"TNT rains from the sky, a classic", color:"aqua"},\
{id:"tnt_rain_reverse", name:"Reverse Tnt Rain", difficulty:"medium", description:"TNT rains from below the map... for some reason", color:"aqua"},\
{id:"tnt_rain_sideways", name:"Sideways Tnt Rain", difficulty:"hard", description:"TNT rains from ... the walls?", color:"aqua"},\
{id:"virus", name:"Covid-19", difficulty:"medium", description:"Social distancing is required for this event", color:"aqua"},\
{id:"raid", name:"Illager Raid", difficulty:"hard", description:"Illagers start a raid", color:"yellow"},\
{id:"zombie_apocalypse", name:"Zombie Apocalypse", difficulty:"hard", description:"The dead rise, won't you join them?", color:"aqua"},\
{id:"slime", name:"Big Slime", difficulty:"hard", description:"Trust me, it's large", color:"aqua"},\
{id:"nuke", name:"Bob the Nuke", difficulty:"medium", description:"He just wants a hug ☹", color:"aqua"},\
{id:"size_changer", name:"Supersized", difficulty:"normal", description:"You become 4 blocks tall", color:"aqua"},\
{id:"tsunami_lava", name:"Lava Rises", difficulty:"medium", description:"Get to the high ground", color:"aqua"},\
{id:"tsunami_water", name:"Tsunami", difficulty:"normal", description:"Please stop swimming to the top and dying it happens every time", color:"aqua"},\
{id:"sun", name:"The Sun Explodes", difficulty:"medium", description:"every 7-year old's worst fear", color:"aqua"},\
{id:"bat", name:"CHAOS Pinata", difficulty:"normal", description:"Kill the bat pinata to get goodies!", color:"aqua"},\
{id:"surface", name:"Swappage", difficulty:"normal", description:"Get randomly teleported around the map", color:"aqua"},\
{id:"bees", name:"Swarm", difficulty:"hard", description:"RELEASE THE BEES!", color:"aqua"},\
{id:"warden", name:"Peak Stealth Gameplay", difficulty:"hard", description:"truly the peakest of stealth gameplays", color:"aqua"},\
{id:"wololo", name:"Wololo", difficulty:"normal", description:"Wololo", color:"aqua"},\
{id:"food_rain", name:"Food Rain", difficulty:"normal", description:"Food for you :D", color:"yellow"},\
{id:"meteor_shower", name:"⚠ Meteor Shower Incoming! ⚠", difficulty:"impossible", description:"Will kill you and your ears", color:"red"},\
{id:"zeus", name:"Zeus's Wrath", difficulty:"impossible", description:"Zeus Shall Smite You!", color:"gold"},\
{id:"snow", name:"Blizzard", difficulty:"normal", description:"MERRY CHRISTMAS!", color:"aqua"},\
{id:"wither_rain", name:"Withering Rain", difficulty:"medium", description:"Acid rain but more deadly", color:"aqua"},\
{id:"size_changer_small", name:"Shrinkage", difficulty:"normal", description:"become smol", color:"aqua"},\
{id:"amogus", name:"Sus Amongus", difficulty:"medium", description:"amogus ඞ", color:"red"},\
{id:"meltdown", name:"Nuclear Meltdown (B.O.B. Inc.)", difficulty:"medium", description:"B.O.B. Inc. dumps excess nuclear waste into the map", color:"aqua"},\
{id:"wind", name:"A Windy Day", difficulty:"medium", description:"♬ I Believe I can Flyyyyyy ♬", color:"aqua"},\
{id:"anvil_rain", name:"Watch out!", difficulty:"normal", description:"...for falling anvils!", color:"aqua"},\
{id:"3hm", name:"3 Heart Mode", difficulty:"hard", description:"New hardcore challenge just dropped?", color:"aqua"},\
{id:"mlg", name:"MLG Pro Gamer Moment",difficulty:"hard", description:"stop reading this and hit the clutch", color:"aqua"},\
{id:"laser", name:"The OMEGALASER", difficulty:"medium", description:"Blows a hole straight through the map", color:"aqua"},\
{id:"tnt", name:"Keep Moving!", difficulty:"hard", description:"...or DIE", color:"red"},\
{id:"cave_in", name:"Cave In", difficulty:"medium", description:"Blocks around you collapse", color:"aqua"},\
{id:"lava_rain", name:"Rain of Flames", difficulty:"normal", description:"BURN IT ALL!!", color:"aqua"},\
{id:"time_slow", name:"Time Dilation", difficulty:"normal", description:"Penguin Strategy troop speed be like:", color:"aqua"},\
{id:"diy", name:"DIY Chaos", difficulty:"normal", description:"I'm too lazy to make good events, make your own chaos", color:"aqua"},\
{id:"roots", name:"Roots in the Sky", difficulty:"normal", description:"Strange roots overtake the map", color:"aqua"},\
{id:"kelp_expand", name:"The Kelp Expanding", difficulty:"normal", description:"🌿 The kelp will consume us all! 🌿", color:"aqua"},\
{id:"confetti", name:"Confetti Cannon", difficulty:"normal", description:"Colors everywhere!", color:"aqua"},\
{id:"pufferfish_bombs", name:"Aquatic Airstrike", difficulty:"hard", description:"⚠ Pufferfish Incoming ⚠", color:"aqua"},\
{id:"hog_rider", name:"Hog Riders", difficulty:"normal", description:"HOG RIDA!", color:"aqua"},\
{id:"mitosis", name:"Cellular Mitosis", difficulty:"medium", description:"The Box becomes a life-sized Petri Dish (Shulker Edition)", color:"aqua"},\
{id:"shuffle", name:"World Corruption", difficulty:"normal", description:"what on earth is going on here", color:"aqua"},\
{id:"p2w", name:"Pay-To-Win Mode", difficulty:"normal", description:"gives you Chaos Coins only if you have a rank (AM or FM).", color:"yellow"},\
{id:"black_hole", name:"Black Hole", difficulty: "hard", description: "The event horizon approaches", "color": "black"},\
{id:"abduction", name:"Alien Abduction", difficulty: "hard", description: "take me to your leader", "color": "aqua"},\
{id:"supernova", name:"☄ SUPERNOVA ☄", difficulty: "hard", description: "the power of a dying star", "color": "light_purple"},\
{id:"magma", name:"Magma Hydra", difficulty: "medium", description: "Exponential growth functions, anyone?", "color": "aqua"},\
{id:"creaking", name:"Creaking Angels", difficulty: "hard", description: "don't blink.", "color": "aqua"},\
{id:"icarus", name:"The Power of Flight", difficulty: "normal", description: "don't fly too close to the sun", "color": "aqua"},\
{id:"gambling", name:"LETS GO GAMBLING", difficulty: "normal", description: "Want More? Try the Casino at the Mall!", "color": "aqua"},\
{id:"witherstorm", name:"WITHER STORM", difficulty: "impossible", description: "An Unstoppable Beast", "color": "dark_purple"},\
{id:"trader", name:"The Caravan", difficulty: "normal", description: "They're just some simple wandering traders", "color": "aqua"},\
{id:"clearlag", name:"Clearlag", difficulty: "normal", description: "Clears Lag", "color": "aqua"},\
{id:"corruption", name:"Sculk Corruption", difficulty: "normal", description: "Beware the Warden", "color": "aqua"},\
{id:"lavachicken", name:"Lava Chicken", difficulty: "normal", description: "CHICKEN JOCKEY", "color": "aqua"},\
{id:"ghast", name:"Ghasts", difficulty: "hard", description: "It's a Balloon?", "color": "aqua"},\
{id:"probros_attempt", name:"Home Infestation", difficulty: "medium", description: "Coming straight from YOUR house!", "color": "aqua"},\
{id:"immortal_snail", name:"Immortal Snail", difficulty: "hard", description: "It will chase you to the ends of the earth", "color": "aqua"},\
{id:"sand_worm", name:"T3ST FA1L3D", difficulty: "normal", description: "C0D3 Z3R0", "color": "aqua"},\
{id:"laser_pointere", name:"Laser Pointere", difficulty: "hard", description: "So I haveth a laser pointere...", "color": "aqua"},\
{id:"sunburn", name:"Sunburn", difficulty: "medium", description: "Burn in the Daylight", "color": "aqua"},\
{id:"withers", name:"Wither Apocalypse", difficulty: "impossible", description: "Nowhere is safe.", "color": "aqua"},\
{id:"dragon", name:"A.D.H.D.", difficulty:"hard", description:"Attention-Deficient Hyperactive Dragon", color:"dark_purple"},\
{id:"ragemold", name:"Ragemold", difficulty:"medium", description:"The Enraged Bird will become Mold.", color:"red"},\
{id:"tornado", name:"Tornado", difficulty:"impossible", description:"We're not in Kansas anymore...", color:"gray"},\
{id:"frogs", name:"All-Eating Frogs", difficulty:"hard", description:"Devourers of all that moves", color:"aqua"},\
{id:"lasers", name:"Laser Face", difficulty:"medium", description:"shoot a laser from your face", color:"aqua"},\
{id:"flood", name:"Flood Risk", difficulty:"hard", description:"Stay out of the water", color:"aqua"},\
{id:"worldborder", name:"World Border", difficulty:"medium", description:"Avoid the incoming wall", color:"aqua"},\
{id:"sinkhole", name:"Sinkhole", difficulty:"medium", description:"somebody forgot to check if the foundation was stable", color:"aqua"},\
{id:"crystals", name:"Crystal Ritual", difficulty:"medium", description:"Try not to interrupt it", color:"aqua"},\
{id:"bergentruck", name:"Bergentrück", difficulty:"hard", description:"DRIVING IN MY CAR, RIGHT AFTER A BEER!", color:"gold"},\
{id:"turtle", name:"Spinning Turtle Tower", difficulty:"normal", description:"you spin me right round baby right round", color:"aqua"},\
{id:"ultimate_tnt", name:"All the Explosions", difficulty:"special", description:"Yes Rico, Kaboom", color:"dark_red"},\
{id:"double", name:"DOUBLE EVENTS", difficulty:"special", description:"IT'S DOUBLE OR NOTHING", color:"dark_red"},\
{id:"chaos", name:"CHAOS", difficulty:"special", description:"I CAN DO ANYTHING!", color:"dark_red"}\
]}
#the number of disasters is (<number of this line> - 10)
# can confirm - Ragebird7200

execute store result storage code:disaster_system disasters_len int 1 run data get storage code:disaster_system disasters