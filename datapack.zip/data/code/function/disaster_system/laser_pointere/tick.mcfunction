execute store result score random tmp run random value 0..60
execute if score random tmp matches 0 run tag @a remove laser_pointere_target
execute if score random tmp matches 0 run tag @r[team=pvp] add laser_pointere_target

execute store result score random tmp run random value 1..3
execute if score random tmp matches 1 as @e[tag=laser_pointere] at @s facing entity @p[team=pvp,tag=laser_pointere_target] eyes run tp @s ^ ^ ^1
execute if score random tmp matches 2 as @e[tag=laser_pointere] at @s facing entity @p[team=pvp,tag=laser_pointere_target] eyes run tp @s ^ ^ ^3
execute if score random tmp matches 3 as @e[tag=laser_pointere] at @s facing entity @p[team=pvp,tag=laser_pointere_target] eyes run tp @s ^ ^ ^5
data merge entity @n[tag=laser_pointere] {teleport_duration:5}
execute at @n[tag=laser_pointere] run particle dust{color:16711680,scale:1.4}
execute as @e[x=-25,dx=50,y=-100,dy=400,z=-25,dz=50,type=!player,tag=!safe,type=!item,tag=!riding] at @s facing entity @n[tag=laser_pointere] eyes run tp @s ^ ^ ^0.2