scoreboard players set supernova_timer tmp 0
summon marker 0 0 0 {Tags:[spread]}