scoreboard players remove supernova_timer tmp 1
execute as @e[type=marker,tag=spread] at @s store result entity @s Pos[0] double 1 run random value -2..2
execute as @e[type=marker,tag=spread] at @s store result entity @s Pos[1] double 1 run random value -2..2
execute as @e[type=marker,tag=spread] at @s store result entity @s Pos[2] double 1 run random value -2..2

execute if score supernova_timer tmp matches -600.. positioned 0.0 0.0 0.0 at @e[type=marker,tag=spread,distance=..2] run summon ender_dragon ~ ~ ~ {Health:0,Silent:true}
execute if score supernova_timer tmp matches -600.. at @e[type=marker,tag=spread] run summon tnt ~ ~ ~ {fuse:80,NoGravity:true,block_state:{Name:"pink_stained_glass"}}

#summon text_display ~ ~ ~ {alignment:"center",text:{"obfuscated":true,"color":"#000000","text":"youcantseethisyet"},background:0,line_width:10}