effect give @r[team=pvp] poison 300
