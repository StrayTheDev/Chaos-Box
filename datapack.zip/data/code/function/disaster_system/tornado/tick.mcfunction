execute as @a[team=pvp] run function code:disaster_system/tornado/pull
execute as @e[type=breeze_wind_charge] run function code:disaster_system/tornado/pull
execute as @e[tag=event.black_hole_block] at @s facing 0 ~ 0 rotated ~-85 ~-3 run tp @s ^ ^ ^0.5 ~ ~

execute as @e[type=breeze_wind_charge] at @s if entity @n[type=breeze_wind_charge,distance=0.1..1] run kill @s


execute store result entity @n[tag=tornado] data.offset int 1.0 run random value 0..35
execute at @e[tag=tornado] run function code:disaster_system/tornado/summon with entity @n[tag=tornado] data

execute positioned 0 30 0 as @n[tag=tornado] store result entity @s Rotation[0] float 1 run random value -180..180
execute positioned 0 30 0 as @n[tag=tornado] store result entity @s Rotation[1] float 1 run random value -30..80
execute positioned 0 30 0 as @n[tag=tornado] at @s run function code:disaster_system/.misc/raycast/raycast

execute positioned 0 30 0 as @n[tag=tornado] store result entity @s Rotation[0] float 1 run random value -180..180
execute positioned 0 30 0 as @n[tag=tornado] store result entity @s Rotation[1] float 1 run random value -30..80
execute positioned 0 30 0 as @n[tag=tornado] at @s run function code:disaster_system/.misc/raycast/raycast
