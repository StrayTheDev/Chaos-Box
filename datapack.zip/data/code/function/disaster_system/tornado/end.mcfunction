kill @e[tag=tornado]
kill @e[tag=tornado-breeze]
execute as @e[type=block_display,tag=event.black_hole_block] at @s run function code:disaster_system/.misc/raycast/replace_falling_block with entity @s block_state
kill @e[tag=event.black_hole_block]