summon marker 0 0 0 {Tags:[pull]}

execute at @s unless predicate code:sky facing 0 ~ 0 rotated ~-70 ~1 positioned 0.0 0.0 0.0 as @n[tag=pull] run tp @s ^ ^ ^0.15 ~ ~
execute at @s if predicate code:sky facing 0 ~ 0 rotated ~-70 ~-10 positioned 0.0 0.0 0.0 as @n[tag=pull] run tp @s ^ ^ ^0.35 ~ ~

data modify entity @s Motion set from entity @n[tag=pull] Pos
kill @e[tag=pull]