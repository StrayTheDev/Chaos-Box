title @a times 0 50 10
title @a title [{"text":"/VOTE","bold":true,"color":"dark_green"}]
title @a subtitle [{"text":"this is your friendly reminder","color":"gray"}]

execute at @a run playsound entity.elder_guardian.curse master @a ~ ~ ~ 100
execute at @a run playsound entity.elder_guardian.curse master @a ~ ~ ~ 100
execute at @a run playsound entity.elder_guardian.curse master @a ~ ~ ~ 100
execute at @a run playsound entity.elder_guardian.curse master @a ~ ~ ~ 100
execute at @a run playsound entity.elder_guardian.curse master @a ~ ~ ~ 100
execute at @a run playsound entity.elder_guardian.curse master @a ~ ~ ~ 100
execute at @a run playsound entity.elder_guardian.curse master @a ~ ~ ~ 100
execute at @a run playsound entity.elder_guardian.curse master @a ~ ~ ~ 100
execute at @a run playsound entity.elder_guardian.curse master @a ~ ~ ~ 100
execute at @a run playsound entity.elder_guardian.curse master @a ~ ~ ~ 100

effect give @a slowness 3 100
effect give @a blindness 3