execute if entity @s[distance=..1.5] run particle dust{color:16711680,scale:0.05}
execute if entity @s[distance=1.5..2] run particle dust{color:16711680,scale:1.0}
execute if entity @s[distance=2..3] run particle dust{color:16711680,scale:0.6}
execute if entity @s[distance=3..4] run particle dust{color:16711680,scale:0.5}
execute if entity @s[distance=4..5] run particle dust{color:16711680,scale:0.4}
execute if entity @s[distance=5..6] run particle dust{color:16711680,scale:0.3}



execute if block ~ ~ ~ air if entity @s[distance=..6] positioned ^ ^ ^0.1 run function code:disaster_system/lasers/laser/tick
execute unless block ~ ~ ~ air unless block ~ ~ ~ bedrock unless block ~ ~ ~ barrier run setblock ~ ~ ~ air destroy