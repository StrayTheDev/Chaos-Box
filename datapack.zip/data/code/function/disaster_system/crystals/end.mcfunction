execute as @e[type=end_crystal] run damage @s 1 arrow
summon tnt 0 0 0 {explosion_power:20,fuse:0}