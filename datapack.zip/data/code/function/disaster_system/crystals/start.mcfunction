execute at @a[team=pvp] run summon end_crystal ~ ~ ~ {beam_target:[I;0,0,0],ShowBottom:false}
summon end_crystal 0 1.5 0 {ShowBottom:false}