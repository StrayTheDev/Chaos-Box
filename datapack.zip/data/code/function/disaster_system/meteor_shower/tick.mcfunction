# - By Ap
summon fireball 0 50 0 {Tags:["meteor_from_shower"], ExplosionPower:1b}

execute as @e[tag=meteor_from_shower] at @s run function code:disaster_system/.misc/randomize_pos
execute as @e[tag=meteor_from_shower] at @s run data modify entity @s Motion set value [1.0d, -5.0d, 1.0d]
tag @e[tag=meteor_from_shower] remove meteor_from_shower
