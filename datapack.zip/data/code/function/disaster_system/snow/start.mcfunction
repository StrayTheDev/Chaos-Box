weather rain 999s
fillbiome -25 -64 -25 27 200 27 minecraft:snowy_plains
gamerule snowAccumulationHeight 8
gamerule randomTickSpeed 400

execute as @a[team=pvp] run item replace entity @s saddle from entity @s armor.head
execute as @a[team=pvp] run item replace entity @s armor.head with ice[enchantments={binding_curse:1,vanishing_curse:1},tooltip_display={hide_tooltip:true},equippable={slot:head,camera_overlay:"misc/powder_snow_outline"},attribute_modifiers=[{type:"movement_speed",slot:head,amount:-0.5,operation:"add_multiplied_total",id:"freeze"},{type:"jump_strength",slot:head,amount:-1,operation:"add_multiplied_total",id:"freezer"}]]