fillbiome -25 -64 -25 27 200 27 minecraft:plains
fill -25 -64 -25 27 200 27 snow_block replace snow
fill -25 -64 -25 27 200 27 air replace snow_block
gamerule snowAccumulationHeight 1
gamerule randomTickSpeed 3
weather clear

execute as @a[team=pvp] run item replace entity @s armor.head from entity @s saddle
execute as @a[team=pvp] run item replace entity @s saddle with air