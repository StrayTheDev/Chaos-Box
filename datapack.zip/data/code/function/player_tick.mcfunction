execute if score @s player.deathDetection matches 1.. run function code:on_death
execute if entity @s[x=34,y=0,z=-75,dx=10,dy=6,dz=8] run function code:chaos_coins/shop/player/sauna
function code:stats
execute unless score @s stats.time_survived1 >= @s stats.time_survived run execute store result score @s stats.time_survived1 run scoreboard players get @s stats.time_survived


effect give @s[team=spawn] weakness 1 100 true


execute as @s[z=-25,dz=-100,x=7,dx=-14,dy=5] if entity @s[team=pvp] run team join spawn
gamemode survival @s[team=!spawn,team=!the_end,gamemode=adventure]
gamemode adventure @s[team=spawn,gamemode=survival]

execute as @s[team=pvp] unless entity @s[x=-25,dx=50,y=-100,dy=350,z=-25,dz=50] run damage @s 1 outside_border

team join sandbox @s[team=spawn,x=11,y=4,z=-73,dx=7,dy=4,dz=1]
team join spawn @s[team=sandbox,x=11,y=4,z=-65,dx=7,dy=4,dz=1]

execute if score @s gambling matches 1.. run function code:chaos_coins/shop/buy/gambling

execute as @s if items entity @s weapon.* totem_of_undying at @s positioned ~ -70 ~ if entity @s[distance=..5] run data merge entity @s {Motion:[0.0,14.0,0.0]}
execute as @s if items entity @s weapon.* totem_of_undying at @s positioned ~ -70 ~ if entity @s[distance=..5] run damage @s 100 arrow