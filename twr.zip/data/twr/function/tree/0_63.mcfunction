execute as @s[scores={nbs_twr=0..2720}] run function twr:tree/0_31
execute as @s[scores={nbs_twr=2560..5360}] run function twr:tree/32_63
