execute as @s[scores={nbs_twr=1600..1920}] run function twr:tree/20_21
execute as @s[scores={nbs_twr=1760..2160}] run function twr:tree/22_23
