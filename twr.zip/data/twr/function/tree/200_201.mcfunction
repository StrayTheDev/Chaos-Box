execute as @s[scores={nbs_twr=16000..16240,nbs_twr_t=..199}] run function twr:notes/200
execute as @s[scores={nbs_twr=16080..16320,nbs_twr_t=..200}] run function twr:notes/201
