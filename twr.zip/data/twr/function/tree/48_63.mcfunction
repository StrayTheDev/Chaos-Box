execute as @s[scores={nbs_twr=3840..4640}] run function twr:tree/48_55
execute as @s[scores={nbs_twr=4480..5360}] run function twr:tree/56_63
