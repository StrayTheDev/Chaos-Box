execute as @s[scores={nbs_twr=6240..6480,nbs_twr_t=..77}] run function twr:notes/78
execute as @s[scores={nbs_twr=6320..6560,nbs_twr_t=..78}] run function twr:notes/79
