execute as @s[scores={nbs_twr=17920..18720}] run function twr:tree/224_231
execute as @s[scores={nbs_twr=18560..19440}] run function twr:tree/232_239
