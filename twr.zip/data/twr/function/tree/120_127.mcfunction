execute as @s[scores={nbs_twr=9600..10080}] run function twr:tree/120_123
execute as @s[scores={nbs_twr=9920..10480}] run function twr:tree/124_127
