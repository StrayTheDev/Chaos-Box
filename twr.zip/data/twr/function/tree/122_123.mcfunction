execute as @s[scores={nbs_twr=9760..10000,nbs_twr_t=..121}] run function twr:notes/122
execute as @s[scores={nbs_twr=9840..10080,nbs_twr_t=..122}] run function twr:notes/123
