execute as @s[scores={nbs_twr=5120..5440}] run function twr:tree/64_65
execute as @s[scores={nbs_twr=5280..5680}] run function twr:tree/66_67
