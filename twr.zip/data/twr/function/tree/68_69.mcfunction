execute as @s[scores={nbs_twr=5440..5680,nbs_twr_t=..67}] run function twr:notes/68
execute as @s[scores={nbs_twr=5520..5760,nbs_twr_t=..68}] run function twr:notes/69
