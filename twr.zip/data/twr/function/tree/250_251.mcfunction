execute as @s[scores={nbs_twr=20000..20240,nbs_twr_t=..249}] run function twr:notes/250
execute as @s[scores={nbs_twr=20080..20320,nbs_twr_t=..250}] run function twr:notes/251
