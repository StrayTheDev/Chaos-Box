execute as @s[scores={nbs_twr=1760..2000,nbs_twr_t=..21}] run function twr:notes/22
execute as @s[scores={nbs_twr=1840..2080,nbs_twr_t=..22}] run function twr:notes/23
