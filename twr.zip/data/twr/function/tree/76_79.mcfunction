execute as @s[scores={nbs_twr=6080..6400}] run function twr:tree/76_77
execute as @s[scores={nbs_twr=6240..6640}] run function twr:tree/78_79
