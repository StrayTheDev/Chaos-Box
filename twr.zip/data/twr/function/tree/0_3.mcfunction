execute as @s[scores={nbs_twr=0..320}] run function twr:tree/0_1
execute as @s[scores={nbs_twr=160..560}] run function twr:tree/2_3
