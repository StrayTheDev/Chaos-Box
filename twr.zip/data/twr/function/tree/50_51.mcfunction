execute as @s[scores={nbs_twr=4000..4240,nbs_twr_t=..49}] run function twr:notes/50
execute as @s[scores={nbs_twr=4080..4320,nbs_twr_t=..50}] run function twr:notes/51
