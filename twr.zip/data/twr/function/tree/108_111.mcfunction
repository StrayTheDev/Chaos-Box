execute as @s[scores={nbs_twr=8640..8960}] run function twr:tree/108_109
execute as @s[scores={nbs_twr=8800..9200}] run function twr:tree/110_111
