execute as @s[scores={nbs_twr=9920..10160,nbs_twr_t=..123}] run function twr:notes/124
execute as @s[scores={nbs_twr=10000..10240,nbs_twr_t=..124}] run function twr:notes/125
