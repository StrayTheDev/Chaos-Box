execute as @s[scores={nbs_twr=2240..2480,nbs_twr_t=..27}] run function twr:notes/28
execute as @s[scores={nbs_twr=2320..2560,nbs_twr_t=..28}] run function twr:notes/29
