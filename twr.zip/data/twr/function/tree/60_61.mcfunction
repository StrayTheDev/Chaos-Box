execute as @s[scores={nbs_twr=4800..5040,nbs_twr_t=..59}] run function twr:notes/60
execute as @s[scores={nbs_twr=4880..5120,nbs_twr_t=..60}] run function twr:notes/61
