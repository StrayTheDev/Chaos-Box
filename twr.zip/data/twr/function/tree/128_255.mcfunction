execute as @s[scores={nbs_twr=10240..15520}] run function twr:tree/128_191
execute as @s[scores={nbs_twr=15360..20720}] run function twr:tree/192_255
