execute as @s[scores={nbs_twr=480..720,nbs_twr_t=..5}] run function twr:notes/6
execute as @s[scores={nbs_twr=560..800,nbs_twr_t=..6}] run function twr:notes/7
