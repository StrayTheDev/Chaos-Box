execute as @s[scores={nbs_twr=10560..10800,nbs_twr_t=..131}] run function twr:notes/132
execute as @s[scores={nbs_twr=10640..10880,nbs_twr_t=..132}] run function twr:notes/133
