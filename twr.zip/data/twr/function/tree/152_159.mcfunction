execute as @s[scores={nbs_twr=12160..12640}] run function twr:tree/152_155
execute as @s[scores={nbs_twr=12480..13040}] run function twr:tree/156_159
