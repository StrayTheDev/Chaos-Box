execute as @s[scores={nbs_twr=3520..3840}] run function twr:tree/44_45
execute as @s[scores={nbs_twr=3680..4080}] run function twr:tree/46_47
