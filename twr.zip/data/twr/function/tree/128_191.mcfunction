execute as @s[scores={nbs_twr=10240..12960}] run function twr:tree/128_159
execute as @s[scores={nbs_twr=12800..15600}] run function twr:tree/160_191
