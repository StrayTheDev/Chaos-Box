execute as @s[scores={nbs_twr=8320..8800}] run function twr:tree/104_107
execute as @s[scores={nbs_twr=8640..9200}] run function twr:tree/108_111
