execute as @s[scores={nbs_twr=10240..11040}] run function twr:tree/128_135
execute as @s[scores={nbs_twr=10880..11760}] run function twr:tree/136_143
