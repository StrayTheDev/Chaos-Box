execute as @s[scores={nbs_twr=5920..6160,nbs_twr_t=..73}] run function twr:notes/74
execute as @s[scores={nbs_twr=6000..6240,nbs_twr_t=..74}] run function twr:notes/75
