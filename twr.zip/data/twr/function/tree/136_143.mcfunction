execute as @s[scores={nbs_twr=10880..11360}] run function twr:tree/136_139
execute as @s[scores={nbs_twr=11200..11760}] run function twr:tree/140_143
