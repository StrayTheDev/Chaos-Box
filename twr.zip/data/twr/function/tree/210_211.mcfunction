execute as @s[scores={nbs_twr=16800..17040,nbs_twr_t=..209}] run function twr:notes/210
execute as @s[scores={nbs_twr=16880..17120,nbs_twr_t=..210}] run function twr:notes/211
