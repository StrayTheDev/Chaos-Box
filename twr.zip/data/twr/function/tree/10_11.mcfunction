execute as @s[scores={nbs_twr=800..1040,nbs_twr_t=..9}] run function twr:notes/10
execute as @s[scores={nbs_twr=880..1120,nbs_twr_t=..10}] run function twr:notes/11
