execute as @s[scores={nbs_twr=0..480}] run function twr:tree/0_3
execute as @s[scores={nbs_twr=320..880}] run function twr:tree/4_7
