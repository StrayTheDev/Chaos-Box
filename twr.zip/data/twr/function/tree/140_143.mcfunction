execute as @s[scores={nbs_twr=11200..11520}] run function twr:tree/140_141
execute as @s[scores={nbs_twr=11360..11760}] run function twr:tree/142_143
