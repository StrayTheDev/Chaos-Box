execute as @s[scores={nbs_twr=3200..3520}] run function twr:tree/40_41
execute as @s[scores={nbs_twr=3360..3760}] run function twr:tree/42_43
