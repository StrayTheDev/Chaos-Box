execute as @s[scores={nbs_twr=15520..15760,nbs_twr_t=..193}] run function twr:notes/194
execute as @s[scores={nbs_twr=15600..15840,nbs_twr_t=..194}] run function twr:notes/195
