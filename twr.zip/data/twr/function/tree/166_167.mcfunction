execute as @s[scores={nbs_twr=13280..13520,nbs_twr_t=..165}] run function twr:notes/166
execute as @s[scores={nbs_twr=13360..13600,nbs_twr_t=..166}] run function twr:notes/167
