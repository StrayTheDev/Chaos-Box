execute as @s[scores={nbs_twr=5120..6560}] run function twr:tree/64_79
execute as @s[scores={nbs_twr=6400..7920}] run function twr:tree/80_95
