execute as @s[scores={nbs_twr=8160..8400,nbs_twr_t=..101}] run function twr:notes/102
execute as @s[scores={nbs_twr=8240..8480,nbs_twr_t=..102}] run function twr:notes/103
