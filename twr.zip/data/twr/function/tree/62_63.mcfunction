execute as @s[scores={nbs_twr=4960..5200,nbs_twr_t=..61}] run function twr:notes/62
execute as @s[scores={nbs_twr=5040..5280,nbs_twr_t=..62}] run function twr:notes/63
