execute as @s[scores={nbs_twr=9440..9680,nbs_twr_t=..117}] run function twr:notes/118
execute as @s[scores={nbs_twr=9520..9760,nbs_twr_t=..118}] run function twr:notes/119
