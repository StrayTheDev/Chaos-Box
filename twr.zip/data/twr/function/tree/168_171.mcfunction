execute as @s[scores={nbs_twr=13440..13760}] run function twr:tree/168_169
execute as @s[scores={nbs_twr=13600..14000}] run function twr:tree/170_171
