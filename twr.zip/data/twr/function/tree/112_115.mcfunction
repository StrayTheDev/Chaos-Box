execute as @s[scores={nbs_twr=8960..9280}] run function twr:tree/112_113
execute as @s[scores={nbs_twr=9120..9520}] run function twr:tree/114_115
