execute as @s[scores={nbs_twr=20160..20480}] run function twr:tree/252_253
execute as @s[scores={nbs_twr=20320..20720}] run function twr:tree/254_255
