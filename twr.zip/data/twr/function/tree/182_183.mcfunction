execute as @s[scores={nbs_twr=14560..14800,nbs_twr_t=..181}] run function twr:notes/182
execute as @s[scores={nbs_twr=14640..14880,nbs_twr_t=..182}] run function twr:notes/183
