execute as @s[scores={nbs_twr=18240..18560}] run function twr:tree/228_229
execute as @s[scores={nbs_twr=18400..18800}] run function twr:tree/230_231
