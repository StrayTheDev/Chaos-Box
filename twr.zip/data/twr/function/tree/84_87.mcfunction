execute as @s[scores={nbs_twr=6720..7040}] run function twr:tree/84_85
execute as @s[scores={nbs_twr=6880..7280}] run function twr:tree/86_87
