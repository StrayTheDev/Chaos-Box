execute as @s[scores={nbs_twr=1920..2400}] run function twr:tree/24_27
execute as @s[scores={nbs_twr=2240..2800}] run function twr:tree/28_31
