execute as @s[scores={nbs_twr=5280..5520,nbs_twr_t=..65}] run function twr:notes/66
execute as @s[scores={nbs_twr=5360..5600,nbs_twr_t=..66}] run function twr:notes/67
