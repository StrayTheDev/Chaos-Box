execute as @s[scores={nbs_twr=15680..15920,nbs_twr_t=..195}] run function twr:notes/196
execute as @s[scores={nbs_twr=15760..16000,nbs_twr_t=..196}] run function twr:notes/197
