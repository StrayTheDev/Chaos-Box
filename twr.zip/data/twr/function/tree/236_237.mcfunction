execute as @s[scores={nbs_twr=18880..19120,nbs_twr_t=..235}] run function twr:notes/236
execute as @s[scores={nbs_twr=18960..19200,nbs_twr_t=..236}] run function twr:notes/237
