execute as @s[scores={nbs_twr=19360..19600,nbs_twr_t=..241}] run function twr:notes/242
execute as @s[scores={nbs_twr=19440..19680,nbs_twr_t=..242}] run function twr:notes/243
