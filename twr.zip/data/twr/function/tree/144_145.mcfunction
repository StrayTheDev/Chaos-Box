execute as @s[scores={nbs_twr=11520..11760,nbs_twr_t=..143}] run function twr:notes/144
execute as @s[scores={nbs_twr=11600..11840,nbs_twr_t=..144}] run function twr:notes/145
