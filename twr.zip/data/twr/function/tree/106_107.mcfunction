execute as @s[scores={nbs_twr=8480..8720,nbs_twr_t=..105}] run function twr:notes/106
execute as @s[scores={nbs_twr=8560..8800,nbs_twr_t=..106}] run function twr:notes/107
