execute as @s[scores={nbs_twr=11840..12080,nbs_twr_t=..147}] run function twr:notes/148
execute as @s[scores={nbs_twr=11920..12160,nbs_twr_t=..148}] run function twr:notes/149
