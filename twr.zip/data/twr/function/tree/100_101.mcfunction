execute as @s[scores={nbs_twr=8000..8240,nbs_twr_t=..99}] run function twr:notes/100
execute as @s[scores={nbs_twr=8080..8320,nbs_twr_t=..100}] run function twr:notes/101
