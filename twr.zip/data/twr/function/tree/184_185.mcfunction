execute as @s[scores={nbs_twr=14720..14960,nbs_twr_t=..183}] run function twr:notes/184
execute as @s[scores={nbs_twr=14800..15040,nbs_twr_t=..184}] run function twr:notes/185
