execute as @s[scores={nbs_twr=9600..9920}] run function twr:tree/120_121
execute as @s[scores={nbs_twr=9760..10160}] run function twr:tree/122_123
