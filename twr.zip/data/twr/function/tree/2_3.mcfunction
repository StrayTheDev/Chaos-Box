execute as @s[scores={nbs_twr=160..400,nbs_twr_t=..1}] run function twr:notes/2
execute as @s[scores={nbs_twr=240..480,nbs_twr_t=..2}] run function twr:notes/3
