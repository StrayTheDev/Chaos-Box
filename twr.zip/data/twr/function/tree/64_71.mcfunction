execute as @s[scores={nbs_twr=5120..5600}] run function twr:tree/64_67
execute as @s[scores={nbs_twr=5440..6000}] run function twr:tree/68_71
