execute as @s[scores={nbs_twr=2560..3040}] run function twr:tree/32_35
execute as @s[scores={nbs_twr=2880..3440}] run function twr:tree/36_39
