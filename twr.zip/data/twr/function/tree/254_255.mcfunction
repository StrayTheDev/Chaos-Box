execute as @s[scores={nbs_twr=20320..20560,nbs_twr_t=..253}] run function twr:notes/254
execute as @s[scores={nbs_twr=20400..20640,nbs_twr_t=..254}] run function twr:notes/255
