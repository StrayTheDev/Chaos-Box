execute as @s[scores={nbs_twr=14720..15200}] run function twr:tree/184_187
execute as @s[scores={nbs_twr=15040..15600}] run function twr:tree/188_191
