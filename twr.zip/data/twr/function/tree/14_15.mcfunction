execute as @s[scores={nbs_twr=1120..1360,nbs_twr_t=..13}] run function twr:notes/14
execute as @s[scores={nbs_twr=1200..1440,nbs_twr_t=..14}] run function twr:notes/15
