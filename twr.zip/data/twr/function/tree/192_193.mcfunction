execute as @s[scores={nbs_twr=15360..15600,nbs_twr_t=..191}] run function twr:notes/192
execute as @s[scores={nbs_twr=15440..15680,nbs_twr_t=..192}] run function twr:notes/193
