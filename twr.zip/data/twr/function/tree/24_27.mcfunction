execute as @s[scores={nbs_twr=1920..2240}] run function twr:tree/24_25
execute as @s[scores={nbs_twr=2080..2480}] run function twr:tree/26_27
