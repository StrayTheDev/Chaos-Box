execute as @s[scores={nbs_twr=19840..20320}] run function twr:tree/248_251
execute as @s[scores={nbs_twr=20160..20720}] run function twr:tree/252_255
