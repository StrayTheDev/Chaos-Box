execute as @s[scores={nbs_twr=6400..6880}] run function twr:tree/80_83
execute as @s[scores={nbs_twr=6720..7280}] run function twr:tree/84_87
