execute as @s[scores={nbs_twr=13760..14080}] run function twr:tree/172_173
execute as @s[scores={nbs_twr=13920..14320}] run function twr:tree/174_175
