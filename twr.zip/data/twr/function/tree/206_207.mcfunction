execute as @s[scores={nbs_twr=16480..16720,nbs_twr_t=..205}] run function twr:notes/206
execute as @s[scores={nbs_twr=16560..16800,nbs_twr_t=..206}] run function twr:notes/207
