execute as @s[scores={nbs_twr=10560..10880}] run function twr:tree/132_133
execute as @s[scores={nbs_twr=10720..11120}] run function twr:tree/134_135
