execute as @s[scores={nbs_twr=18560..18880}] run function twr:tree/232_233
execute as @s[scores={nbs_twr=18720..19120}] run function twr:tree/234_235
