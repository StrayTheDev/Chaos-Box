execute as @s[scores={nbs_twr=10880..11120,nbs_twr_t=..135}] run function twr:notes/136
execute as @s[scores={nbs_twr=10960..11200,nbs_twr_t=..136}] run function twr:notes/137
