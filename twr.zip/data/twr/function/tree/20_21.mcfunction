execute as @s[scores={nbs_twr=1600..1840,nbs_twr_t=..19}] run function twr:notes/20
execute as @s[scores={nbs_twr=1680..1920,nbs_twr_t=..20}] run function twr:notes/21
