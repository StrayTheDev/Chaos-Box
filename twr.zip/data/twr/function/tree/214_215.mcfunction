execute as @s[scores={nbs_twr=17120..17360,nbs_twr_t=..213}] run function twr:notes/214
execute as @s[scores={nbs_twr=17200..17440,nbs_twr_t=..214}] run function twr:notes/215
