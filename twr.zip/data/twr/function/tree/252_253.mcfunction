execute as @s[scores={nbs_twr=20160..20400,nbs_twr_t=..251}] run function twr:notes/252
execute as @s[scores={nbs_twr=20240..20480,nbs_twr_t=..252}] run function twr:notes/253
