execute as @s[scores={nbs_twr=19840..20080,nbs_twr_t=..247}] run function twr:notes/248
execute as @s[scores={nbs_twr=19920..20160,nbs_twr_t=..248}] run function twr:notes/249
