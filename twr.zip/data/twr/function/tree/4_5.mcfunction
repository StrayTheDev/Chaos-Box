execute as @s[scores={nbs_twr=320..560,nbs_twr_t=..3}] run function twr:notes/4
execute as @s[scores={nbs_twr=400..640,nbs_twr_t=..4}] run function twr:notes/5
