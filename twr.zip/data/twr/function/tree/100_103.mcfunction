execute as @s[scores={nbs_twr=8000..8320}] run function twr:tree/100_101
execute as @s[scores={nbs_twr=8160..8560}] run function twr:tree/102_103
