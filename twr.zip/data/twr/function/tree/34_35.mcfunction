execute as @s[scores={nbs_twr=2720..2960,nbs_twr_t=..33}] run function twr:notes/34
execute as @s[scores={nbs_twr=2800..3040,nbs_twr_t=..34}] run function twr:notes/35
