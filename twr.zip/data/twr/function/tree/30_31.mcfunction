execute as @s[scores={nbs_twr=2400..2640,nbs_twr_t=..29}] run function twr:notes/30
execute as @s[scores={nbs_twr=2480..2720,nbs_twr_t=..30}] run function twr:notes/31
