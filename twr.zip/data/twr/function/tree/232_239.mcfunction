execute as @s[scores={nbs_twr=18560..19040}] run function twr:tree/232_235
execute as @s[scores={nbs_twr=18880..19440}] run function twr:tree/236_239
