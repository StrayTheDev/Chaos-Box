execute as @s[scores={nbs_twr=6880..7120,nbs_twr_t=..85}] run function twr:notes/86
execute as @s[scores={nbs_twr=6960..7200,nbs_twr_t=..86}] run function twr:notes/87
