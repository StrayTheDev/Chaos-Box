execute as @s[scores={nbs_twr=5120..7840}] run function twr:tree/64_95
execute as @s[scores={nbs_twr=7680..10480}] run function twr:tree/96_127
