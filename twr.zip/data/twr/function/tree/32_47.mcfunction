execute as @s[scores={nbs_twr=2560..3360}] run function twr:tree/32_39
execute as @s[scores={nbs_twr=3200..4080}] run function twr:tree/40_47
