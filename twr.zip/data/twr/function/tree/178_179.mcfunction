execute as @s[scores={nbs_twr=14240..14480,nbs_twr_t=..177}] run function twr:notes/178
execute as @s[scores={nbs_twr=14320..14560,nbs_twr_t=..178}] run function twr:notes/179
