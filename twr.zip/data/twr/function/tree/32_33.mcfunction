execute as @s[scores={nbs_twr=2560..2800,nbs_twr_t=..31}] run function twr:notes/32
execute as @s[scores={nbs_twr=2640..2880,nbs_twr_t=..32}] run function twr:notes/33
