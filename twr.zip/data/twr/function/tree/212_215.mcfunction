execute as @s[scores={nbs_twr=16960..17280}] run function twr:tree/212_213
execute as @s[scores={nbs_twr=17120..17520}] run function twr:tree/214_215
