execute as @s[scores={nbs_twr=15200..15440,nbs_twr_t=..189}] run function twr:notes/190
execute as @s[scores={nbs_twr=15280..15520,nbs_twr_t=..190}] run function twr:notes/191
