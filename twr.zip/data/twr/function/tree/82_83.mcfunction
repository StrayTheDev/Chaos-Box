execute as @s[scores={nbs_twr=6560..6800,nbs_twr_t=..81}] run function twr:notes/82
execute as @s[scores={nbs_twr=6640..6880,nbs_twr_t=..82}] run function twr:notes/83
