execute as @s[scores={nbs_twr=6400..6640,nbs_twr_t=..79}] run function twr:notes/80
execute as @s[scores={nbs_twr=6480..6720,nbs_twr_t=..80}] run function twr:notes/81
