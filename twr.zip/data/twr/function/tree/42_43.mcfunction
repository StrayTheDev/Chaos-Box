execute as @s[scores={nbs_twr=3360..3600,nbs_twr_t=..41}] run function twr:notes/42
execute as @s[scores={nbs_twr=3440..3680,nbs_twr_t=..42}] run function twr:notes/43
