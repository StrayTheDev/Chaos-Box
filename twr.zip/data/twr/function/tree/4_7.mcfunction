execute as @s[scores={nbs_twr=320..640}] run function twr:tree/4_5
execute as @s[scores={nbs_twr=480..880}] run function twr:tree/6_7
