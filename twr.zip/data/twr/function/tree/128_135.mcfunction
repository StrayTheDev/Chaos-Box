execute as @s[scores={nbs_twr=10240..10720}] run function twr:tree/128_131
execute as @s[scores={nbs_twr=10560..11120}] run function twr:tree/132_135
