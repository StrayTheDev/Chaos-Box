execute as @s[scores={nbs_twr=12800..13120}] run function twr:tree/160_161
execute as @s[scores={nbs_twr=12960..13360}] run function twr:tree/162_163
