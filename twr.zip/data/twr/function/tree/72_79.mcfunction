execute as @s[scores={nbs_twr=5760..6240}] run function twr:tree/72_75
execute as @s[scores={nbs_twr=6080..6640}] run function twr:tree/76_79
