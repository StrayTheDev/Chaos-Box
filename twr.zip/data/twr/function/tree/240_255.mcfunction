execute as @s[scores={nbs_twr=19200..20000}] run function twr:tree/240_247
execute as @s[scores={nbs_twr=19840..20720}] run function twr:tree/248_255
