execute as @s[scores={nbs_twr=1280..1600}] run function twr:tree/16_17
execute as @s[scores={nbs_twr=1440..1840}] run function twr:tree/18_19
