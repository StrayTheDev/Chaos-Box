execute as @s[scores={nbs_twr=17280..17760}] run function twr:tree/216_219
execute as @s[scores={nbs_twr=17600..18160}] run function twr:tree/220_223
