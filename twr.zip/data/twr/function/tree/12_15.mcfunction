execute as @s[scores={nbs_twr=960..1280}] run function twr:tree/12_13
execute as @s[scores={nbs_twr=1120..1520}] run function twr:tree/14_15
