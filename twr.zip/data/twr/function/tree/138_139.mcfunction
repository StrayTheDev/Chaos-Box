execute as @s[scores={nbs_twr=11040..11280,nbs_twr_t=..137}] run function twr:notes/138
execute as @s[scores={nbs_twr=11120..11360,nbs_twr_t=..138}] run function twr:notes/139
