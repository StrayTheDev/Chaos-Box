execute as @s[scores={nbs_twr=14720..15040}] run function twr:tree/184_185
execute as @s[scores={nbs_twr=14880..15280}] run function twr:tree/186_187
