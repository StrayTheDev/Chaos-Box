execute as @s[scores={nbs_twr=18720..18960,nbs_twr_t=..233}] run function twr:notes/234
execute as @s[scores={nbs_twr=18800..19040,nbs_twr_t=..234}] run function twr:notes/235
