execute as @s[scores={nbs_twr=15360..16800}] run function twr:tree/192_207
execute as @s[scores={nbs_twr=16640..18160}] run function twr:tree/208_223
