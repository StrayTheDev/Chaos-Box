execute as @s[scores={nbs_twr=0..10400}] run function twr:tree/0_127
execute as @s[scores={nbs_twr=10240..20720}] run function twr:tree/128_255
