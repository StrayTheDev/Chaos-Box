execute as @s[scores={nbs_twr=17600..17920}] run function twr:tree/220_221
execute as @s[scores={nbs_twr=17760..18160}] run function twr:tree/222_223
