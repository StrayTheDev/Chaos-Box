execute as @s[scores={nbs_twr=12800..13600}] run function twr:tree/160_167
execute as @s[scores={nbs_twr=13440..14320}] run function twr:tree/168_175
