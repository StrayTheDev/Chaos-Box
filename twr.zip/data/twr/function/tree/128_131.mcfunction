execute as @s[scores={nbs_twr=10240..10560}] run function twr:tree/128_129
execute as @s[scores={nbs_twr=10400..10800}] run function twr:tree/130_131
