execute as @s[scores={nbs_twr=17760..18000,nbs_twr_t=..221}] run function twr:notes/222
execute as @s[scores={nbs_twr=17840..18080,nbs_twr_t=..222}] run function twr:notes/223
