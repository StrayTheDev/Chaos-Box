execute as @s[scores={nbs_twr=14080..14400}] run function twr:tree/176_177
execute as @s[scores={nbs_twr=14240..14640}] run function twr:tree/178_179
