execute as @s[scores={nbs_twr=5120..5360,nbs_twr_t=..63}] run function twr:notes/64
execute as @s[scores={nbs_twr=5200..5440,nbs_twr_t=..64}] run function twr:notes/65
