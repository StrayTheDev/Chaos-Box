execute as @s[scores={nbs_twr=2880..3200}] run function twr:tree/36_37
execute as @s[scores={nbs_twr=3040..3440}] run function twr:tree/38_39
