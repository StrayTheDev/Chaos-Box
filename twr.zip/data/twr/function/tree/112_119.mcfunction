execute as @s[scores={nbs_twr=8960..9440}] run function twr:tree/112_115
execute as @s[scores={nbs_twr=9280..9840}] run function twr:tree/116_119
