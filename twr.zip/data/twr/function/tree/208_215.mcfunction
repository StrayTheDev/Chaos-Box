execute as @s[scores={nbs_twr=16640..17120}] run function twr:tree/208_211
execute as @s[scores={nbs_twr=16960..17520}] run function twr:tree/212_215
