execute as @s[scores={nbs_twr=11200..11440,nbs_twr_t=..139}] run function twr:notes/140
execute as @s[scores={nbs_twr=11280..11520,nbs_twr_t=..140}] run function twr:notes/141
