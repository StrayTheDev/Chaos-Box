execute as @s[scores={nbs_twr=1280..1520,nbs_twr_t=..15}] run function twr:notes/16
execute as @s[scores={nbs_twr=1360..1600,nbs_twr_t=..16}] run function twr:notes/17
