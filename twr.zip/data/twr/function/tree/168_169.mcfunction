execute as @s[scores={nbs_twr=13440..13680,nbs_twr_t=..167}] run function twr:notes/168
execute as @s[scores={nbs_twr=13520..13760,nbs_twr_t=..168}] run function twr:notes/169
