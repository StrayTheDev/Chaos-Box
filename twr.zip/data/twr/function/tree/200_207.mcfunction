execute as @s[scores={nbs_twr=16000..16480}] run function twr:tree/200_203
execute as @s[scores={nbs_twr=16320..16880}] run function twr:tree/204_207
