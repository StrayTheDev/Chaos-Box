execute as @s[scores={nbs_twr=19200..19440,nbs_twr_t=..239}] run function twr:notes/240
execute as @s[scores={nbs_twr=19280..19520,nbs_twr_t=..240}] run function twr:notes/241
