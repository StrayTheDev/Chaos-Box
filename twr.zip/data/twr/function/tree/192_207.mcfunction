execute as @s[scores={nbs_twr=15360..16160}] run function twr:tree/192_199
execute as @s[scores={nbs_twr=16000..16880}] run function twr:tree/200_207
