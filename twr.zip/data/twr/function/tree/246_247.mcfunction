execute as @s[scores={nbs_twr=19680..19920,nbs_twr_t=..245}] run function twr:notes/246
execute as @s[scores={nbs_twr=19760..20000,nbs_twr_t=..246}] run function twr:notes/247
