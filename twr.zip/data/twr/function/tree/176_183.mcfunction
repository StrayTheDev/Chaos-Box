execute as @s[scores={nbs_twr=14080..14560}] run function twr:tree/176_179
execute as @s[scores={nbs_twr=14400..14960}] run function twr:tree/180_183
