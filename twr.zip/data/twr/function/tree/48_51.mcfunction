execute as @s[scores={nbs_twr=3840..4160}] run function twr:tree/48_49
execute as @s[scores={nbs_twr=4000..4400}] run function twr:tree/50_51
