execute as @s[scores={nbs_twr=11520..12000}] run function twr:tree/144_147
execute as @s[scores={nbs_twr=11840..12400}] run function twr:tree/148_151
