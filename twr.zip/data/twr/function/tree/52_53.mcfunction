execute as @s[scores={nbs_twr=4160..4400,nbs_twr_t=..51}] run function twr:notes/52
execute as @s[scores={nbs_twr=4240..4480,nbs_twr_t=..52}] run function twr:notes/53
