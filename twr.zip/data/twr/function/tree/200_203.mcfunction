execute as @s[scores={nbs_twr=16000..16320}] run function twr:tree/200_201
execute as @s[scores={nbs_twr=16160..16560}] run function twr:tree/202_203
