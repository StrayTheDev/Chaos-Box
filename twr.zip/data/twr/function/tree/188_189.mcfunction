execute as @s[scores={nbs_twr=15040..15280,nbs_twr_t=..187}] run function twr:notes/188
execute as @s[scores={nbs_twr=15120..15360,nbs_twr_t=..188}] run function twr:notes/189
