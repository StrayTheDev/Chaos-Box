execute as @s[scores={nbs_twr=2080..2320,nbs_twr_t=..25}] run function twr:notes/26
execute as @s[scores={nbs_twr=2160..2400,nbs_twr_t=..26}] run function twr:notes/27
