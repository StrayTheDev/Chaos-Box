execute as @s[scores={nbs_twr=15360..18080}] run function twr:tree/192_223
execute as @s[scores={nbs_twr=17920..20720}] run function twr:tree/224_255
