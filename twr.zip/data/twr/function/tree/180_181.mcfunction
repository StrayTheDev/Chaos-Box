execute as @s[scores={nbs_twr=14400..14640,nbs_twr_t=..179}] run function twr:notes/180
execute as @s[scores={nbs_twr=14480..14720,nbs_twr_t=..180}] run function twr:notes/181
