execute as @s[scores={nbs_twr=0..1440}] run function twr:tree/0_15
execute as @s[scores={nbs_twr=1280..2800}] run function twr:tree/16_31
