execute as @s[scores={nbs_twr=11680..11920,nbs_twr_t=..145}] run function twr:notes/146
execute as @s[scores={nbs_twr=11760..12000,nbs_twr_t=..146}] run function twr:notes/147
