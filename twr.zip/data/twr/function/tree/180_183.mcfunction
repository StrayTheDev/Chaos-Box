execute as @s[scores={nbs_twr=14400..14720}] run function twr:tree/180_181
execute as @s[scores={nbs_twr=14560..14960}] run function twr:tree/182_183
