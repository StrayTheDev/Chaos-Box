execute as @s[scores={nbs_twr=17280..17600}] run function twr:tree/216_217
execute as @s[scores={nbs_twr=17440..17840}] run function twr:tree/218_219
