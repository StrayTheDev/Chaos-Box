execute as @s[scores={nbs_twr=15040..15360}] run function twr:tree/188_189
execute as @s[scores={nbs_twr=15200..15600}] run function twr:tree/190_191
