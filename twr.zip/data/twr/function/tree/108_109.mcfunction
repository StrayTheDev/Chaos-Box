execute as @s[scores={nbs_twr=8640..8880,nbs_twr_t=..107}] run function twr:notes/108
execute as @s[scores={nbs_twr=8720..8960,nbs_twr_t=..108}] run function twr:notes/109
