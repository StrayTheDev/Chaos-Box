execute as @s[scores={nbs_twr=1440..1680,nbs_twr_t=..17}] run function twr:notes/18
execute as @s[scores={nbs_twr=1520..1760,nbs_twr_t=..18}] run function twr:notes/19
