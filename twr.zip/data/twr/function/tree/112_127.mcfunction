execute as @s[scores={nbs_twr=8960..9760}] run function twr:tree/112_119
execute as @s[scores={nbs_twr=9600..10480}] run function twr:tree/120_127
