execute as @s[scores={nbs_twr=9120..9360,nbs_twr_t=..113}] run function twr:notes/114
execute as @s[scores={nbs_twr=9200..9440,nbs_twr_t=..114}] run function twr:notes/115
