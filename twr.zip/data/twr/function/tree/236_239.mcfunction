execute as @s[scores={nbs_twr=18880..19200}] run function twr:tree/236_237
execute as @s[scores={nbs_twr=19040..19440}] run function twr:tree/238_239
