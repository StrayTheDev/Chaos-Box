execute as @s[scores={nbs_twr=17920..18240}] run function twr:tree/224_225
execute as @s[scores={nbs_twr=18080..18480}] run function twr:tree/226_227
