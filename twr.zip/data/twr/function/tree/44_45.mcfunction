execute as @s[scores={nbs_twr=3520..3760,nbs_twr_t=..43}] run function twr:notes/44
execute as @s[scores={nbs_twr=3600..3840,nbs_twr_t=..44}] run function twr:notes/45
