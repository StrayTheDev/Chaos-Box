execute as @s[scores={nbs_twr=2240..2560}] run function twr:tree/28_29
execute as @s[scores={nbs_twr=2400..2800}] run function twr:tree/30_31
