execute as @s[scores={nbs_twr=11360..11600,nbs_twr_t=..141}] run function twr:notes/142
execute as @s[scores={nbs_twr=11440..11680,nbs_twr_t=..142}] run function twr:notes/143
