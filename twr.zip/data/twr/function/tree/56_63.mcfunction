execute as @s[scores={nbs_twr=4480..4960}] run function twr:tree/56_59
execute as @s[scores={nbs_twr=4800..5360}] run function twr:tree/60_63
