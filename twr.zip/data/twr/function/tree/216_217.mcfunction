execute as @s[scores={nbs_twr=17280..17520,nbs_twr_t=..215}] run function twr:notes/216
execute as @s[scores={nbs_twr=17360..17600,nbs_twr_t=..216}] run function twr:notes/217
