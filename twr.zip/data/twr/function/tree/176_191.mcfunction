execute as @s[scores={nbs_twr=14080..14880}] run function twr:tree/176_183
execute as @s[scores={nbs_twr=14720..15600}] run function twr:tree/184_191
