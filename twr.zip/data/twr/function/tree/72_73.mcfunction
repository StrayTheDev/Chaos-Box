execute as @s[scores={nbs_twr=5760..6000,nbs_twr_t=..71}] run function twr:notes/72
execute as @s[scores={nbs_twr=5840..6080,nbs_twr_t=..72}] run function twr:notes/73
