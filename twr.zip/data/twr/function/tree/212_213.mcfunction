execute as @s[scores={nbs_twr=16960..17200,nbs_twr_t=..211}] run function twr:notes/212
execute as @s[scores={nbs_twr=17040..17280,nbs_twr_t=..212}] run function twr:notes/213
