execute as @s[scores={nbs_twr=17920..18400}] run function twr:tree/224_227
execute as @s[scores={nbs_twr=18240..18800}] run function twr:tree/228_231
