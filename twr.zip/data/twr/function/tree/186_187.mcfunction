execute as @s[scores={nbs_twr=14880..15120,nbs_twr_t=..185}] run function twr:notes/186
execute as @s[scores={nbs_twr=14960..15200,nbs_twr_t=..186}] run function twr:notes/187
