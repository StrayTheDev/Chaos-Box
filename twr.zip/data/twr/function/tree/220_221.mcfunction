execute as @s[scores={nbs_twr=17600..17840,nbs_twr_t=..219}] run function twr:notes/220
execute as @s[scores={nbs_twr=17680..17920,nbs_twr_t=..220}] run function twr:notes/221
