execute as @s[scores={nbs_twr=19840..20160}] run function twr:tree/248_249
execute as @s[scores={nbs_twr=20000..20400}] run function twr:tree/250_251
