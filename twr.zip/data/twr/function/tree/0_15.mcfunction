execute as @s[scores={nbs_twr=0..800}] run function twr:tree/0_7
execute as @s[scores={nbs_twr=640..1520}] run function twr:tree/8_15
