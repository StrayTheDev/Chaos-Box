execute as @s[scores={nbs_twr=4480..4720,nbs_twr_t=..55}] run function twr:notes/56
execute as @s[scores={nbs_twr=4560..4800,nbs_twr_t=..56}] run function twr:notes/57
