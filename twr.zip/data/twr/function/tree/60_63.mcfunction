execute as @s[scores={nbs_twr=4800..5120}] run function twr:tree/60_61
execute as @s[scores={nbs_twr=4960..5360}] run function twr:tree/62_63
