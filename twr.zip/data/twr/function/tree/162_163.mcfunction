execute as @s[scores={nbs_twr=12960..13200,nbs_twr_t=..161}] run function twr:notes/162
execute as @s[scores={nbs_twr=13040..13280,nbs_twr_t=..162}] run function twr:notes/163
