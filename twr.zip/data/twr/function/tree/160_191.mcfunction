execute as @s[scores={nbs_twr=12800..14240}] run function twr:tree/160_175
execute as @s[scores={nbs_twr=14080..15600}] run function twr:tree/176_191
