execute as @s[scores={nbs_twr=12160..12480}] run function twr:tree/152_153
execute as @s[scores={nbs_twr=12320..12720}] run function twr:tree/154_155
