execute as @s[scores={nbs_twr=10240..11680}] run function twr:tree/128_143
execute as @s[scores={nbs_twr=11520..13040}] run function twr:tree/144_159
