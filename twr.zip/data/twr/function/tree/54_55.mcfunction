execute as @s[scores={nbs_twr=4320..4560,nbs_twr_t=..53}] run function twr:notes/54
execute as @s[scores={nbs_twr=4400..4640,nbs_twr_t=..54}] run function twr:notes/55
