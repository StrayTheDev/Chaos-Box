execute as @s[scores={nbs_twr=1280..2080}] run function twr:tree/16_23
execute as @s[scores={nbs_twr=1920..2800}] run function twr:tree/24_31
