execute as @s[scores={nbs_twr=15680..16000}] run function twr:tree/196_197
execute as @s[scores={nbs_twr=15840..16240}] run function twr:tree/198_199
