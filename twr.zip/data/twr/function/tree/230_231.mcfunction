execute as @s[scores={nbs_twr=18400..18640,nbs_twr_t=..229}] run function twr:notes/230
execute as @s[scores={nbs_twr=18480..18720,nbs_twr_t=..230}] run function twr:notes/231
