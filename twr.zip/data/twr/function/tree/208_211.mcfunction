execute as @s[scores={nbs_twr=16640..16960}] run function twr:tree/208_209
execute as @s[scores={nbs_twr=16800..17200}] run function twr:tree/210_211
