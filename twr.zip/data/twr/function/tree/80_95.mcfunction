execute as @s[scores={nbs_twr=6400..7200}] run function twr:tree/80_87
execute as @s[scores={nbs_twr=7040..7920}] run function twr:tree/88_95
