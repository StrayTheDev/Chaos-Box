execute as @s[scores={nbs_twr=4480..4800}] run function twr:tree/56_57
execute as @s[scores={nbs_twr=4640..5040}] run function twr:tree/58_59
