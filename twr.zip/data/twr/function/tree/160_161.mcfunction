execute as @s[scores={nbs_twr=12800..13040,nbs_twr_t=..159}] run function twr:notes/160
execute as @s[scores={nbs_twr=12880..13120,nbs_twr_t=..160}] run function twr:notes/161
