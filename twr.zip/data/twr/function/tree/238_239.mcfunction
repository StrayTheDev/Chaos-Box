execute as @s[scores={nbs_twr=19040..19280,nbs_twr_t=..237}] run function twr:notes/238
execute as @s[scores={nbs_twr=19120..19360,nbs_twr_t=..238}] run function twr:notes/239
