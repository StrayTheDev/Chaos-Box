execute as @s[scores={nbs_twr=960..1200,nbs_twr_t=..11}] run function twr:notes/12
execute as @s[scores={nbs_twr=1040..1280,nbs_twr_t=..12}] run function twr:notes/13
