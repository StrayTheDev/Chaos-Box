execute as @s[scores={nbs_twr=3040..3280,nbs_twr_t=..37}] run function twr:notes/38
execute as @s[scores={nbs_twr=3120..3360,nbs_twr_t=..38}] run function twr:notes/39
