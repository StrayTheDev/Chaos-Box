execute as @s[scores={nbs_twr=11840..12160}] run function twr:tree/148_149
execute as @s[scores={nbs_twr=12000..12400}] run function twr:tree/150_151
