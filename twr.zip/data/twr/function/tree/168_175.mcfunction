execute as @s[scores={nbs_twr=13440..13920}] run function twr:tree/168_171
execute as @s[scores={nbs_twr=13760..14320}] run function twr:tree/172_175
