execute as @s[scores={nbs_twr=6720..6960,nbs_twr_t=..83}] run function twr:notes/84
execute as @s[scores={nbs_twr=6800..7040,nbs_twr_t=..84}] run function twr:notes/85
