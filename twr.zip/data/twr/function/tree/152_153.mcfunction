execute as @s[scores={nbs_twr=12160..12400,nbs_twr_t=..151}] run function twr:notes/152
execute as @s[scores={nbs_twr=12240..12480,nbs_twr_t=..152}] run function twr:notes/153
