execute as @s[scores={nbs_twr=16320..16640}] run function twr:tree/204_205
execute as @s[scores={nbs_twr=16480..16880}] run function twr:tree/206_207
