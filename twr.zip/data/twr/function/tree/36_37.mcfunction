execute as @s[scores={nbs_twr=2880..3120,nbs_twr_t=..35}] run function twr:notes/36
execute as @s[scores={nbs_twr=2960..3200,nbs_twr_t=..36}] run function twr:notes/37
