execute as @s[scores={nbs_twr=9600..9840,nbs_twr_t=..119}] run function twr:notes/120
execute as @s[scores={nbs_twr=9680..9920,nbs_twr_t=..120}] run function twr:notes/121
