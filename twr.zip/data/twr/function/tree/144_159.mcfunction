execute as @s[scores={nbs_twr=11520..12320}] run function twr:tree/144_151
execute as @s[scores={nbs_twr=12160..13040}] run function twr:tree/152_159
