execute as @s[scores={nbs_twr=0..5280}] run function twr:tree/0_63
execute as @s[scores={nbs_twr=5120..10480}] run function twr:tree/64_127
