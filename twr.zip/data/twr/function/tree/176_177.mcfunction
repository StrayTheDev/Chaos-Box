execute as @s[scores={nbs_twr=14080..14320,nbs_twr_t=..175}] run function twr:notes/176
execute as @s[scores={nbs_twr=14160..14400,nbs_twr_t=..176}] run function twr:notes/177
