execute as @s[scores={nbs_twr=2560..4000}] run function twr:tree/32_47
execute as @s[scores={nbs_twr=3840..5360}] run function twr:tree/48_63
