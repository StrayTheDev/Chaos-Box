execute as @s[scores={nbs_twr=18240..18480,nbs_twr_t=..227}] run function twr:notes/228
execute as @s[scores={nbs_twr=18320..18560,nbs_twr_t=..228}] run function twr:notes/229
