execute as @s[scores={nbs_twr=4160..4480}] run function twr:tree/52_53
execute as @s[scores={nbs_twr=4320..4720}] run function twr:tree/54_55
