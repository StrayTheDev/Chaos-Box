execute as @s[scores={nbs_twr=12480..12800}] run function twr:tree/156_157
execute as @s[scores={nbs_twr=12640..13040}] run function twr:tree/158_159
