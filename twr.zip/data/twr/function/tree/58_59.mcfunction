execute as @s[scores={nbs_twr=4640..4880,nbs_twr_t=..57}] run function twr:notes/58
execute as @s[scores={nbs_twr=4720..4960,nbs_twr_t=..58}] run function twr:notes/59
