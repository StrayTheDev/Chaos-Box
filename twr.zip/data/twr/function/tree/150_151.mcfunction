execute as @s[scores={nbs_twr=12000..12240,nbs_twr_t=..149}] run function twr:notes/150
execute as @s[scores={nbs_twr=12080..12320,nbs_twr_t=..150}] run function twr:notes/151
