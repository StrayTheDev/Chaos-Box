execute as @s[scores={nbs_twr=15840..16080,nbs_twr_t=..197}] run function twr:notes/198
execute as @s[scores={nbs_twr=15920..16160,nbs_twr_t=..198}] run function twr:notes/199
