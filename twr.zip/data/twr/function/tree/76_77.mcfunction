execute as @s[scores={nbs_twr=6080..6320,nbs_twr_t=..75}] run function twr:notes/76
execute as @s[scores={nbs_twr=6160..6400,nbs_twr_t=..76}] run function twr:notes/77
