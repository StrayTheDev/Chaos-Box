execute as @s[scores={nbs_twr=3200..3440,nbs_twr_t=..39}] run function twr:notes/40
execute as @s[scores={nbs_twr=3280..3520,nbs_twr_t=..40}] run function twr:notes/41
