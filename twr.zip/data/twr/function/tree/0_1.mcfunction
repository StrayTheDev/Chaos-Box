execute as @s[scores={nbs_twr=0..240,nbs_twr_t=..-1}] run function twr:notes/0
execute as @s[scores={nbs_twr=80..320,nbs_twr_t=..0}] run function twr:notes/1
