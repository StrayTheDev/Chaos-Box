execute as @s[scores={nbs_twr=6400..6720}] run function twr:tree/80_81
execute as @s[scores={nbs_twr=6560..6960}] run function twr:tree/82_83
