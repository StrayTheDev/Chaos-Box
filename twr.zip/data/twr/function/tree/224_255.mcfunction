execute as @s[scores={nbs_twr=17920..19360}] run function twr:tree/224_239
execute as @s[scores={nbs_twr=19200..20720}] run function twr:tree/240_255
