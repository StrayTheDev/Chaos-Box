execute as @s[scores={nbs_twr=5440..5760}] run function twr:tree/68_69
execute as @s[scores={nbs_twr=5600..6000}] run function twr:tree/70_71
