execute as @s[scores={nbs_twr=10240..10480,nbs_twr_t=..127}] run function twr:notes/128
execute as @s[scores={nbs_twr=10320..10560,nbs_twr_t=..128}] run function twr:notes/129
