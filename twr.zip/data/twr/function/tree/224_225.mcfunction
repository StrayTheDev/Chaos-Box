execute as @s[scores={nbs_twr=17920..18160,nbs_twr_t=..223}] run function twr:notes/224
execute as @s[scores={nbs_twr=18000..18240,nbs_twr_t=..224}] run function twr:notes/225
