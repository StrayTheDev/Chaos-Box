execute as @s[scores={nbs_twr=5600..5840,nbs_twr_t=..69}] run function twr:notes/70
execute as @s[scores={nbs_twr=5680..5920,nbs_twr_t=..70}] run function twr:notes/71
