execute as @s[scores={nbs_twr=18560..18800,nbs_twr_t=..231}] run function twr:notes/232
execute as @s[scores={nbs_twr=18640..18880,nbs_twr_t=..232}] run function twr:notes/233
