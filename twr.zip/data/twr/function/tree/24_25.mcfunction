execute as @s[scores={nbs_twr=1920..2160,nbs_twr_t=..23}] run function twr:notes/24
execute as @s[scores={nbs_twr=2000..2240,nbs_twr_t=..24}] run function twr:notes/25
