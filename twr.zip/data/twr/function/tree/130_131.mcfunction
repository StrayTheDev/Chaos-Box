execute as @s[scores={nbs_twr=10400..10640,nbs_twr_t=..129}] run function twr:notes/130
execute as @s[scores={nbs_twr=10480..10720,nbs_twr_t=..130}] run function twr:notes/131
