execute as @s[scores={nbs_twr=3840..4080,nbs_twr_t=..47}] run function twr:notes/48
execute as @s[scores={nbs_twr=3920..4160,nbs_twr_t=..48}] run function twr:notes/49
