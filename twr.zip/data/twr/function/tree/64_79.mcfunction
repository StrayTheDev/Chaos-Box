execute as @s[scores={nbs_twr=5120..5920}] run function twr:tree/64_71
execute as @s[scores={nbs_twr=5760..6640}] run function twr:tree/72_79
