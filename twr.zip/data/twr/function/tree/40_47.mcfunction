execute as @s[scores={nbs_twr=3200..3680}] run function twr:tree/40_43
execute as @s[scores={nbs_twr=3520..4080}] run function twr:tree/44_47
