execute as @s[scores={nbs_twr=8800..9040,nbs_twr_t=..109}] run function twr:notes/110
execute as @s[scores={nbs_twr=8880..9120,nbs_twr_t=..110}] run function twr:notes/111
