execute as @s[scores={nbs_twr=19520..19760,nbs_twr_t=..243}] run function twr:notes/244
execute as @s[scores={nbs_twr=19600..19840,nbs_twr_t=..244}] run function twr:notes/245
