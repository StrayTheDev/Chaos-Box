execute as @s[scores={nbs_twr=2560..2880}] run function twr:tree/32_33
execute as @s[scores={nbs_twr=2720..3120}] run function twr:tree/34_35
