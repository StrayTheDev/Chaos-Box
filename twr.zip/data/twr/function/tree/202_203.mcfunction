execute as @s[scores={nbs_twr=16160..16400,nbs_twr_t=..201}] run function twr:notes/202
execute as @s[scores={nbs_twr=16240..16480,nbs_twr_t=..202}] run function twr:notes/203
