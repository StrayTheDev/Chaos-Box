execute as @s[scores={nbs_twr=12480..12720,nbs_twr_t=..155}] run function twr:notes/156
execute as @s[scores={nbs_twr=12560..12800,nbs_twr_t=..156}] run function twr:notes/157
