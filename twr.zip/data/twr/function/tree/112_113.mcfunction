execute as @s[scores={nbs_twr=8960..9200,nbs_twr_t=..111}] run function twr:notes/112
execute as @s[scores={nbs_twr=9040..9280,nbs_twr_t=..112}] run function twr:notes/113
