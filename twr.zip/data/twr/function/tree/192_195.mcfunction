execute as @s[scores={nbs_twr=15360..15680}] run function twr:tree/192_193
execute as @s[scores={nbs_twr=15520..15920}] run function twr:tree/194_195
