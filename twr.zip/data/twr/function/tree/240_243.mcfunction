execute as @s[scores={nbs_twr=19200..19520}] run function twr:tree/240_241
execute as @s[scores={nbs_twr=19360..19760}] run function twr:tree/242_243
