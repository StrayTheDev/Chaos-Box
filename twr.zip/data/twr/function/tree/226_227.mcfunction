execute as @s[scores={nbs_twr=18080..18320,nbs_twr_t=..225}] run function twr:notes/226
execute as @s[scores={nbs_twr=18160..18400,nbs_twr_t=..226}] run function twr:notes/227
