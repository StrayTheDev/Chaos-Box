execute as @s[scores={nbs_twr=1280..1760}] run function twr:tree/16_19
execute as @s[scores={nbs_twr=1600..2160}] run function twr:tree/20_23
