execute as @s[scores={nbs_twr=10080..10320,nbs_twr_t=..125}] run function twr:notes/126
execute as @s[scores={nbs_twr=10160..10400,nbs_twr_t=..126}] run function twr:notes/127
