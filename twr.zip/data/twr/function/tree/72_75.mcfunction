execute as @s[scores={nbs_twr=5760..6080}] run function twr:tree/72_73
execute as @s[scores={nbs_twr=5920..6320}] run function twr:tree/74_75
