execute as @s[scores={nbs_twr=12640..12880,nbs_twr_t=..157}] run function twr:notes/158
execute as @s[scores={nbs_twr=12720..12960,nbs_twr_t=..158}] run function twr:notes/159
