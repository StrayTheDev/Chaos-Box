execute as @s[scores={nbs_twr=9280..9520,nbs_twr_t=..115}] run function twr:notes/116
execute as @s[scores={nbs_twr=9360..9600,nbs_twr_t=..116}] run function twr:notes/117
