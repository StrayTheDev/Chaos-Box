execute as @s[scores={nbs_twr=16640..17440}] run function twr:tree/208_215
execute as @s[scores={nbs_twr=17280..18160}] run function twr:tree/216_223
