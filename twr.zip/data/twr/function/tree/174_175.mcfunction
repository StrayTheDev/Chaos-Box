execute as @s[scores={nbs_twr=13920..14160,nbs_twr_t=..173}] run function twr:notes/174
execute as @s[scores={nbs_twr=14000..14240,nbs_twr_t=..174}] run function twr:notes/175
