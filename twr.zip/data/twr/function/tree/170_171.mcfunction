execute as @s[scores={nbs_twr=13600..13840,nbs_twr_t=..169}] run function twr:notes/170
execute as @s[scores={nbs_twr=13680..13920,nbs_twr_t=..170}] run function twr:notes/171
