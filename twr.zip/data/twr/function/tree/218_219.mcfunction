execute as @s[scores={nbs_twr=17440..17680,nbs_twr_t=..217}] run function twr:notes/218
execute as @s[scores={nbs_twr=17520..17760,nbs_twr_t=..218}] run function twr:notes/219
