execute as @s[scores={nbs_twr=3680..3920,nbs_twr_t=..45}] run function twr:notes/46
execute as @s[scores={nbs_twr=3760..4000,nbs_twr_t=..46}] run function twr:notes/47
