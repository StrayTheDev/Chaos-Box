execute as @s[scores={nbs_twr=9280..9600}] run function twr:tree/116_117
execute as @s[scores={nbs_twr=9440..9840}] run function twr:tree/118_119
