execute as @s[scores={nbs_twr=8320..8640}] run function twr:tree/104_105
execute as @s[scores={nbs_twr=8480..8880}] run function twr:tree/106_107
