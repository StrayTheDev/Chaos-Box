execute as @s[scores={nbs_twr=16640..16880,nbs_twr_t=..207}] run function twr:notes/208
execute as @s[scores={nbs_twr=16720..16960,nbs_twr_t=..208}] run function twr:notes/209
