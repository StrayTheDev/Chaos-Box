execute as @s[scores={nbs_twr=13760..14000,nbs_twr_t=..171}] run function twr:notes/172
execute as @s[scores={nbs_twr=13840..14080,nbs_twr_t=..172}] run function twr:notes/173
