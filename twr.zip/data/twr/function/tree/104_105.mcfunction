execute as @s[scores={nbs_twr=8320..8560,nbs_twr_t=..103}] run function twr:notes/104
execute as @s[scores={nbs_twr=8400..8640,nbs_twr_t=..104}] run function twr:notes/105
