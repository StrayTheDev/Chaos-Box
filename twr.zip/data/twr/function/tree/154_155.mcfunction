execute as @s[scores={nbs_twr=12320..12560,nbs_twr_t=..153}] run function twr:notes/154
execute as @s[scores={nbs_twr=12400..12640,nbs_twr_t=..154}] run function twr:notes/155
