execute as @s[scores={nbs_twr=16320..16560,nbs_twr_t=..203}] run function twr:notes/204
execute as @s[scores={nbs_twr=16400..16640,nbs_twr_t=..204}] run function twr:notes/205
