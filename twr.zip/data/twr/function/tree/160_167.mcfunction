execute as @s[scores={nbs_twr=12800..13280}] run function twr:tree/160_163
execute as @s[scores={nbs_twr=13120..13680}] run function twr:tree/164_167
