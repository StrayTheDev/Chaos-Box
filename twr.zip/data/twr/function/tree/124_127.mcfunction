execute as @s[scores={nbs_twr=9920..10240}] run function twr:tree/124_125
execute as @s[scores={nbs_twr=10080..10480}] run function twr:tree/126_127
