execute as @s[scores={nbs_twr=10880..11200}] run function twr:tree/136_137
execute as @s[scores={nbs_twr=11040..11440}] run function twr:tree/138_139
