execute as @s[scores={nbs_twr=10720..10960,nbs_twr_t=..133}] run function twr:notes/134
execute as @s[scores={nbs_twr=10800..11040,nbs_twr_t=..134}] run function twr:notes/135
