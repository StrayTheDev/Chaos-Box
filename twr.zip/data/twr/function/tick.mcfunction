execute as @a[tag=nbs_twr] run scoreboard players operation @s nbs_twr += speed nbs_twr
execute as @a[tag=nbs_twr] run function twr:tree/0_255