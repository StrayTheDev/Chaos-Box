tag @s add nbs_twr
scoreboard players set @s nbs_twr_t -1
