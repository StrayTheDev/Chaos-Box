tag @s remove nbs_twr
scoreboard players reset @s nbs_twr
scoreboard players reset @s nbs_twr_t