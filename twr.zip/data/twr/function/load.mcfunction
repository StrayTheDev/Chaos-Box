scoreboard objectives add nbs_twr dummy
scoreboard objectives add nbs_twr_t dummy
scoreboard players set speed nbs_twr 50