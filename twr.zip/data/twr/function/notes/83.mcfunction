execute at @s run playsound minecraft:block.note_block.harp record @a ~ ~ ~ 12.04 1.681793
execute at @s run playsound minecraft:block.note_block.bass record @a ~ ~ ~ 12.04 1.681793
execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 1.681793
scoreboard players set @s nbs_twr_t 83