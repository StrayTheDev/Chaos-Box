execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 0.749154
execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 0.749154
execute at @s run playsound minecraft:block.note_block.pling record @a ~ ~ ~ 12.04 0.749154
execute at @s run playsound minecraft:block.note_block.bit record @a ~ ~ ~ 12.04 0.749154
execute at @s run playsound minecraft:block.note_block.bit record @a ~ ~ ~ 12.04 0.749154
execute at @s run playsound minecraft:block.note_block.bass record @a ~ ~ ~ 12.04 1.059463
execute at @s run playsound minecraft:block.note_block.harp record @a ~ ~ ~ 12.04 1.259921
execute at @s run playsound minecraft:block.note_block.bass record @a ~ ~ ~ 12.04 1.259921
execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 1.259921
scoreboard players set @s nbs_twr_t 120