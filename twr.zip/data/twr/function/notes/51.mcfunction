execute at @s run playsound minecraft:block.note_block.harp record @a ~ ~ ~ 12.04 2.000000
execute at @s run playsound minecraft:block.note_block.bass record @a ~ ~ ~ 12.04 2.000000
execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 2.000000
scoreboard players set @s nbs_twr_t 51