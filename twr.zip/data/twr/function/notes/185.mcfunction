execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 0.500000
execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 0.629961
scoreboard players set @s nbs_twr_t 185