execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 1.122462
execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 1.122462
execute at @s run playsound minecraft:block.note_block.pling record @a ~ ~ ~ 12.04 1.122462
execute at @s run playsound minecraft:block.note_block.bit record @a ~ ~ ~ 12.04 1.122462
execute at @s run playsound minecraft:block.note_block.bit record @a ~ ~ ~ 12.04 1.122462
execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 0.840896
execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 0.840896
execute at @s run playsound minecraft:block.note_block.bass record @a ~ ~ ~ 12.04 0.840896
scoreboard players set @s nbs_twr_t 164