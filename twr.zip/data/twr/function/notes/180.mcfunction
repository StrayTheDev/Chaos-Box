execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 0.629961
execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 0.629961
execute at @s run playsound minecraft:block.note_block.pling record @a ~ ~ ~ 12.04 0.629961
execute at @s run playsound minecraft:block.note_block.bit record @a ~ ~ ~ 12.04 0.629961
execute at @s run playsound minecraft:block.note_block.bit record @a ~ ~ ~ 12.04 0.629961
execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 0.890899
execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 0.629961
execute at @s run playsound minecraft:block.note_block.bass record @a ~ ~ ~ 12.04 0.629961
scoreboard players set @s nbs_twr_t 180