execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 0.840896
execute at @s run playsound minecraft:block.note_block.flute record @a ~ ~ ~ 12.04 0.629961
execute at @s run playsound minecraft:block.note_block.snare record @a ~ ~ ~ 12.04 0.793701
execute at @s run playsound minecraft:block.note_block.harp record @a ~ ~ ~ 12.04 0.629961
scoreboard players set @s nbs_twr_t 254