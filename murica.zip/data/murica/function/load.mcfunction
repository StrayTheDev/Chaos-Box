scoreboard objectives add nbs_murica dummy
scoreboard objectives add nbs_murica_t dummy
scoreboard players set speed nbs_murica 40