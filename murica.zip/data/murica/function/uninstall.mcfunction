tag @e remove nbs_murica
scoreboard objectives remove nbs_murica
scoreboard objectives remove nbs_murica_t
datapack disable "murica"
tellraw @s ["",{"text":"[NBS] ","color":"gold","bold":true},{"text":"Data pack ","color":"yellow"},{"text":"murica","color":"gold","underlined":true},{"text":" uninstalled successfully. You may now remove it from your data pack folder.","color":"yellow"}]