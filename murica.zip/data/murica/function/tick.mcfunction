execute as @a[tag=nbs_murica] run scoreboard players operation @s nbs_murica += speed nbs_murica
execute as @a[tag=nbs_murica] at @s run function murica:tree/0_127