tag @s remove nbs_murica
scoreboard players reset @s nbs_murica
scoreboard players reset @s nbs_murica_t