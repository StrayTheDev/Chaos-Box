tag @s add nbs_murica
scoreboard players set @s nbs_murica_t -1
