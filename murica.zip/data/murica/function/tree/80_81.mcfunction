execute as @s[scores={nbs_murica=6400..6640,nbs_murica_t=..79}] run function murica:notes/80
execute as @s[scores={nbs_murica=6480..6720,nbs_murica_t=..80}] run function murica:notes/81
