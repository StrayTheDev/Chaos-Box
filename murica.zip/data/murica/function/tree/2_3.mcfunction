execute as @s[scores={nbs_murica=160..400,nbs_murica_t=..1}] run function murica:notes/2
execute as @s[scores={nbs_murica=240..480,nbs_murica_t=..2}] run function murica:notes/3
