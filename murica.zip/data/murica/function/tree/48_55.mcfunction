execute as @s[scores={nbs_murica=3840..4320}] run function murica:tree/48_51
execute as @s[scores={nbs_murica=4160..4720}] run function murica:tree/52_55
