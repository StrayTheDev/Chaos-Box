execute as @s[scores={nbs_murica=8640..8960}] run function murica:tree/108_109
execute as @s[scores={nbs_murica=8800..9200}] run function murica:tree/110_111
