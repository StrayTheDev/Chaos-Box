execute as @s[scores={nbs_murica=640..880,nbs_murica_t=..7}] run function murica:notes/8
execute as @s[scores={nbs_murica=720..960,nbs_murica_t=..8}] run function murica:notes/9
