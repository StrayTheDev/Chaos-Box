execute as @s[scores={nbs_murica=4960..5200,nbs_murica_t=..61}] run function murica:notes/62
execute as @s[scores={nbs_murica=5040..5280,nbs_murica_t=..62}] run function murica:notes/63
