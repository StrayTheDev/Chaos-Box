execute as @s[scores={nbs_murica=4480..4720,nbs_murica_t=..55}] run function murica:notes/56
execute as @s[scores={nbs_murica=4560..4800,nbs_murica_t=..56}] run function murica:notes/57
