execute as @s[scores={nbs_murica=4320..4560,nbs_murica_t=..53}] run function murica:notes/54
execute as @s[scores={nbs_murica=4400..4640,nbs_murica_t=..54}] run function murica:notes/55
