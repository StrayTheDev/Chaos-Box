execute as @s[scores={nbs_murica=9280..9600}] run function murica:tree/116_117
execute as @s[scores={nbs_murica=9440..9840}] run function murica:tree/118_119
