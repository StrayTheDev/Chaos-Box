execute as @s[scores={nbs_murica=8800..9040,nbs_murica_t=..109}] run function murica:notes/110
