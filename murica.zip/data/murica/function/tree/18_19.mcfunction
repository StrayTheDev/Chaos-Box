execute as @s[scores={nbs_murica=1440..1680,nbs_murica_t=..17}] run function murica:notes/18
execute as @s[scores={nbs_murica=1520..1760,nbs_murica_t=..18}] run function murica:notes/19
