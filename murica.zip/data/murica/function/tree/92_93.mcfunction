execute as @s[scores={nbs_murica=7360..7600,nbs_murica_t=..91}] run function murica:notes/92
execute as @s[scores={nbs_murica=7440..7680,nbs_murica_t=..92}] run function murica:notes/93
