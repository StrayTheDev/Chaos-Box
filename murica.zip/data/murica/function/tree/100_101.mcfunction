execute as @s[scores={nbs_murica=8000..8240,nbs_murica_t=..99}] run function murica:notes/100
