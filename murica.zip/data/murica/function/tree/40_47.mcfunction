execute as @s[scores={nbs_murica=3200..3680}] run function murica:tree/40_43
execute as @s[scores={nbs_murica=3520..4080}] run function murica:tree/44_47
