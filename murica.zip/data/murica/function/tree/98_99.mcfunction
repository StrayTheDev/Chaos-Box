execute as @s[scores={nbs_murica=7840..8080,nbs_murica_t=..97}] run function murica:notes/98
execute as @s[scores={nbs_murica=7920..8160,nbs_murica_t=..98}] run function murica:notes/99
