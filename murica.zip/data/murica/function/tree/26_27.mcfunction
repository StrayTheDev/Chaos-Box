execute as @s[scores={nbs_murica=2080..2320,nbs_murica_t=..25}] run function murica:notes/26
execute as @s[scores={nbs_murica=2160..2400,nbs_murica_t=..26}] run function murica:notes/27
