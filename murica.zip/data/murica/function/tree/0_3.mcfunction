execute as @s[scores={nbs_murica=0..320}] run function murica:tree/0_1
execute as @s[scores={nbs_murica=160..560}] run function murica:tree/2_3
