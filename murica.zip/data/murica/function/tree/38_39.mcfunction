execute as @s[scores={nbs_murica=3040..3280,nbs_murica_t=..37}] run function murica:notes/38
execute as @s[scores={nbs_murica=3120..3360,nbs_murica_t=..38}] run function murica:notes/39
