execute as @s[scores={nbs_murica=1600..1840,nbs_murica_t=..19}] run function murica:notes/20
execute as @s[scores={nbs_murica=1680..1920,nbs_murica_t=..20}] run function murica:notes/21
