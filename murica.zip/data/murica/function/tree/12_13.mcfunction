execute as @s[scores={nbs_murica=960..1200,nbs_murica_t=..11}] run function murica:notes/12
