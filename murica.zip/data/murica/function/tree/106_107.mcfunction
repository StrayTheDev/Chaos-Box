execute as @s[scores={nbs_murica=8480..8720,nbs_murica_t=..105}] run function murica:notes/106
