execute as @s[scores={nbs_murica=6880..7120,nbs_murica_t=..85}] run function murica:notes/86
