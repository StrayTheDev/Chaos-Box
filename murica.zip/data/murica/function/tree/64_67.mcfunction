execute as @s[scores={nbs_murica=5120..5440}] run function murica:tree/64_65
execute as @s[scores={nbs_murica=5280..5680}] run function murica:tree/66_67
