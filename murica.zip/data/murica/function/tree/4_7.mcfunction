execute as @s[scores={nbs_murica=320..640}] run function murica:tree/4_5
execute as @s[scores={nbs_murica=480..880}] run function murica:tree/6_7
