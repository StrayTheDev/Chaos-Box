execute as @s[scores={nbs_murica=9920..10160,nbs_murica_t=..123}] run function murica:notes/124
