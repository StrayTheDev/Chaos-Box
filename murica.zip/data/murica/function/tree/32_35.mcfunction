execute as @s[scores={nbs_murica=2560..2880}] run function murica:tree/32_33
execute as @s[scores={nbs_murica=2720..3120}] run function murica:tree/34_35
