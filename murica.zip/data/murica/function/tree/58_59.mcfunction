execute as @s[scores={nbs_murica=4640..4880,nbs_murica_t=..57}] run function murica:notes/58
execute as @s[scores={nbs_murica=4720..4960,nbs_murica_t=..58}] run function murica:notes/59
