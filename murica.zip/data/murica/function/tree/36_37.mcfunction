execute as @s[scores={nbs_murica=2880..3120,nbs_murica_t=..35}] run function murica:notes/36
execute as @s[scores={nbs_murica=2960..3200,nbs_murica_t=..36}] run function murica:notes/37
