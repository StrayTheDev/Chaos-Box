execute as @s[scores={nbs_murica=7360..7680}] run function murica:tree/92_93
execute as @s[scores={nbs_murica=7520..7920}] run function murica:tree/94_95
