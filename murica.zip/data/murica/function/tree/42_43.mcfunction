execute as @s[scores={nbs_murica=3360..3600,nbs_murica_t=..41}] run function murica:notes/42
execute as @s[scores={nbs_murica=3440..3680,nbs_murica_t=..42}] run function murica:notes/43
