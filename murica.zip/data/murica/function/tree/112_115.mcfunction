execute as @s[scores={nbs_murica=8960..9280}] run function murica:tree/112_113
execute as @s[scores={nbs_murica=9120..9520}] run function murica:tree/114_115
