execute as @s[scores={nbs_murica=1280..1600}] run function murica:tree/16_17
execute as @s[scores={nbs_murica=1440..1840}] run function murica:tree/18_19
