execute as @s[scores={nbs_murica=1120..1360,nbs_murica_t=..13}] run function murica:notes/14
