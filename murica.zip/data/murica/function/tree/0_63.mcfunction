execute as @s[scores={nbs_murica=0..2720}] run function murica:tree/0_31
execute as @s[scores={nbs_murica=2560..5360}] run function murica:tree/32_63
