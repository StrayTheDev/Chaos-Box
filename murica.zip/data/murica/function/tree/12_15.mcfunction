execute as @s[scores={nbs_murica=960..1280}] run function murica:tree/12_13
execute as @s[scores={nbs_murica=1120..1520}] run function murica:tree/14_15
