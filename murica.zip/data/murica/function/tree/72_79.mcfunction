execute as @s[scores={nbs_murica=5760..6240}] run function murica:tree/72_75
execute as @s[scores={nbs_murica=6080..6640}] run function murica:tree/76_79
