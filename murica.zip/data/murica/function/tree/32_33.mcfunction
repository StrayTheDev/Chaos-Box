execute as @s[scores={nbs_murica=2560..2800,nbs_murica_t=..31}] run function murica:notes/32
execute as @s[scores={nbs_murica=2640..2880,nbs_murica_t=..32}] run function murica:notes/33
