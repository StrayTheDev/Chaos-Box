execute as @s[scores={nbs_murica=4480..4800}] run function murica:tree/56_57
execute as @s[scores={nbs_murica=4640..5040}] run function murica:tree/58_59
