execute as @s[scores={nbs_murica=3680..3920,nbs_murica_t=..45}] run function murica:notes/46
execute as @s[scores={nbs_murica=3760..4000,nbs_murica_t=..46}] run function murica:notes/47
