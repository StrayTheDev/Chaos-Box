execute as @s[scores={nbs_murica=7040..7280,nbs_murica_t=..87}] run function murica:notes/88
execute as @s[scores={nbs_murica=7120..7360,nbs_murica_t=..88}] run function murica:notes/89
