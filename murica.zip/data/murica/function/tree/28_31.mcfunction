execute as @s[scores={nbs_murica=2240..2560}] run function murica:tree/28_29
execute as @s[scores={nbs_murica=2400..2800}] run function murica:tree/30_31
