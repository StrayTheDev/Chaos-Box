execute as @s[scores={nbs_murica=7680..8160}] run function murica:tree/96_99
execute as @s[scores={nbs_murica=8000..8560}] run function murica:tree/100_103
