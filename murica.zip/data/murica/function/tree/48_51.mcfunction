execute as @s[scores={nbs_murica=3840..4160}] run function murica:tree/48_49
execute as @s[scores={nbs_murica=4000..4400}] run function murica:tree/50_51
