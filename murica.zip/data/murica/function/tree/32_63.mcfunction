execute as @s[scores={nbs_murica=2560..4000}] run function murica:tree/32_47
execute as @s[scores={nbs_murica=3840..5360}] run function murica:tree/48_63
