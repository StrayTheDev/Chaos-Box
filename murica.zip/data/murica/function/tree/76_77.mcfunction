execute as @s[scores={nbs_murica=6080..6320,nbs_murica_t=..75}] run function murica:notes/76
