execute as @s[scores={nbs_murica=9600..9840,nbs_murica_t=..119}] run function murica:notes/120
