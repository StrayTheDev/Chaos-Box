execute as @s[scores={nbs_murica=1280..1520,nbs_murica_t=..15}] run function murica:notes/16
execute as @s[scores={nbs_murica=1360..1600,nbs_murica_t=..16}] run function murica:notes/17
