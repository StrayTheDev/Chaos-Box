execute as @s[scores={nbs_murica=0..5280}] run function murica:tree/0_63
execute as @s[scores={nbs_murica=5120..10480}] run function murica:tree/64_127
