execute as @s[scores={nbs_murica=8640..8880,nbs_murica_t=..107}] run function murica:notes/108
