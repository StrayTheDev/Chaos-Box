execute as @s[scores={nbs_murica=800..1040,nbs_murica_t=..9}] run function murica:notes/10
execute as @s[scores={nbs_murica=880..1120,nbs_murica_t=..10}] run function murica:notes/11
