execute as @s[scores={nbs_murica=8960..9200,nbs_murica_t=..111}] run function murica:notes/112
execute as @s[scores={nbs_murica=9040..9280,nbs_murica_t=..112}] run function murica:notes/113
