execute as @s[scores={nbs_murica=7520..7760,nbs_murica_t=..93}] run function murica:notes/94
