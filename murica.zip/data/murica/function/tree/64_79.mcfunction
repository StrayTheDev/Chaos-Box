execute as @s[scores={nbs_murica=5120..5920}] run function murica:tree/64_71
execute as @s[scores={nbs_murica=5760..6640}] run function murica:tree/72_79
