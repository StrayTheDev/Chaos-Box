execute as @s[scores={nbs_murica=2880..3200}] run function murica:tree/36_37
execute as @s[scores={nbs_murica=3040..3440}] run function murica:tree/38_39
