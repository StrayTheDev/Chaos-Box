execute as @s[scores={nbs_murica=7680..7920,nbs_murica_t=..95}] run function murica:notes/96
