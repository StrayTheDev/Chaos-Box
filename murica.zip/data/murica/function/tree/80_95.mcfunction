execute as @s[scores={nbs_murica=6400..7200}] run function murica:tree/80_87
execute as @s[scores={nbs_murica=7040..7920}] run function murica:tree/88_95
