execute as @s[scores={nbs_murica=8320..8560,nbs_murica_t=..103}] run function murica:notes/104
