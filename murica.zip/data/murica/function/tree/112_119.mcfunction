execute as @s[scores={nbs_murica=8960..9440}] run function murica:tree/112_115
execute as @s[scores={nbs_murica=9280..9840}] run function murica:tree/116_119
