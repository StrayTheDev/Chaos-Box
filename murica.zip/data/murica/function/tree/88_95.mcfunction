execute as @s[scores={nbs_murica=7040..7520}] run function murica:tree/88_91
execute as @s[scores={nbs_murica=7360..7920}] run function murica:tree/92_95
