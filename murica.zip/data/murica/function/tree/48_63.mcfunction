execute as @s[scores={nbs_murica=3840..4640}] run function murica:tree/48_55
execute as @s[scores={nbs_murica=4480..5360}] run function murica:tree/56_63
