execute as @s[scores={nbs_murica=5600..5840,nbs_murica_t=..69}] run function murica:notes/70
execute as @s[scores={nbs_murica=5680..5920,nbs_murica_t=..70}] run function murica:notes/71
