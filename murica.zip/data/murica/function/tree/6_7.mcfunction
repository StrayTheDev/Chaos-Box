execute as @s[scores={nbs_murica=480..720,nbs_murica_t=..5}] run function murica:notes/6
execute as @s[scores={nbs_murica=560..800,nbs_murica_t=..6}] run function murica:notes/7
