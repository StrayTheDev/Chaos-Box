execute as @s[scores={nbs_murica=0..1440}] run function murica:tree/0_15
execute as @s[scores={nbs_murica=1280..2800}] run function murica:tree/16_31
