execute as @s[scores={nbs_murica=6400..6880}] run function murica:tree/80_83
execute as @s[scores={nbs_murica=6720..7280}] run function murica:tree/84_87
