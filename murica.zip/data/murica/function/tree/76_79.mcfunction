execute as @s[scores={nbs_murica=6080..6400}] run function murica:tree/76_77
execute as @s[scores={nbs_murica=6240..6640}] run function murica:tree/78_79
