execute as @s[scores={nbs_murica=9600..9920}] run function murica:tree/120_121
