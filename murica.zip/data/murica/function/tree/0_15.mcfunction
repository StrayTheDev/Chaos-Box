execute as @s[scores={nbs_murica=0..800}] run function murica:tree/0_7
execute as @s[scores={nbs_murica=640..1520}] run function murica:tree/8_15
