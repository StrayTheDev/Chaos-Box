execute as @s[scores={nbs_murica=3840..4080,nbs_murica_t=..47}] run function murica:notes/48
execute as @s[scores={nbs_murica=3920..4160,nbs_murica_t=..48}] run function murica:notes/49
