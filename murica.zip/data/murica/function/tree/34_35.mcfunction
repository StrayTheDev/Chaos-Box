execute as @s[scores={nbs_murica=2720..2960,nbs_murica_t=..33}] run function murica:notes/34
execute as @s[scores={nbs_murica=2800..3040,nbs_murica_t=..34}] run function murica:notes/35
