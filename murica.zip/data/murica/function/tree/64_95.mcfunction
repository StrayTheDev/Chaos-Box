execute as @s[scores={nbs_murica=5120..6560}] run function murica:tree/64_79
execute as @s[scores={nbs_murica=6400..7920}] run function murica:tree/80_95
