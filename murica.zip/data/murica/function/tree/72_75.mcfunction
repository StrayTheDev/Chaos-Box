execute as @s[scores={nbs_murica=5760..6080}] run function murica:tree/72_73
execute as @s[scores={nbs_murica=5920..6320}] run function murica:tree/74_75
