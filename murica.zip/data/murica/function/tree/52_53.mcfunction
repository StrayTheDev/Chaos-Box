execute as @s[scores={nbs_murica=4160..4400,nbs_murica_t=..51}] run function murica:notes/52
