execute as @s[scores={nbs_murica=5440..5680,nbs_murica_t=..67}] run function murica:notes/68
