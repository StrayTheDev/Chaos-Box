execute as @s[scores={nbs_murica=6240..6480,nbs_murica_t=..77}] run function murica:notes/78
