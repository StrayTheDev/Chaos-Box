execute as @s[scores={nbs_murica=6720..6960,nbs_murica_t=..83}] run function murica:notes/84
execute as @s[scores={nbs_murica=6800..7040,nbs_murica_t=..84}] run function murica:notes/85
