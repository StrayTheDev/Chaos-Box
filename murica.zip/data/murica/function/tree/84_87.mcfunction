execute as @s[scores={nbs_murica=6720..7040}] run function murica:tree/84_85
execute as @s[scores={nbs_murica=6880..7280}] run function murica:tree/86_87
