execute as @s[scores={nbs_murica=3520..3760,nbs_murica_t=..43}] run function murica:notes/44
execute as @s[scores={nbs_murica=3600..3840,nbs_murica_t=..44}] run function murica:notes/45
