execute as @s[scores={nbs_murica=8160..8400,nbs_murica_t=..101}] run function murica:notes/102
execute as @s[scores={nbs_murica=8240..8480,nbs_murica_t=..102}] run function murica:notes/103
