execute as @s[scores={nbs_murica=0..480}] run function murica:tree/0_3
execute as @s[scores={nbs_murica=320..880}] run function murica:tree/4_7
