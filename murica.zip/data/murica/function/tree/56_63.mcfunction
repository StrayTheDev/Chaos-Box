execute as @s[scores={nbs_murica=4480..4960}] run function murica:tree/56_59
execute as @s[scores={nbs_murica=4800..5360}] run function murica:tree/60_63
