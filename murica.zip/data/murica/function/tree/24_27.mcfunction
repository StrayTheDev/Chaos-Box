execute as @s[scores={nbs_murica=1920..2240}] run function murica:tree/24_25
execute as @s[scores={nbs_murica=2080..2480}] run function murica:tree/26_27
