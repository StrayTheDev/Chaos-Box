execute as @s[scores={nbs_murica=2400..2640,nbs_murica_t=..29}] run function murica:notes/30
execute as @s[scores={nbs_murica=2480..2720,nbs_murica_t=..30}] run function murica:notes/31
