execute as @s[scores={nbs_murica=1920..2160,nbs_murica_t=..23}] run function murica:notes/24
