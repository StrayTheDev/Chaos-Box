execute as @s[scores={nbs_murica=8320..8640}] run function murica:tree/104_105
execute as @s[scores={nbs_murica=8480..8880}] run function murica:tree/106_107
