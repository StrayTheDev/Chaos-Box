execute as @s[scores={nbs_murica=2560..3360}] run function murica:tree/32_39
execute as @s[scores={nbs_murica=3200..4080}] run function murica:tree/40_47
