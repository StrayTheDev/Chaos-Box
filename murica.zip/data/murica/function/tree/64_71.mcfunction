execute as @s[scores={nbs_murica=5120..5600}] run function murica:tree/64_67
execute as @s[scores={nbs_murica=5440..6000}] run function murica:tree/68_71
