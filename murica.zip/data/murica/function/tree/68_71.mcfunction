execute as @s[scores={nbs_murica=5440..5760}] run function murica:tree/68_69
execute as @s[scores={nbs_murica=5600..6000}] run function murica:tree/70_71
