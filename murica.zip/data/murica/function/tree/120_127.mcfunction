execute as @s[scores={nbs_murica=9600..10080}] run function murica:tree/120_123
execute as @s[scores={nbs_murica=9920..10480}] run function murica:tree/124_127
