execute as @s[scores={nbs_murica=7040..7360}] run function murica:tree/88_89
execute as @s[scores={nbs_murica=7200..7600}] run function murica:tree/90_91
