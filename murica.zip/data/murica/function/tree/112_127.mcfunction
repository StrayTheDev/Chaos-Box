execute as @s[scores={nbs_murica=8960..9760}] run function murica:tree/112_119
execute as @s[scores={nbs_murica=9600..10480}] run function murica:tree/120_127
