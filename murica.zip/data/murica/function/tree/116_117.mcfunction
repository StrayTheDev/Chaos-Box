execute as @s[scores={nbs_murica=9280..9520,nbs_murica_t=..115}] run function murica:notes/116
execute as @s[scores={nbs_murica=9360..9600,nbs_murica_t=..116}] run function murica:notes/117
