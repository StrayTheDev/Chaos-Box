execute as @s[scores={nbs_murica=5920..6160,nbs_murica_t=..73}] run function murica:notes/74
