execute as @s[scores={nbs_murica=4160..4480}] run function murica:tree/52_53
execute as @s[scores={nbs_murica=4320..4720}] run function murica:tree/54_55
