execute as @s[scores={nbs_murica=5760..6000,nbs_murica_t=..71}] run function murica:notes/72
