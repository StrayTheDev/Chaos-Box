execute as @s[scores={nbs_murica=8000..8320}] run function murica:tree/100_101
execute as @s[scores={nbs_murica=8160..8560}] run function murica:tree/102_103
