execute as @s[scores={nbs_murica=320..560,nbs_murica_t=..3}] run function murica:notes/4
execute as @s[scores={nbs_murica=400..640,nbs_murica_t=..4}] run function murica:notes/5
