execute as @s[scores={nbs_murica=3200..3440,nbs_murica_t=..39}] run function murica:notes/40
execute as @s[scores={nbs_murica=3280..3520,nbs_murica_t=..40}] run function murica:notes/41
