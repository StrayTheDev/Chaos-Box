execute as @s[scores={nbs_murica=640..960}] run function murica:tree/8_9
execute as @s[scores={nbs_murica=800..1200}] run function murica:tree/10_11
