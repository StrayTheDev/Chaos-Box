execute as @s[scores={nbs_murica=10160..10400,nbs_murica_t=..126}] run function murica:notes/127
