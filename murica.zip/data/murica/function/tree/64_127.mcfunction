execute as @s[scores={nbs_murica=5120..7840}] run function murica:tree/64_95
execute as @s[scores={nbs_murica=7680..10480}] run function murica:tree/96_127
