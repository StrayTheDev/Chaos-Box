execute as @s[scores={nbs_murica=6560..6800,nbs_murica_t=..81}] run function murica:notes/82
execute as @s[scores={nbs_murica=6640..6880,nbs_murica_t=..82}] run function murica:notes/83
