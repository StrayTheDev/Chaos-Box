execute as @s[scores={nbs_murica=5280..5520,nbs_murica_t=..65}] run function murica:notes/66
execute as @s[scores={nbs_murica=5360..5600,nbs_murica_t=..66}] run function murica:notes/67
