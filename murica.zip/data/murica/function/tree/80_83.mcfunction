execute as @s[scores={nbs_murica=6400..6720}] run function murica:tree/80_81
execute as @s[scores={nbs_murica=6560..6960}] run function murica:tree/82_83
