execute as @s[scores={nbs_murica=5120..5360,nbs_murica_t=..63}] run function murica:notes/64
