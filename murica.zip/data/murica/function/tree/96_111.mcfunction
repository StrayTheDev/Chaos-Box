execute as @s[scores={nbs_murica=7680..8480}] run function murica:tree/96_103
execute as @s[scores={nbs_murica=8320..9200}] run function murica:tree/104_111
