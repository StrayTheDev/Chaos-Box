execute as @s[scores={nbs_murica=4800..5120}] run function murica:tree/60_61
execute as @s[scores={nbs_murica=4960..5360}] run function murica:tree/62_63
