execute as @s[scores={nbs_murica=640..1120}] run function murica:tree/8_11
execute as @s[scores={nbs_murica=960..1520}] run function murica:tree/12_15
