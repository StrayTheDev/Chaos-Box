execute as @s[scores={nbs_murica=7680..9120}] run function murica:tree/96_111
execute as @s[scores={nbs_murica=8960..10480}] run function murica:tree/112_127
