execute as @s[scores={nbs_murica=0..240,nbs_murica_t=..-1}] run function murica:notes/0
execute as @s[scores={nbs_murica=80..320,nbs_murica_t=..0}] run function murica:notes/1
