execute as @s[scores={nbs_murica=1920..2400}] run function murica:tree/24_27
execute as @s[scores={nbs_murica=2240..2800}] run function murica:tree/28_31
