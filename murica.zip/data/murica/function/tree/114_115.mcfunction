execute as @s[scores={nbs_murica=9120..9360,nbs_murica_t=..113}] run function murica:notes/114
execute as @s[scores={nbs_murica=9200..9440,nbs_murica_t=..114}] run function murica:notes/115
