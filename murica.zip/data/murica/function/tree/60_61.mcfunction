execute as @s[scores={nbs_murica=4800..5040,nbs_murica_t=..59}] run function murica:notes/60
execute as @s[scores={nbs_murica=4880..5120,nbs_murica_t=..60}] run function murica:notes/61
