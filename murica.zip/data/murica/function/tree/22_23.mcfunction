execute as @s[scores={nbs_murica=1760..2000,nbs_murica_t=..21}] run function murica:notes/22
execute as @s[scores={nbs_murica=1840..2080,nbs_murica_t=..22}] run function murica:notes/23
