execute as @s[scores={nbs_murica=8320..8800}] run function murica:tree/104_107
execute as @s[scores={nbs_murica=8640..9200}] run function murica:tree/108_111
