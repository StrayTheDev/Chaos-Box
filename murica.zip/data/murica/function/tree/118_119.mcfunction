execute as @s[scores={nbs_murica=9440..9680,nbs_murica_t=..117}] run function murica:notes/118
execute as @s[scores={nbs_murica=9520..9760,nbs_murica_t=..118}] run function murica:notes/119
