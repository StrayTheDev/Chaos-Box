execute as @s[scores={nbs_murica=4000..4240,nbs_murica_t=..49}] run function murica:notes/50
execute as @s[scores={nbs_murica=4080..4320,nbs_murica_t=..50}] run function murica:notes/51
