execute as @s[scores={nbs_murica=7200..7440,nbs_murica_t=..89}] run function murica:notes/90
execute as @s[scores={nbs_murica=7280..7520,nbs_murica_t=..90}] run function murica:notes/91
