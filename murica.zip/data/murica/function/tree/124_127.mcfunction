execute as @s[scores={nbs_murica=9920..10240}] run function murica:tree/124_125
execute as @s[scores={nbs_murica=10080..10480}] run function murica:tree/126_127
