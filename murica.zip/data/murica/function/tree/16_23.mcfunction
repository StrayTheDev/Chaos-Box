execute as @s[scores={nbs_murica=1280..1760}] run function murica:tree/16_19
execute as @s[scores={nbs_murica=1600..2160}] run function murica:tree/20_23
