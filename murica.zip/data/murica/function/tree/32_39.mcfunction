execute as @s[scores={nbs_murica=2560..3040}] run function murica:tree/32_35
execute as @s[scores={nbs_murica=2880..3440}] run function murica:tree/36_39
