execute as @s[scores={nbs_murica=3520..3840}] run function murica:tree/44_45
execute as @s[scores={nbs_murica=3680..4080}] run function murica:tree/46_47
