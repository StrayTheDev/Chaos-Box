execute as @s[scores={nbs_murica=1600..1920}] run function murica:tree/20_21
execute as @s[scores={nbs_murica=1760..2160}] run function murica:tree/22_23
