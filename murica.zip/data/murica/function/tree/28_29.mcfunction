execute as @s[scores={nbs_murica=2240..2480,nbs_murica_t=..27}] run function murica:notes/28
execute as @s[scores={nbs_murica=2320..2560,nbs_murica_t=..28}] run function murica:notes/29
