playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.50 0.629961 1
scoreboard players set @s nbs_murica_t 89