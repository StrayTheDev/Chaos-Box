playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.61 0.793701 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.50 1.887749 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.50 1.887749 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.58 0.793701 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.70 0.943874 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.58 1.887749 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.58 0.793701 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.58 0.793701 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.54 0.943874 1
playsound minecraft:block.note_block.bass record @s ^0 ^ ^ 0.66 1.587401 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.50 0.629961 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.50 0.629961 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 0.50 0.707107 1
scoreboard players set @s nbs_murica_t 16