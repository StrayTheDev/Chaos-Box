playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.50 1.122462 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.58 1.122462 1
scoreboard players set @s nbs_murica 0
scoreboard players set @s nbs_murica_t -1