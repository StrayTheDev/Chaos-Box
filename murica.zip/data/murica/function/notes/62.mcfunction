playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.50 1.334840 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.58 0.667420 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.58 0.529732 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.58 0.667420 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.58 0.793701 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.58 1.334840 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.54 0.667420 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.50 0.629961 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 0.50 0.707107 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.50 0.629961 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.50 0.629961 1
scoreboard players set @s nbs_murica_t 62