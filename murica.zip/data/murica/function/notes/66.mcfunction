playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.58 0.529732 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.58 0.629961 1
scoreboard players set @s nbs_murica_t 66