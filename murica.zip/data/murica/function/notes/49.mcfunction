playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.50 1.334840 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.70 0.667420 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.58 1.334840 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.54 1.334840 1
scoreboard players set @s nbs_murica_t 49