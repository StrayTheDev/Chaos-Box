playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.50 1.059463 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.50 1.059463 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.70 0.529732 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.58 1.059463 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.54 1.059463 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.50 0.629961 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.50 0.629961 1
scoreboard players set @s nbs_murica_t 19