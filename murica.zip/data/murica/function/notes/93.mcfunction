playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.61 0.594604 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.58 0.594604 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.50 0.629961 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.50 0.629961 1
scoreboard players set @s nbs_murica_t 93