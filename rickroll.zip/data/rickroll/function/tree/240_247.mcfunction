execute as @s[scores={nbs_rickroll=19200..19680}] run function rickroll:tree/240_243
execute as @s[scores={nbs_rickroll=19520..20080}] run function rickroll:tree/244_247
