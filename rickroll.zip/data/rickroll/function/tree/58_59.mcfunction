execute as @s[scores={nbs_rickroll=4640..4880,nbs_rickroll_t=..57}] run function rickroll:notes/58
