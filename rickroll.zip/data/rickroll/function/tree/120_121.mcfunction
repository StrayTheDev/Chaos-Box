execute as @s[scores={nbs_rickroll=9600..9840,nbs_rickroll_t=..119}] run function rickroll:notes/120
