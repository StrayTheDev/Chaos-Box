execute as @s[scores={nbs_rickroll=16160..16400,nbs_rickroll_t=..201}] run function rickroll:notes/202
