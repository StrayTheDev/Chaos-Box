execute as @s[scores={nbs_rickroll=20000..20240,nbs_rickroll_t=..249}] run function rickroll:notes/250
