execute as @s[scores={nbs_rickroll=0..320}] run function rickroll:tree/0_1
execute as @s[scores={nbs_rickroll=160..560}] run function rickroll:tree/2_3
