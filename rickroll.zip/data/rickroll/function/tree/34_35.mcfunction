execute as @s[scores={nbs_rickroll=2720..2960,nbs_rickroll_t=..33}] run function rickroll:notes/34
