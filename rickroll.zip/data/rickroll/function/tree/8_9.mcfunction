execute as @s[scores={nbs_rickroll=640..880,nbs_rickroll_t=..7}] run function rickroll:notes/8
