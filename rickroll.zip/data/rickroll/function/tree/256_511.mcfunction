execute as @s[scores={nbs_rickroll=20480..30880}] run function rickroll:tree/256_383
