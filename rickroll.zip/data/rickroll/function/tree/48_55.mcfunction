execute as @s[scores={nbs_rickroll=3840..4320}] run function rickroll:tree/48_51
execute as @s[scores={nbs_rickroll=4160..4720}] run function rickroll:tree/52_55
