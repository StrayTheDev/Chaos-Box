execute as @s[scores={nbs_rickroll=8320..8800}] run function rickroll:tree/104_107
execute as @s[scores={nbs_rickroll=8640..9200}] run function rickroll:tree/108_111
