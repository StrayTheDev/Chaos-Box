execute as @s[scores={nbs_rickroll=11200..11520}] run function rickroll:tree/140_141
execute as @s[scores={nbs_rickroll=11360..11760}] run function rickroll:tree/142_143
