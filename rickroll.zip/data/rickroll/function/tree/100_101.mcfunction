execute as @s[scores={nbs_rickroll=8000..8240,nbs_rickroll_t=..99}] run function rickroll:notes/100
