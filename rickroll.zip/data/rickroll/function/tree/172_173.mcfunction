execute as @s[scores={nbs_rickroll=13760..14000,nbs_rickroll_t=..171}] run function rickroll:notes/172
