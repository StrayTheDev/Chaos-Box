execute as @s[scores={nbs_rickroll=20480..21280}] run function rickroll:tree/256_263
execute as @s[scores={nbs_rickroll=21120..22000}] run function rickroll:tree/264_271
