execute as @s[scores={nbs_rickroll=6400..6720}] run function rickroll:tree/80_81
execute as @s[scores={nbs_rickroll=6560..6960}] run function rickroll:tree/82_83
