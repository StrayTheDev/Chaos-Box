execute as @s[scores={nbs_rickroll=20800..21040,nbs_rickroll_t=..259}] run function rickroll:notes/260
