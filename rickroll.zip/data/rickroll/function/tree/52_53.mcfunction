execute as @s[scores={nbs_rickroll=4160..4400,nbs_rickroll_t=..51}] run function rickroll:notes/52
