execute as @s[scores={nbs_rickroll=3200..3520}] run function rickroll:tree/40_41
