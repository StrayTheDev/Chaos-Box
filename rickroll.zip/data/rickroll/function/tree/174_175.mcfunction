execute as @s[scores={nbs_rickroll=13920..14160,nbs_rickroll_t=..173}] run function rickroll:notes/174
