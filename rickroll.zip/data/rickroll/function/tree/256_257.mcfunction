execute as @s[scores={nbs_rickroll=20480..20720,nbs_rickroll_t=..255}] run function rickroll:notes/256
