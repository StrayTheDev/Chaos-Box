execute as @s[scores={nbs_rickroll=5760..6000,nbs_rickroll_t=..71}] run function rickroll:notes/72
