execute as @s[scores={nbs_rickroll=0..800}] run function rickroll:tree/0_7
execute as @s[scores={nbs_rickroll=640..1520}] run function rickroll:tree/8_15
