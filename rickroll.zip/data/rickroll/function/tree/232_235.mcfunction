execute as @s[scores={nbs_rickroll=18560..18880}] run function rickroll:tree/232_233
