execute as @s[scores={nbs_rickroll=19840..20160}] run function rickroll:tree/248_249
execute as @s[scores={nbs_rickroll=20000..20400}] run function rickroll:tree/250_251
