execute as @s[scores={nbs_rickroll=6720..6960,nbs_rickroll_t=..83}] run function rickroll:notes/84
