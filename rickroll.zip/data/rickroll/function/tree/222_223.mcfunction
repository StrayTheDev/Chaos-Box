execute as @s[scores={nbs_rickroll=17760..18000,nbs_rickroll_t=..221}] run function rickroll:notes/222
