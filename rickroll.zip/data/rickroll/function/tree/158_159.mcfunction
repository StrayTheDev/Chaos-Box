execute as @s[scores={nbs_rickroll=12640..12880,nbs_rickroll_t=..157}] run function rickroll:notes/158
