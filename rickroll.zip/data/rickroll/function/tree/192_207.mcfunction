execute as @s[scores={nbs_rickroll=15360..16160}] run function rickroll:tree/192_199
execute as @s[scores={nbs_rickroll=16000..16880}] run function rickroll:tree/200_207
