execute as @s[scores={nbs_rickroll=17920..18720}] run function rickroll:tree/224_231
execute as @s[scores={nbs_rickroll=18560..19440}] run function rickroll:tree/232_239
