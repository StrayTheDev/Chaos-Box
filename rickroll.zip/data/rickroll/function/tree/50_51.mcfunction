execute as @s[scores={nbs_rickroll=4000..4240,nbs_rickroll_t=..49}] run function rickroll:notes/50
