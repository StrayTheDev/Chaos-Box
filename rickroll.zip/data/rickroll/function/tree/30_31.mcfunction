execute as @s[scores={nbs_rickroll=2400..2640,nbs_rickroll_t=..29}] run function rickroll:notes/30
