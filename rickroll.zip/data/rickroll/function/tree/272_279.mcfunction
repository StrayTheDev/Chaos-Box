execute as @s[scores={nbs_rickroll=21760..22240}] run function rickroll:tree/272_275
