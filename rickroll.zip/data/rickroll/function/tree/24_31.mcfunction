execute as @s[scores={nbs_rickroll=1920..2400}] run function rickroll:tree/24_27
execute as @s[scores={nbs_rickroll=2240..2800}] run function rickroll:tree/28_31
