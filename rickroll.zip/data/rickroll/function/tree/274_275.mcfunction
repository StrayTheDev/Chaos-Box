execute as @s[scores={nbs_rickroll=21920..22160,nbs_rickroll_t=..273}] run function rickroll:notes/274
