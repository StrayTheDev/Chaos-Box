execute as @s[scores={nbs_rickroll=3200..3680}] run function rickroll:tree/40_43
execute as @s[scores={nbs_rickroll=3520..4080}] run function rickroll:tree/44_47
