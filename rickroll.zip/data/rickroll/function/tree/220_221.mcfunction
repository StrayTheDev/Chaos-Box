execute as @s[scores={nbs_rickroll=17600..17840,nbs_rickroll_t=..219}] run function rickroll:notes/220
