execute as @s[scores={nbs_rickroll=10240..15520}] run function rickroll:tree/128_191
execute as @s[scores={nbs_rickroll=15360..20720}] run function rickroll:tree/192_255
