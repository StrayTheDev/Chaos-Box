execute as @s[scores={nbs_rickroll=7680..7920,nbs_rickroll_t=..95}] run function rickroll:notes/96
