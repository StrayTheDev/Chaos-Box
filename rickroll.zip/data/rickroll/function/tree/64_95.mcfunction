execute as @s[scores={nbs_rickroll=5120..6560}] run function rickroll:tree/64_79
execute as @s[scores={nbs_rickroll=6400..7920}] run function rickroll:tree/80_95
