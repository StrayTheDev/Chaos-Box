execute as @s[scores={nbs_rickroll=7040..7520}] run function rickroll:tree/88_91
execute as @s[scores={nbs_rickroll=7360..7920}] run function rickroll:tree/92_95
