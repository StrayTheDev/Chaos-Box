execute as @s[scores={nbs_rickroll=16640..16960}] run function rickroll:tree/208_209
execute as @s[scores={nbs_rickroll=16800..17200}] run function rickroll:tree/210_211
