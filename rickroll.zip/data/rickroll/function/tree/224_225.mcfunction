execute as @s[scores={nbs_rickroll=17920..18160,nbs_rickroll_t=..223}] run function rickroll:notes/224
