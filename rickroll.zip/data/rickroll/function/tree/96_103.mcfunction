execute as @s[scores={nbs_rickroll=7680..8160}] run function rickroll:tree/96_99
execute as @s[scores={nbs_rickroll=8000..8560}] run function rickroll:tree/100_103
