execute as @s[scores={nbs_rickroll=7680..8000}] run function rickroll:tree/96_97
execute as @s[scores={nbs_rickroll=7840..8240}] run function rickroll:tree/98_99
