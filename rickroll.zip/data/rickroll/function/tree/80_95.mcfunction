execute as @s[scores={nbs_rickroll=6400..7200}] run function rickroll:tree/80_87
execute as @s[scores={nbs_rickroll=7040..7920}] run function rickroll:tree/88_95
