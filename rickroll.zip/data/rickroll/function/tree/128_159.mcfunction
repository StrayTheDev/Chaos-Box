execute as @s[scores={nbs_rickroll=10240..11680}] run function rickroll:tree/128_143
execute as @s[scores={nbs_rickroll=11520..13040}] run function rickroll:tree/144_159
