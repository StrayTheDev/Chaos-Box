execute as @s[scores={nbs_rickroll=11840..12160}] run function rickroll:tree/148_149
