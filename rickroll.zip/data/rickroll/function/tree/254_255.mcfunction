execute as @s[scores={nbs_rickroll=20320..20560,nbs_rickroll_t=..253}] run function rickroll:notes/254
