execute as @s[scores={nbs_rickroll=5120..5600}] run function rickroll:tree/64_67
execute as @s[scores={nbs_rickroll=5440..6000}] run function rickroll:tree/68_71
