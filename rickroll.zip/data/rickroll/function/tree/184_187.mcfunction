execute as @s[scores={nbs_rickroll=14720..15040}] run function rickroll:tree/184_185
execute as @s[scores={nbs_rickroll=14880..15280}] run function rickroll:tree/186_187
