execute as @s[scores={nbs_rickroll=13440..13760}] run function rickroll:tree/168_169
