execute as @s[scores={nbs_rickroll=5760..6080}] run function rickroll:tree/72_73
execute as @s[scores={nbs_rickroll=5920..6320}] run function rickroll:tree/74_75
