execute as @s[scores={nbs_rickroll=17920..18240}] run function rickroll:tree/224_225
execute as @s[scores={nbs_rickroll=18080..18480}] run function rickroll:tree/226_227
