execute as @s[scores={nbs_rickroll=7360..7680}] run function rickroll:tree/92_93
execute as @s[scores={nbs_rickroll=7520..7920}] run function rickroll:tree/94_95
