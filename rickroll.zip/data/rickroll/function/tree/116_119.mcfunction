execute as @s[scores={nbs_rickroll=9280..9600}] run function rickroll:tree/116_117
