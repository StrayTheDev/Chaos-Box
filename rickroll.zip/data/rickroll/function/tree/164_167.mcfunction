execute as @s[scores={nbs_rickroll=13120..13440}] run function rickroll:tree/164_165
