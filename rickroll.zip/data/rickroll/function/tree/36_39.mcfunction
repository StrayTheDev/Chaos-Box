execute as @s[scores={nbs_rickroll=2880..3200}] run function rickroll:tree/36_37
