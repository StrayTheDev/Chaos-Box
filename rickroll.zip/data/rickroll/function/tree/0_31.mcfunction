execute as @s[scores={nbs_rickroll=0..1440}] run function rickroll:tree/0_15
execute as @s[scores={nbs_rickroll=1280..2800}] run function rickroll:tree/16_31
