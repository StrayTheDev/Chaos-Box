execute as @s[scores={nbs_rickroll=6400..6880}] run function rickroll:tree/80_83
execute as @s[scores={nbs_rickroll=6720..7280}] run function rickroll:tree/84_87
