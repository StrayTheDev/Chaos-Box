execute as @s[scores={nbs_rickroll=10240..10480,nbs_rickroll_t=..127}] run function rickroll:notes/128
