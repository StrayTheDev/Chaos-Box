execute as @s[scores={nbs_rickroll=15680..16000}] run function rickroll:tree/196_197
