execute as @s[scores={nbs_rickroll=2240..2560}] run function rickroll:tree/28_29
execute as @s[scores={nbs_rickroll=2400..2800}] run function rickroll:tree/30_31
