execute as @s[scores={nbs_rickroll=2560..3040}] run function rickroll:tree/32_35
execute as @s[scores={nbs_rickroll=2880..3440}] run function rickroll:tree/36_39
