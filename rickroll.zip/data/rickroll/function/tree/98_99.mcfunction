execute as @s[scores={nbs_rickroll=7840..8080,nbs_rickroll_t=..97}] run function rickroll:notes/98
