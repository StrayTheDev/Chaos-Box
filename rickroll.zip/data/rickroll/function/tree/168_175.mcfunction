execute as @s[scores={nbs_rickroll=13440..13920}] run function rickroll:tree/168_171
execute as @s[scores={nbs_rickroll=13760..14320}] run function rickroll:tree/172_175
