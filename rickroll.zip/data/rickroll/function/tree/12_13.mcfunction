execute as @s[scores={nbs_rickroll=960..1200,nbs_rickroll_t=..11}] run function rickroll:notes/12
