execute as @s[scores={nbs_rickroll=1120..1360,nbs_rickroll_t=..13}] run function rickroll:notes/14
