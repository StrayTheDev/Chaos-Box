execute as @s[scores={nbs_rickroll=9120..9360,nbs_rickroll_t=..113}] run function rickroll:notes/114
