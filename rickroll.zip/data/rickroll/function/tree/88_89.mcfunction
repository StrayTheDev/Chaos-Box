execute as @s[scores={nbs_rickroll=7040..7280,nbs_rickroll_t=..87}] run function rickroll:notes/88
