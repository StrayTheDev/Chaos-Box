execute as @s[scores={nbs_rickroll=4160..4480}] run function rickroll:tree/52_53
