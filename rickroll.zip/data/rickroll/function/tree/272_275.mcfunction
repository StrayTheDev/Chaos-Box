execute as @s[scores={nbs_rickroll=21760..22080}] run function rickroll:tree/272_273
execute as @s[scores={nbs_rickroll=21920..22320}] run function rickroll:tree/274_275
