execute as @s[scores={nbs_rickroll=8640..8960}] run function rickroll:tree/108_109
