execute as @s[scores={nbs_rickroll=11520..12000}] run function rickroll:tree/144_147
execute as @s[scores={nbs_rickroll=11840..12400}] run function rickroll:tree/148_151
