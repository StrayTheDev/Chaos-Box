execute as @s[scores={nbs_rickroll=6720..7040}] run function rickroll:tree/84_85
