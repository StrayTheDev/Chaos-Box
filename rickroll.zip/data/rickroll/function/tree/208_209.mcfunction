execute as @s[scores={nbs_rickroll=16640..16880,nbs_rickroll_t=..207}] run function rickroll:notes/208
