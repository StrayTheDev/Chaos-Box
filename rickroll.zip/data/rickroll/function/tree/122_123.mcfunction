execute as @s[scores={nbs_rickroll=9760..10000,nbs_rickroll_t=..121}] run function rickroll:notes/122
