execute as @s[scores={nbs_rickroll=14880..15120,nbs_rickroll_t=..185}] run function rickroll:notes/186
