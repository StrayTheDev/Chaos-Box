execute as @s[scores={nbs_rickroll=5120..5360,nbs_rickroll_t=..63}] run function rickroll:notes/64
