execute as @s[scores={nbs_rickroll=3520..3840}] run function rickroll:tree/44_45
