execute as @s[scores={nbs_rickroll=12800..13600}] run function rickroll:tree/160_167
execute as @s[scores={nbs_rickroll=13440..14320}] run function rickroll:tree/168_175
