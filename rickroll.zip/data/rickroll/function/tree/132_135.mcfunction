execute as @s[scores={nbs_rickroll=10560..10880}] run function rickroll:tree/132_133
