execute as @s[scores={nbs_rickroll=6400..6640,nbs_rickroll_t=..79}] run function rickroll:notes/80
