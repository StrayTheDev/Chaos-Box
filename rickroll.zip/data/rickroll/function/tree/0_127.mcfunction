execute as @s[scores={nbs_rickroll=0..5280}] run function rickroll:tree/0_63
execute as @s[scores={nbs_rickroll=5120..10480}] run function rickroll:tree/64_127
