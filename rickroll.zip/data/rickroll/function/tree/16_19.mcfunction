execute as @s[scores={nbs_rickroll=1280..1600}] run function rickroll:tree/16_17
execute as @s[scores={nbs_rickroll=1440..1840}] run function rickroll:tree/18_19
