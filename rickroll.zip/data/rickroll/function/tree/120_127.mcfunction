execute as @s[scores={nbs_rickroll=9600..10080}] run function rickroll:tree/120_123
execute as @s[scores={nbs_rickroll=9920..10480}] run function rickroll:tree/124_127
