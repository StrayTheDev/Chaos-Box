execute as @s[scores={nbs_rickroll=12160..12640}] run function rickroll:tree/152_155
execute as @s[scores={nbs_rickroll=12480..13040}] run function rickroll:tree/156_159
