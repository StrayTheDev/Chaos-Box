execute as @s[scores={nbs_rickroll=11520..11840}] run function rickroll:tree/144_145
execute as @s[scores={nbs_rickroll=11680..12080}] run function rickroll:tree/146_147
