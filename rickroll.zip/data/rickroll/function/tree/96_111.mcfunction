execute as @s[scores={nbs_rickroll=7680..8480}] run function rickroll:tree/96_103
execute as @s[scores={nbs_rickroll=8320..9200}] run function rickroll:tree/104_111
