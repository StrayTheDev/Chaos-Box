execute as @s[scores={nbs_rickroll=19360..19600,nbs_rickroll_t=..241}] run function rickroll:notes/242
