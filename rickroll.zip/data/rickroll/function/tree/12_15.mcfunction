execute as @s[scores={nbs_rickroll=960..1280}] run function rickroll:tree/12_13
execute as @s[scores={nbs_rickroll=1120..1520}] run function rickroll:tree/14_15
