execute as @s[scores={nbs_rickroll=640..960}] run function rickroll:tree/8_9
execute as @s[scores={nbs_rickroll=800..1200}] run function rickroll:tree/10_11
