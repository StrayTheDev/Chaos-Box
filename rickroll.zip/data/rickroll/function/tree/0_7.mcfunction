execute as @s[scores={nbs_rickroll=0..480}] run function rickroll:tree/0_3
execute as @s[scores={nbs_rickroll=320..880}] run function rickroll:tree/4_7
