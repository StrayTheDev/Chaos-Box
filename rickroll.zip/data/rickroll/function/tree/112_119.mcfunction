execute as @s[scores={nbs_rickroll=8960..9440}] run function rickroll:tree/112_115
execute as @s[scores={nbs_rickroll=9280..9840}] run function rickroll:tree/116_119
