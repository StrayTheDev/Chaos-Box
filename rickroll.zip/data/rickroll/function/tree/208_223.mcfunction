execute as @s[scores={nbs_rickroll=16640..17440}] run function rickroll:tree/208_215
execute as @s[scores={nbs_rickroll=17280..18160}] run function rickroll:tree/216_223
