execute as @s[scores={nbs_rickroll=12320..12560,nbs_rickroll_t=..153}] run function rickroll:notes/154
