execute as @s[scores={nbs_rickroll=10080..10320,nbs_rickroll_t=..125}] run function rickroll:notes/126
