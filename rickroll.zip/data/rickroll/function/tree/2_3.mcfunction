execute as @s[scores={nbs_rickroll=160..400,nbs_rickroll_t=..1}] run function rickroll:notes/2
