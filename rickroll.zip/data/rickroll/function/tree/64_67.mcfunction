execute as @s[scores={nbs_rickroll=5120..5440}] run function rickroll:tree/64_65
