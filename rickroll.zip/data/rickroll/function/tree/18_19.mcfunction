execute as @s[scores={nbs_rickroll=1440..1680,nbs_rickroll_t=..17}] run function rickroll:notes/18
