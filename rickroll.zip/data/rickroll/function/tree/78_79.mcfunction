execute as @s[scores={nbs_rickroll=6240..6480,nbs_rickroll_t=..77}] run function rickroll:notes/78
