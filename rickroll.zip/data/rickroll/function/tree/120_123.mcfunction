execute as @s[scores={nbs_rickroll=9600..9920}] run function rickroll:tree/120_121
execute as @s[scores={nbs_rickroll=9760..10160}] run function rickroll:tree/122_123
