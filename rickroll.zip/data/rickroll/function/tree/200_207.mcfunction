execute as @s[scores={nbs_rickroll=16000..16480}] run function rickroll:tree/200_203
execute as @s[scores={nbs_rickroll=16320..16880}] run function rickroll:tree/204_207
