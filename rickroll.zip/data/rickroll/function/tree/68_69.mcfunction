execute as @s[scores={nbs_rickroll=5440..5680,nbs_rickroll_t=..67}] run function rickroll:notes/68
