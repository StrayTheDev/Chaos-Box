execute as @s[scores={nbs_rickroll=2560..2880}] run function rickroll:tree/32_33
execute as @s[scores={nbs_rickroll=2720..3120}] run function rickroll:tree/34_35
