execute as @s[scores={nbs_rickroll=2080..2320,nbs_rickroll_t=..25}] run function rickroll:notes/26
