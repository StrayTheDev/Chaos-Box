execute as @s[scores={nbs_rickroll=7200..7440,nbs_rickroll_t=..89}] run function rickroll:notes/90
