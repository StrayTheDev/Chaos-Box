execute as @s[scores={nbs_rickroll=10880..11200}] run function rickroll:tree/136_137
