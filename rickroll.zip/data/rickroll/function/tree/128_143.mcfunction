execute as @s[scores={nbs_rickroll=10240..11040}] run function rickroll:tree/128_135
execute as @s[scores={nbs_rickroll=10880..11760}] run function rickroll:tree/136_143
