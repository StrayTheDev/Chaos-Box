execute as @s[scores={nbs_rickroll=4480..4960}] run function rickroll:tree/56_59
execute as @s[scores={nbs_rickroll=4800..5360}] run function rickroll:tree/60_63
