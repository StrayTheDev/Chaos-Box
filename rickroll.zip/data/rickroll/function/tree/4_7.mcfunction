execute as @s[scores={nbs_rickroll=480..880}] run function rickroll:tree/6_7
