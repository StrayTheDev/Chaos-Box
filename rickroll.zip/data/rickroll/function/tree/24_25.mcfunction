execute as @s[scores={nbs_rickroll=1920..2160,nbs_rickroll_t=..23}] run function rickroll:notes/24
