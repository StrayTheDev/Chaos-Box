execute as @s[scores={nbs_rickroll=10880..11360}] run function rickroll:tree/136_139
execute as @s[scores={nbs_rickroll=11200..11760}] run function rickroll:tree/140_143
