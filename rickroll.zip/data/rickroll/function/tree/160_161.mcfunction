execute as @s[scores={nbs_rickroll=12800..13040,nbs_rickroll_t=..159}] run function rickroll:notes/160
