execute as @s[scores={nbs_rickroll=20160..20480}] run function rickroll:tree/252_253
execute as @s[scores={nbs_rickroll=20320..20720}] run function rickroll:tree/254_255
