execute as @s[scores={nbs_rickroll=12960..13200,nbs_rickroll_t=..161}] run function rickroll:notes/162
