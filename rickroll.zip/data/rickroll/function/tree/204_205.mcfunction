execute as @s[scores={nbs_rickroll=16320..16560,nbs_rickroll_t=..203}] run function rickroll:notes/204
