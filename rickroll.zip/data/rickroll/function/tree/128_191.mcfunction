execute as @s[scores={nbs_rickroll=10240..12960}] run function rickroll:tree/128_159
execute as @s[scores={nbs_rickroll=12800..15600}] run function rickroll:tree/160_191
