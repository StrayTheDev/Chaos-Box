execute as @s[scores={nbs_rickroll=19840..20080,nbs_rickroll_t=..247}] run function rickroll:notes/248
