execute as @s[scores={nbs_rickroll=5760..6240}] run function rickroll:tree/72_75
execute as @s[scores={nbs_rickroll=6080..6640}] run function rickroll:tree/76_79
