execute as @s[scores={nbs_rickroll=21760..22560}] run function rickroll:tree/272_279
