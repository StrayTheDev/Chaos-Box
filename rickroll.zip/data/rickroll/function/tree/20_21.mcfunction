execute as @s[scores={nbs_rickroll=1600..1840,nbs_rickroll_t=..19}] run function rickroll:notes/20
