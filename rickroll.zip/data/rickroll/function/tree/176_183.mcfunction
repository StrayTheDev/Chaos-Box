execute as @s[scores={nbs_rickroll=14080..14560}] run function rickroll:tree/176_179
execute as @s[scores={nbs_rickroll=14400..14960}] run function rickroll:tree/180_183
