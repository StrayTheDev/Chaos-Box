execute as @s[scores={nbs_rickroll=18880..19200}] run function rickroll:tree/236_237
