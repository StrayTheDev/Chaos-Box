execute as @s[scores={nbs_rickroll=14080..14400}] run function rickroll:tree/176_177
execute as @s[scores={nbs_rickroll=14240..14640}] run function rickroll:tree/178_179
