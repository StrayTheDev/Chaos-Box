execute as @s[scores={nbs_rickroll=800..1040,nbs_rickroll_t=..9}] run function rickroll:notes/10
