execute as @s[scores={nbs_rickroll=4800..5120}] run function rickroll:tree/60_61
execute as @s[scores={nbs_rickroll=4960..5360}] run function rickroll:tree/62_63
