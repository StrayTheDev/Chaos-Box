execute as @s[scores={nbs_rickroll=7520..7760,nbs_rickroll_t=..93}] run function rickroll:notes/94
