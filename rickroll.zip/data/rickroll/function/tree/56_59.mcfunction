execute as @s[scores={nbs_rickroll=4480..4800}] run function rickroll:tree/56_57
execute as @s[scores={nbs_rickroll=4640..5040}] run function rickroll:tree/58_59
