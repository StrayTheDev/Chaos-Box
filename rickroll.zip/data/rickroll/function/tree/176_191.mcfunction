execute as @s[scores={nbs_rickroll=14080..14880}] run function rickroll:tree/176_183
execute as @s[scores={nbs_rickroll=14720..15600}] run function rickroll:tree/184_191
