execute as @s[scores={nbs_rickroll=1920..2240}] run function rickroll:tree/24_25
execute as @s[scores={nbs_rickroll=2080..2480}] run function rickroll:tree/26_27
