execute as @s[scores={nbs_rickroll=18560..19040}] run function rickroll:tree/232_235
execute as @s[scores={nbs_rickroll=18880..19440}] run function rickroll:tree/236_239
