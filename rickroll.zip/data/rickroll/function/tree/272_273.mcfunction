execute as @s[scores={nbs_rickroll=21760..22000,nbs_rickroll_t=..271}] run function rickroll:notes/272
