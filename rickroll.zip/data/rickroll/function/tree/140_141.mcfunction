execute as @s[scores={nbs_rickroll=11200..11440,nbs_rickroll_t=..139}] run function rickroll:notes/140
