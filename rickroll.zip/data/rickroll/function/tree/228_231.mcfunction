execute as @s[scores={nbs_rickroll=18240..18560}] run function rickroll:tree/228_229
