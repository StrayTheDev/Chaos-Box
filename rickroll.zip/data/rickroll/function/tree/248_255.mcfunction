execute as @s[scores={nbs_rickroll=19840..20320}] run function rickroll:tree/248_251
execute as @s[scores={nbs_rickroll=20160..20720}] run function rickroll:tree/252_255
