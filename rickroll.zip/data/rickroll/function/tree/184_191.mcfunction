execute as @s[scores={nbs_rickroll=14720..15200}] run function rickroll:tree/184_187
execute as @s[scores={nbs_rickroll=15040..15600}] run function rickroll:tree/188_191
