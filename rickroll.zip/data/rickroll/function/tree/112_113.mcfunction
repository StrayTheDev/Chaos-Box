execute as @s[scores={nbs_rickroll=8960..9200,nbs_rickroll_t=..111}] run function rickroll:notes/112
