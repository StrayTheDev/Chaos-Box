execute as @s[scores={nbs_rickroll=9280..9520,nbs_rickroll_t=..115}] run function rickroll:notes/116
