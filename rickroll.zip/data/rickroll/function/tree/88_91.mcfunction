execute as @s[scores={nbs_rickroll=7040..7360}] run function rickroll:tree/88_89
execute as @s[scores={nbs_rickroll=7200..7600}] run function rickroll:tree/90_91
