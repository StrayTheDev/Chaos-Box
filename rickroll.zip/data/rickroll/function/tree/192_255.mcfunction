execute as @s[scores={nbs_rickroll=15360..18080}] run function rickroll:tree/192_223
execute as @s[scores={nbs_rickroll=17920..20720}] run function rickroll:tree/224_255
