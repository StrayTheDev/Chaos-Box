execute as @s[scores={nbs_rickroll=12480..12720,nbs_rickroll_t=..155}] run function rickroll:notes/156
