execute as @s[scores={nbs_rickroll=18080..18320,nbs_rickroll_t=..225}] run function rickroll:notes/226
