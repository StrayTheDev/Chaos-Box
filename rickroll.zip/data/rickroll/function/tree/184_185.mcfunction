execute as @s[scores={nbs_rickroll=14720..14960,nbs_rickroll_t=..183}] run function rickroll:notes/184
