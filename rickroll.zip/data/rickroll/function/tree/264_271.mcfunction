execute as @s[scores={nbs_rickroll=21120..21600}] run function rickroll:tree/264_267
execute as @s[scores={nbs_rickroll=21440..22000}] run function rickroll:tree/268_271
