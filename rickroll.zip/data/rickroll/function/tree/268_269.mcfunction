execute as @s[scores={nbs_rickroll=21440..21680,nbs_rickroll_t=..267}] run function rickroll:notes/268
