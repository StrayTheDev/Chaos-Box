execute as @s[scores={nbs_rickroll=13760..14080}] run function rickroll:tree/172_173
execute as @s[scores={nbs_rickroll=13920..14320}] run function rickroll:tree/174_175
