execute as @s[scores={nbs_rickroll=0..2720}] run function rickroll:tree/0_31
execute as @s[scores={nbs_rickroll=2560..5360}] run function rickroll:tree/32_63
