execute as @s[scores={nbs_rickroll=6080..6320,nbs_rickroll_t=..75}] run function rickroll:notes/76
