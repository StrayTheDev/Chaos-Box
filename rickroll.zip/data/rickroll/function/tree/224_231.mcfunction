execute as @s[scores={nbs_rickroll=17920..18400}] run function rickroll:tree/224_227
execute as @s[scores={nbs_rickroll=18240..18800}] run function rickroll:tree/228_231
