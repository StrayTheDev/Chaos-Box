execute as @s[scores={nbs_rickroll=20480..20800}] run function rickroll:tree/256_257
