execute as @s[scores={nbs_rickroll=16800..17040,nbs_rickroll_t=..209}] run function rickroll:notes/210
