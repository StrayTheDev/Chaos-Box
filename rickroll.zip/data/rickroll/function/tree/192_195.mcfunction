execute as @s[scores={nbs_rickroll=15360..15680}] run function rickroll:tree/192_193
