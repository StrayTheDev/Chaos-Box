execute as @s[scores={nbs_rickroll=14080..14320,nbs_rickroll_t=..175}] run function rickroll:notes/176
