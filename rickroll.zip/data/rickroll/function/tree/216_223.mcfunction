execute as @s[scores={nbs_rickroll=17280..17760}] run function rickroll:tree/216_219
execute as @s[scores={nbs_rickroll=17600..18160}] run function rickroll:tree/220_223
