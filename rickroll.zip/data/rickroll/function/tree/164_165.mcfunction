execute as @s[scores={nbs_rickroll=13120..13360,nbs_rickroll_t=..163}] run function rickroll:notes/164
