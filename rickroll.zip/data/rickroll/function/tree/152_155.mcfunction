execute as @s[scores={nbs_rickroll=12160..12480}] run function rickroll:tree/152_153
execute as @s[scores={nbs_rickroll=12320..12720}] run function rickroll:tree/154_155
