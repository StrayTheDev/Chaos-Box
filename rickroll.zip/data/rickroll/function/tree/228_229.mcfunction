execute as @s[scores={nbs_rickroll=18240..18480,nbs_rickroll_t=..227}] run function rickroll:notes/228
