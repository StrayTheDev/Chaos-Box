execute as @s[scores={nbs_rickroll=15200..15440,nbs_rickroll_t=..189}] run function rickroll:notes/190
