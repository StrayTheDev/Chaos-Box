execute as @s[scores={nbs_rickroll=17440..17680,nbs_rickroll_t=..217}] run function rickroll:notes/218
