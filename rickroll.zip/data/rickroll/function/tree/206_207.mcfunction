execute as @s[scores={nbs_rickroll=16480..16720,nbs_rickroll_t=..205}] run function rickroll:notes/206
