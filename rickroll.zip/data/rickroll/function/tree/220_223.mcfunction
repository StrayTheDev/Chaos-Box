execute as @s[scores={nbs_rickroll=17600..17920}] run function rickroll:tree/220_221
execute as @s[scores={nbs_rickroll=17760..18160}] run function rickroll:tree/222_223
