execute as @s[scores={nbs_rickroll=16960..17200,nbs_rickroll_t=..211}] run function rickroll:notes/212
