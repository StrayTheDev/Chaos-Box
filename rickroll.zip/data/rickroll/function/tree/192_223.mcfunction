execute as @s[scores={nbs_rickroll=15360..16800}] run function rickroll:tree/192_207
execute as @s[scores={nbs_rickroll=16640..18160}] run function rickroll:tree/208_223
