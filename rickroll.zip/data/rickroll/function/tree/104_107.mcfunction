execute as @s[scores={nbs_rickroll=8320..8640}] run function rickroll:tree/104_105
