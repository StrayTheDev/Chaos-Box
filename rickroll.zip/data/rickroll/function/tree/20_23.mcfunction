execute as @s[scores={nbs_rickroll=1600..1920}] run function rickroll:tree/20_21
