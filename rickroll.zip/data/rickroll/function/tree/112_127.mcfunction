execute as @s[scores={nbs_rickroll=8960..9760}] run function rickroll:tree/112_119
execute as @s[scores={nbs_rickroll=9600..10480}] run function rickroll:tree/120_127
