execute as @s[scores={nbs_rickroll=11680..11920,nbs_rickroll_t=..145}] run function rickroll:notes/146
