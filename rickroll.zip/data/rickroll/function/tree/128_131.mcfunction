execute as @s[scores={nbs_rickroll=10240..10560}] run function rickroll:tree/128_129
