execute as @s[scores={nbs_rickroll=14240..14480,nbs_rickroll_t=..177}] run function rickroll:notes/178
