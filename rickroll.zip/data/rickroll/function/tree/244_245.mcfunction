execute as @s[scores={nbs_rickroll=19520..19760,nbs_rickroll_t=..243}] run function rickroll:notes/244
