execute as @s[scores={nbs_rickroll=3200..3440,nbs_rickroll_t=..39}] run function rickroll:notes/40
