execute as @s[scores={nbs_rickroll=10240..10720}] run function rickroll:tree/128_131
execute as @s[scores={nbs_rickroll=10560..11120}] run function rickroll:tree/132_135
