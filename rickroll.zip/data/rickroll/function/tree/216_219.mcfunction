execute as @s[scores={nbs_rickroll=17280..17600}] run function rickroll:tree/216_217
execute as @s[scores={nbs_rickroll=17440..17840}] run function rickroll:tree/218_219
