execute as @s[scores={nbs_rickroll=17280..17520,nbs_rickroll_t=..215}] run function rickroll:notes/216
