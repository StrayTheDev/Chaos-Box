execute as @s[scores={nbs_rickroll=20480..20960}] run function rickroll:tree/256_259
execute as @s[scores={nbs_rickroll=20800..21360}] run function rickroll:tree/260_263
