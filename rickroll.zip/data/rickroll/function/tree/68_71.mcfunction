execute as @s[scores={nbs_rickroll=5440..5760}] run function rickroll:tree/68_69
