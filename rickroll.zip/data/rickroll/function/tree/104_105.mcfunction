execute as @s[scores={nbs_rickroll=8320..8560,nbs_rickroll_t=..103}] run function rickroll:notes/104
