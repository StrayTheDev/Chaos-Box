execute as @s[scores={nbs_rickroll=14400..14640,nbs_rickroll_t=..179}] run function rickroll:notes/180
