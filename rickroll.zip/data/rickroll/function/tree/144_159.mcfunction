execute as @s[scores={nbs_rickroll=11520..12320}] run function rickroll:tree/144_151
execute as @s[scores={nbs_rickroll=12160..13040}] run function rickroll:tree/152_159
