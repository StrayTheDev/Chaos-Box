execute as @s[scores={nbs_rickroll=2240..2480,nbs_rickroll_t=..27}] run function rickroll:notes/28
