execute as @s[scores={nbs_rickroll=21440..21760}] run function rickroll:tree/268_269
execute as @s[scores={nbs_rickroll=21600..22000}] run function rickroll:tree/270_271
