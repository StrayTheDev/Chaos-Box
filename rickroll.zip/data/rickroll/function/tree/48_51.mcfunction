execute as @s[scores={nbs_rickroll=3840..4160}] run function rickroll:tree/48_49
execute as @s[scores={nbs_rickroll=4000..4400}] run function rickroll:tree/50_51
