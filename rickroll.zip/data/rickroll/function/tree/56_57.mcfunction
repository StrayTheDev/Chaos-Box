execute as @s[scores={nbs_rickroll=4480..4720,nbs_rickroll_t=..55}] run function rickroll:notes/56
