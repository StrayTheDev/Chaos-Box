execute as @s[scores={nbs_rickroll=16640..17120}] run function rickroll:tree/208_211
execute as @s[scores={nbs_rickroll=16960..17520}] run function rickroll:tree/212_215
