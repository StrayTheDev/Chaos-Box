execute as @s[scores={nbs_rickroll=6080..6400}] run function rickroll:tree/76_77
execute as @s[scores={nbs_rickroll=6240..6640}] run function rickroll:tree/78_79
