execute as @s[scores={nbs_rickroll=13440..13680,nbs_rickroll_t=..167}] run function rickroll:notes/168
