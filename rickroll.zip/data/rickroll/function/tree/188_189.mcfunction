execute as @s[scores={nbs_rickroll=15040..15280,nbs_rickroll_t=..187}] run function rickroll:notes/188
