execute as @s[scores={nbs_rickroll=6560..6800,nbs_rickroll_t=..81}] run function rickroll:notes/82
