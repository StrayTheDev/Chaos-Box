execute as @s[scores={nbs_rickroll=21120..21360,nbs_rickroll_t=..263}] run function rickroll:notes/264
