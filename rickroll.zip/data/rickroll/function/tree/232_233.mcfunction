execute as @s[scores={nbs_rickroll=18560..18800,nbs_rickroll_t=..231}] run function rickroll:notes/232
