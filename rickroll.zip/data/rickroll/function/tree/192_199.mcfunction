execute as @s[scores={nbs_rickroll=15360..15840}] run function rickroll:tree/192_195
execute as @s[scores={nbs_rickroll=15680..16240}] run function rickroll:tree/196_199
