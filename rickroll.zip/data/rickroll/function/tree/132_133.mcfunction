execute as @s[scores={nbs_rickroll=10560..10800,nbs_rickroll_t=..131}] run function rickroll:notes/132
