execute as @s[scores={nbs_rickroll=0..240,nbs_rickroll_t=..-1}] run function rickroll:notes/0
