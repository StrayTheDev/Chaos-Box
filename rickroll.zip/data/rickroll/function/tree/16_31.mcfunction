execute as @s[scores={nbs_rickroll=1280..2080}] run function rickroll:tree/16_23
execute as @s[scores={nbs_rickroll=1920..2800}] run function rickroll:tree/24_31
