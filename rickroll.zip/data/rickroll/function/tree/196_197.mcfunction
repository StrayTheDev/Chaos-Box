execute as @s[scores={nbs_rickroll=15680..15920,nbs_rickroll_t=..195}] run function rickroll:notes/196
