execute as @s[scores={nbs_rickroll=7360..7600,nbs_rickroll_t=..91}] run function rickroll:notes/92
