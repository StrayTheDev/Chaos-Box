execute as @s[scores={nbs_rickroll=4960..5200,nbs_rickroll_t=..61}] run function rickroll:notes/62
