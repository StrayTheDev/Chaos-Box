execute as @s[scores={nbs_rickroll=3520..3760,nbs_rickroll_t=..43}] run function rickroll:notes/44
