execute as @s[scores={nbs_rickroll=12800..14240}] run function rickroll:tree/160_175
execute as @s[scores={nbs_rickroll=14080..15600}] run function rickroll:tree/176_191
