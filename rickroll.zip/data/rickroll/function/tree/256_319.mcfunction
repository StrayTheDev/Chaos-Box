execute as @s[scores={nbs_rickroll=20480..23200}] run function rickroll:tree/256_287
