execute as @s[scores={nbs_rickroll=2560..2800,nbs_rickroll_t=..31}] run function rickroll:notes/32
