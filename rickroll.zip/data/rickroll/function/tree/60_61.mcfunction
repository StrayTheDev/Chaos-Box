execute as @s[scores={nbs_rickroll=4800..5040,nbs_rickroll_t=..59}] run function rickroll:notes/60
