execute as @s[scores={nbs_rickroll=11360..11600,nbs_rickroll_t=..141}] run function rickroll:notes/142
