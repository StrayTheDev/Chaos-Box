execute as @s[scores={nbs_rickroll=16000..16320}] run function rickroll:tree/200_201
execute as @s[scores={nbs_rickroll=16160..16560}] run function rickroll:tree/202_203
