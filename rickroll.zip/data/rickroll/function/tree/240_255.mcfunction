execute as @s[scores={nbs_rickroll=19200..20000}] run function rickroll:tree/240_247
execute as @s[scores={nbs_rickroll=19840..20720}] run function rickroll:tree/248_255
