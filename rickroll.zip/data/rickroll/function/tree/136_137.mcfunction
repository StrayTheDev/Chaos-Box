execute as @s[scores={nbs_rickroll=10880..11120,nbs_rickroll_t=..135}] run function rickroll:notes/136
