execute as @s[scores={nbs_rickroll=16960..17280}] run function rickroll:tree/212_213
