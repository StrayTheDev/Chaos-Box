execute as @s[scores={nbs_rickroll=16000..16240,nbs_rickroll_t=..199}] run function rickroll:notes/200
