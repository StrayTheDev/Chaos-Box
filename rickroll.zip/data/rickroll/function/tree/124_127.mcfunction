execute as @s[scores={nbs_rickroll=9920..10240}] run function rickroll:tree/124_125
execute as @s[scores={nbs_rickroll=10080..10480}] run function rickroll:tree/126_127
