execute as @s[scores={nbs_rickroll=1280..1520,nbs_rickroll_t=..15}] run function rickroll:notes/16
