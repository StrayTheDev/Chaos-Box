execute as @s[scores={nbs_rickroll=20480..21920}] run function rickroll:tree/256_271
execute as @s[scores={nbs_rickroll=21760..23280}] run function rickroll:tree/272_287
