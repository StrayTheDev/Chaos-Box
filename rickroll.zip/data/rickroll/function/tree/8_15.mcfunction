execute as @s[scores={nbs_rickroll=640..1120}] run function rickroll:tree/8_11
execute as @s[scores={nbs_rickroll=960..1520}] run function rickroll:tree/12_15
