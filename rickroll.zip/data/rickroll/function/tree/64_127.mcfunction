execute as @s[scores={nbs_rickroll=5120..7840}] run function rickroll:tree/64_95
execute as @s[scores={nbs_rickroll=7680..10480}] run function rickroll:tree/96_127
