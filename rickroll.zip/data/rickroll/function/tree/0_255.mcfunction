execute as @s[scores={nbs_rickroll=0..10400}] run function rickroll:tree/0_127
execute as @s[scores={nbs_rickroll=10240..20720}] run function rickroll:tree/128_255
