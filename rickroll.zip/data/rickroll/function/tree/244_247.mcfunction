execute as @s[scores={nbs_rickroll=19520..19840}] run function rickroll:tree/244_245
