execute as @s[scores={nbs_rickroll=20480..25760}] run function rickroll:tree/256_319
