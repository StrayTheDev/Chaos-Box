execute as @s[scores={nbs_rickroll=12800..13280}] run function rickroll:tree/160_163
execute as @s[scores={nbs_rickroll=13120..13680}] run function rickroll:tree/164_167
