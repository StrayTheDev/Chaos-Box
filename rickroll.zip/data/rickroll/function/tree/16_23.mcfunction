execute as @s[scores={nbs_rickroll=1280..1760}] run function rickroll:tree/16_19
execute as @s[scores={nbs_rickroll=1600..2160}] run function rickroll:tree/20_23
