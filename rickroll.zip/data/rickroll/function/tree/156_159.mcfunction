execute as @s[scores={nbs_rickroll=12480..12800}] run function rickroll:tree/156_157
execute as @s[scores={nbs_rickroll=12640..13040}] run function rickroll:tree/158_159
