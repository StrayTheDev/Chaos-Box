execute as @s[scores={nbs_rickroll=5120..5920}] run function rickroll:tree/64_71
execute as @s[scores={nbs_rickroll=5760..6640}] run function rickroll:tree/72_79
