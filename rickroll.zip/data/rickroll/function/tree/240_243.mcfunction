execute as @s[scores={nbs_rickroll=19200..19520}] run function rickroll:tree/240_241
execute as @s[scores={nbs_rickroll=19360..19760}] run function rickroll:tree/242_243
