execute as @s[scores={nbs_rickroll=5920..6160,nbs_rickroll_t=..73}] run function rickroll:notes/74
