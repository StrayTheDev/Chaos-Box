execute as @s[scores={nbs_rickroll=480..720,nbs_rickroll_t=..5}] run function rickroll:notes/6
