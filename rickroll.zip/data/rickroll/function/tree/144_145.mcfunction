execute as @s[scores={nbs_rickroll=11520..11760,nbs_rickroll_t=..143}] run function rickroll:notes/144
