execute as @s[scores={nbs_rickroll=16320..16640}] run function rickroll:tree/204_205
execute as @s[scores={nbs_rickroll=16480..16880}] run function rickroll:tree/206_207
