execute as @s[scores={nbs_rickroll=17920..19360}] run function rickroll:tree/224_239
execute as @s[scores={nbs_rickroll=19200..20720}] run function rickroll:tree/240_255
