execute as @s[scores={nbs_rickroll=3840..4080,nbs_rickroll_t=..47}] run function rickroll:notes/48
