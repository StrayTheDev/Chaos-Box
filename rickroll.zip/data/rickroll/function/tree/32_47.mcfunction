execute as @s[scores={nbs_rickroll=2560..3360}] run function rickroll:tree/32_39
execute as @s[scores={nbs_rickroll=3200..4080}] run function rickroll:tree/40_47
