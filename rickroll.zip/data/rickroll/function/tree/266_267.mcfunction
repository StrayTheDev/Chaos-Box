execute as @s[scores={nbs_rickroll=21280..21520,nbs_rickroll_t=..265}] run function rickroll:notes/266
