execute as @s[scores={nbs_rickroll=9920..10160,nbs_rickroll_t=..123}] run function rickroll:notes/124
