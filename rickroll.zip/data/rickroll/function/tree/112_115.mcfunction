execute as @s[scores={nbs_rickroll=8960..9280}] run function rickroll:tree/112_113
execute as @s[scores={nbs_rickroll=9120..9520}] run function rickroll:tree/114_115
