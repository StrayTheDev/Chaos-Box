execute as @s[scores={nbs_rickroll=3840..4640}] run function rickroll:tree/48_55
execute as @s[scores={nbs_rickroll=4480..5360}] run function rickroll:tree/56_63
