execute as @s[scores={nbs_rickroll=8640..8880,nbs_rickroll_t=..107}] run function rickroll:notes/108
