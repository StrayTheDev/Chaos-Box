execute as @s[scores={nbs_rickroll=14400..14720}] run function rickroll:tree/180_181
