execute as @s[scores={nbs_rickroll=8000..8320}] run function rickroll:tree/100_101
