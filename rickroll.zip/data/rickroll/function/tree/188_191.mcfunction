execute as @s[scores={nbs_rickroll=15040..15360}] run function rickroll:tree/188_189
execute as @s[scores={nbs_rickroll=15200..15600}] run function rickroll:tree/190_191
