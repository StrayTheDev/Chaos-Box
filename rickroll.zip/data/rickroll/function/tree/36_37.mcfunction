execute as @s[scores={nbs_rickroll=2880..3120,nbs_rickroll_t=..35}] run function rickroll:notes/36
