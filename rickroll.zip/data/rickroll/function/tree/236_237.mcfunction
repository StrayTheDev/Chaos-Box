execute as @s[scores={nbs_rickroll=18880..19120,nbs_rickroll_t=..235}] run function rickroll:notes/236
