execute as @s[scores={nbs_rickroll=20160..20400,nbs_rickroll_t=..251}] run function rickroll:notes/252
