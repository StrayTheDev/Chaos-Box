execute as @s[scores={nbs_rickroll=21600..21840,nbs_rickroll_t=..269}] run function rickroll:notes/270
