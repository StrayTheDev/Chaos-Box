execute as @s[scores={nbs_rickroll=19200..19440,nbs_rickroll_t=..239}] run function rickroll:notes/240
