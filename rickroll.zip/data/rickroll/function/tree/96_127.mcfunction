execute as @s[scores={nbs_rickroll=7680..9120}] run function rickroll:tree/96_111
execute as @s[scores={nbs_rickroll=8960..10480}] run function rickroll:tree/112_127
