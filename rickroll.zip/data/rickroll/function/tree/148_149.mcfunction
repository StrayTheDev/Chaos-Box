execute as @s[scores={nbs_rickroll=11840..12080,nbs_rickroll_t=..147}] run function rickroll:notes/148
