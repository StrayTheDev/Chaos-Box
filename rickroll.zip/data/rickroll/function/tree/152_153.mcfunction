execute as @s[scores={nbs_rickroll=12160..12400,nbs_rickroll_t=..151}] run function rickroll:notes/152
