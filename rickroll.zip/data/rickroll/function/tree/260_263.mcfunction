execute as @s[scores={nbs_rickroll=20800..21120}] run function rickroll:tree/260_261
execute as @s[scores={nbs_rickroll=20960..21360}] run function rickroll:tree/262_263
