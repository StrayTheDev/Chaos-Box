execute as @s[scores={nbs_rickroll=15360..15600,nbs_rickroll_t=..191}] run function rickroll:notes/192
