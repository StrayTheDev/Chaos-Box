execute as @s[scores={nbs_rickroll=20960..21200,nbs_rickroll_t=..261}] run function rickroll:notes/262
