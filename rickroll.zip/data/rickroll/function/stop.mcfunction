tag @s remove nbs_rickroll
scoreboard players reset @s nbs_rickroll
scoreboard players reset @s nbs_rickroll_t