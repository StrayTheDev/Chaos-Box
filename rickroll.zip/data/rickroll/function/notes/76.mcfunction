playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.98 1.122462 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.98 1.122462 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.81 1.781797 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 1 0.793701 1
playsound minecraft:block.note_block.hat record @s ^0 ^ ^ 0.85 0.707107 1
scoreboard players set @s nbs_rickroll_t 76