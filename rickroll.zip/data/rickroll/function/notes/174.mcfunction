playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.79 0.500000 1
scoreboard players set @s nbs_rickroll_t 174