playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.90 0.561231 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.91 0.707107 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.91 0.840896 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.95 1.681793 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.95 0.840896 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.82 1.781797 1
scoreboard players set @s nbs_rickroll_t 224