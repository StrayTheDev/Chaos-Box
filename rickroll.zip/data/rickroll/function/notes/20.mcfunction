playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.840896 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.87 0.749154 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.92 0.629961 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.92 0.943874 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.96 1.498307 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.96 0.749154 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.82 1.781797 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.707107 1
scoreboard players set @s nbs_rickroll_t 20