playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.97 1.887749 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.97 0.943874 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.87 1.414214 1
scoreboard players set @s nbs_rickroll_t 80