playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.83 1.781797 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.707107 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 0.80 1.189207 1
playsound minecraft:block.note_block.hat record @s ^0 ^ ^ 0.82 0.707107 1
scoreboard players set @s nbs_rickroll_t 260