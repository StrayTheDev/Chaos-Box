playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 0.82 1.189207 1
playsound minecraft:block.note_block.hat record @s ^0 ^ ^ 0.85 0.707107 1
scoreboard players set @s nbs_rickroll_t 262