playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.94 1.498307 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.94 0.749154 1
scoreboard players set @s nbs_rickroll_t 210