playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.561231 1
playsound minecraft:block.note_block.bell record @s ^0 ^ ^ 0.34 1.498307 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.90 1.414214 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 0.81 1.059463 1
scoreboard players set @s nbs_rickroll_t 264