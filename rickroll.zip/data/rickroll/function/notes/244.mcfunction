playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.85 1.781797 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.707107 1
scoreboard players set @s nbs_rickroll_t 244