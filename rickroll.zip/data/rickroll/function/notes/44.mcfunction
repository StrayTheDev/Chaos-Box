playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.99 1.122462 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.99 0.561231 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.80 1.781797 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 1 0.793701 1
playsound minecraft:block.note_block.hat record @s ^0 ^ ^ 0.82 0.707107 1
scoreboard players set @s nbs_rickroll_t 44