playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.561231 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.38 1.259921 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.40 1.259921 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.94 1.122462 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.94 1.122462 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.82 1.781797 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 1 0.793701 1
playsound minecraft:block.note_block.hat record @s ^0 ^ ^ 0.85 0.707107 1
scoreboard players set @s nbs_rickroll_t 140