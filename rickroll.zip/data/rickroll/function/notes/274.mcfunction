playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.749154 1
playsound minecraft:block.note_block.bell record @s ^0 ^ ^ 0.34 1.498307 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 0.82 1.059463 1
function rickroll:stop