playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.89 0.561231 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.93 0.840896 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.86 0.707107 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.96 1.681793 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.96 0.840896 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.82 1.781797 1
scoreboard players set @s nbs_rickroll_t 96