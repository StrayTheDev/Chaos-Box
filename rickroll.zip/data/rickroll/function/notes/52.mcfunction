playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.88 0.707107 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.93 0.561231 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.88 0.840896 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.94 1.681793 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.94 0.840896 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.82 1.781797 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.707107 1
scoreboard players set @s nbs_rickroll_t 52