playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.91 0.561231 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.93 0.840896 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.87 0.707107 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.98 1.681793 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.98 0.840896 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.85 1.781797 1
scoreboard players set @s nbs_rickroll_t 32