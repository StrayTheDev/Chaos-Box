playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.943874 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.91 1.414214 1
scoreboard players set @s nbs_rickroll_t 184