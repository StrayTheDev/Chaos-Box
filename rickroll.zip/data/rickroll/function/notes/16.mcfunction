playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 1 0.890899 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 1.059463 1
scoreboard players set @s nbs_rickroll_t 16