playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.87 0.629961 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.86 0.749154 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.88 0.943874 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.90 1.414214 1
scoreboard players set @s nbs_rickroll_t 128