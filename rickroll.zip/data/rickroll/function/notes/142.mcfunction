playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.561231 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.36 1.498307 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.40 1.498307 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.97 2.000000 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.97 1.000000 1
scoreboard players set @s nbs_rickroll_t 142