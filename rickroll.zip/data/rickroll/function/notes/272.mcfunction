playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.90 1.414214 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 0.85 1.059463 1
scoreboard players set @s nbs_rickroll_t 272