playsound minecraft:block.note_block.bell record @s ^0 ^ ^ 0.35 1.498307 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 0.86 1.059463 1
scoreboard players set @s nbs_rickroll_t 266