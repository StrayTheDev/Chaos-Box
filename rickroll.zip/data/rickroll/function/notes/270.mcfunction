playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.561231 1
playsound minecraft:block.note_block.bell record @s ^0 ^ ^ 0.34 1.498307 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 0.80 1.189207 1
playsound minecraft:block.note_block.hat record @s ^0 ^ ^ 0.81 0.707107 1
scoreboard players set @s nbs_rickroll_t 270