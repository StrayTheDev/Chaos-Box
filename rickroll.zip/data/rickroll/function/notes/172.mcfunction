playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.98 1.122462 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.98 0.561231 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.85 1.781797 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 1 0.793701 1
playsound minecraft:block.note_block.hat record @s ^0 ^ ^ 0.86 0.707107 1
scoreboard players set @s nbs_rickroll_t 172