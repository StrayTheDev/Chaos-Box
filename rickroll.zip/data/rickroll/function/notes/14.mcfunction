playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 1 0.943874 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 1.189207 1
scoreboard players set @s nbs_rickroll_t 14