playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.840896 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.89 0.749154 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.87 0.629961 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.87 0.943874 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.81 1.781797 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.707107 1
scoreboard players set @s nbs_rickroll_t 212