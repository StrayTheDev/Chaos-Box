playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.561231 1
playsound minecraft:block.note_block.bell record @s ^0 ^ ^ 0.35 1.498307 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.85 1.781797 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 1 0.793701 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 0.83 1.189207 1
playsound minecraft:block.note_block.hat record @s ^0 ^ ^ 0.81 0.707107 1
scoreboard players set @s nbs_rickroll_t 268