playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.84 1.781797 1
scoreboard players set @s nbs_rickroll_t 226