playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.707107 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.95 2.000000 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.95 1.000000 1
scoreboard players set @s nbs_rickroll_t 206