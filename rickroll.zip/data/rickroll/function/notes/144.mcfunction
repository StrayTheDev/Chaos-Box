playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.36 1.259921 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.40 1.259921 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.95 1.887749 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.95 0.943874 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.91 1.414214 1
scoreboard players set @s nbs_rickroll_t 144