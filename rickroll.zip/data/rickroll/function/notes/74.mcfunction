playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.629961 1
scoreboard players set @s nbs_rickroll_t 74