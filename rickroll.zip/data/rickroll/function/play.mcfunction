tag @s add nbs_rickroll
scoreboard players set @s nbs_rickroll_t -1
tellraw @a [{"selector":"@s","color":"green"},{"text":" has been ","color":"dark_gray"},{"text":"RICKROLLED","color":"green"},{"text":"!","color":"dark_gray"}]
advancement grant @s only code:funny/rickroll