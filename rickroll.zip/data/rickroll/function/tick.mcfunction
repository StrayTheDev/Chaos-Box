execute as @a[tag=nbs_rickroll] run scoreboard players operation @s nbs_rickroll += speed nbs_rickroll
execute as @a[tag=nbs_rickroll] at @s run function rickroll:tree/0_511