scoreboard objectives add nbs_rickroll dummy
scoreboard objectives add nbs_rickroll_t dummy
scoreboard players set speed nbs_rickroll 80