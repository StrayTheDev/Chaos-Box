tag @s remove nbs_bergentruc
scoreboard players reset @s nbs_bergentruc
scoreboard players reset @s nbs_bergentruc_t