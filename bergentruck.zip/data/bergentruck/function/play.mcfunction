tag @s add nbs_bergentruc
scoreboard players set @s nbs_bergentruc_t -1
