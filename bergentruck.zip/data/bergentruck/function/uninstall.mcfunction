tag @e remove nbs_bergentruc
scoreboard objectives remove nbs_bergentruc
scoreboard objectives remove nbs_bergentruc_t
datapack disable "bergentruck"
tellraw @s ["",{"text":"[NBS] ","color":"gold","bold":true},{"text":"Data pack ","color":"yellow"},{"text":"bergentruck","color":"gold","underlined":true},{"text":" uninstalled successfully. You may now remove it from your data pack folder.","color":"yellow"}]