playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.80 0.529732 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.80 0.529732 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.80 1.781797 1
scoreboard players set @s nbs_bergentruc_t 75