playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 0.943874 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.60 0.793701 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 1.189207 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 1 0.943874 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 1 0.793701 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 1 1.189207 1
scoreboard players set @s nbs_bergentruc_t 66