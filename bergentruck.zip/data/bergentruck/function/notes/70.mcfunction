playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 0.529732 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.60 0.890899 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 1.259921 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 1 0.529732 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 1 0.890899 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 1 1.259921 1
scoreboard players set @s nbs_bergentruc_t 70