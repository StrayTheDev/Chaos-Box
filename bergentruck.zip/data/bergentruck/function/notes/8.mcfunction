playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 1.059463 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 1 1.059463 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.80 0.629961 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.80 1.059463 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.80 0.629961 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.80 1.781797 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 0.70 0.707107 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.80 1.781797 1
scoreboard players set @s nbs_bergentruc_t 8