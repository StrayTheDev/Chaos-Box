playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 1.189207 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 1 1.189207 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.70 0.707107 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.80 0.890899 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.80 1.189207 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.890899 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.80 0.707107 1
scoreboard players set @s nbs_bergentruc_t 4