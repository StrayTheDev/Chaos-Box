playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 0.594604 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.60 0.943874 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 1 0.594604 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 1 0.943874 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.80 0.594604 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.80 0.594604 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.80 1.189207 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.60 0.943874 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.80 1.189207 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 0.60 0.943874 1
playsound minecraft:block.note_block.bell record @s ^0 ^ ^ 0.80 0.594604 1
playsound minecraft:block.note_block.snare record @s ^0 ^ ^ 0.80 1.781797 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.60 1.887749 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.80 1.189207 1
scoreboard players set @s nbs_bergentruc_t 119