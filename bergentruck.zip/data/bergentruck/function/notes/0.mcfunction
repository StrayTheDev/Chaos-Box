playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 0.943874 1
playsound minecraft:block.note_block.flute record @s ^0 ^ ^ 1 0.943874 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.80 0.793701 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.70 0.594604 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.80 0.943874 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 0.80 0.594604 1
playsound minecraft:block.note_block.harp record @s ^0 ^ ^ 1 0.793701 1
scoreboard players set @s nbs_bergentruc_t 0