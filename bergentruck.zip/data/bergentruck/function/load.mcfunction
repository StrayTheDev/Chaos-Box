scoreboard objectives add nbs_bergentruc dummy
scoreboard objectives add nbs_bergentruc_t dummy
scoreboard players set speed nbs_bergentruc 32