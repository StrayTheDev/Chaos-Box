execute as @s[scores={nbs_bergentruc=3200..3680}] run function bergentruck:tree/40_43
execute as @s[scores={nbs_bergentruc=3520..4080}] run function bergentruck:tree/44_47
