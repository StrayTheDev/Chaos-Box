execute as @s[scores={nbs_bergentruc=1280..1600}] run function bergentruck:tree/16_17
execute as @s[scores={nbs_bergentruc=1440..1840}] run function bergentruck:tree/18_19
