execute as @s[scores={nbs_bergentruc=640..1120}] run function bergentruck:tree/8_11
execute as @s[scores={nbs_bergentruc=960..1520}] run function bergentruck:tree/12_15
