execute as @s[scores={nbs_bergentruc=3840..4320}] run function bergentruck:tree/48_51
execute as @s[scores={nbs_bergentruc=4160..4720}] run function bergentruck:tree/52_55
