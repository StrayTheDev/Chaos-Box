execute as @s[scores={nbs_bergentruc=9600..9920}] run function bergentruck:tree/120_121
execute as @s[scores={nbs_bergentruc=9760..10160}] run function bergentruck:tree/122_123
