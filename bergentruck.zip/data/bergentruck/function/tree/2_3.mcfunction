execute as @s[scores={nbs_bergentruc=160..400,nbs_bergentruc_t=..1}] run function bergentruck:notes/2
