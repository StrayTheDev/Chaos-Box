execute as @s[scores={nbs_bergentruc=4480..4720,nbs_bergentruc_t=..55}] run function bergentruck:notes/56
execute as @s[scores={nbs_bergentruc=4560..4800,nbs_bergentruc_t=..56}] run function bergentruck:notes/57
