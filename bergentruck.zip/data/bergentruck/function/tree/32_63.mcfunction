execute as @s[scores={nbs_bergentruc=2560..4000}] run function bergentruck:tree/32_47
execute as @s[scores={nbs_bergentruc=3840..5360}] run function bergentruck:tree/48_63
