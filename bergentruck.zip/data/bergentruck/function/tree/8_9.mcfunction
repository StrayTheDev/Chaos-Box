execute as @s[scores={nbs_bergentruc=640..880,nbs_bergentruc_t=..7}] run function bergentruck:notes/8
execute as @s[scores={nbs_bergentruc=720..960,nbs_bergentruc_t=..8}] run function bergentruck:notes/9
