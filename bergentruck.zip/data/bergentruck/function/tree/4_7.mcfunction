execute as @s[scores={nbs_bergentruc=320..640}] run function bergentruck:tree/4_5
execute as @s[scores={nbs_bergentruc=480..880}] run function bergentruck:tree/6_7
