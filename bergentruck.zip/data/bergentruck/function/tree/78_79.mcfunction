execute as @s[scores={nbs_bergentruc=6240..6480,nbs_bergentruc_t=..77}] run function bergentruck:notes/78
execute as @s[scores={nbs_bergentruc=6320..6560,nbs_bergentruc_t=..78}] run function bergentruck:notes/79
