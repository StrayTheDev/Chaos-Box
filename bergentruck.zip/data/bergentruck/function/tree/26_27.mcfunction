execute as @s[scores={nbs_bergentruc=2080..2320,nbs_bergentruc_t=..25}] run function bergentruck:notes/26
execute as @s[scores={nbs_bergentruc=2160..2400,nbs_bergentruc_t=..26}] run function bergentruck:notes/27
