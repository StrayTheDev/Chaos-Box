execute as @s[scores={nbs_bergentruc=3840..4640}] run function bergentruck:tree/48_55
execute as @s[scores={nbs_bergentruc=4480..5360}] run function bergentruck:tree/56_63
