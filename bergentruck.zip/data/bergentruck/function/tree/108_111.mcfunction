execute as @s[scores={nbs_bergentruc=8640..8960}] run function bergentruck:tree/108_109
execute as @s[scores={nbs_bergentruc=8800..9200}] run function bergentruck:tree/110_111
