execute as @s[scores={nbs_bergentruc=1280..2080}] run function bergentruck:tree/16_23
execute as @s[scores={nbs_bergentruc=1920..2800}] run function bergentruck:tree/24_31
