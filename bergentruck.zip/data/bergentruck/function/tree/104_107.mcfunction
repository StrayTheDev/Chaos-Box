execute as @s[scores={nbs_bergentruc=8320..8640}] run function bergentruck:tree/104_105
execute as @s[scores={nbs_bergentruc=8480..8880}] run function bergentruck:tree/106_107
