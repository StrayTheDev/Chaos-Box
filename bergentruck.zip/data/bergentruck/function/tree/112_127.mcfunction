execute as @s[scores={nbs_bergentruc=8960..9760}] run function bergentruck:tree/112_119
execute as @s[scores={nbs_bergentruc=9600..10480}] run function bergentruck:tree/120_127
