execute as @s[scores={nbs_bergentruc=7840..8080,nbs_bergentruc_t=..97}] run function bergentruck:notes/98
execute as @s[scores={nbs_bergentruc=7920..8160,nbs_bergentruc_t=..98}] run function bergentruck:notes/99
