execute as @s[scores={nbs_bergentruc=2880..3120,nbs_bergentruc_t=..35}] run function bergentruck:notes/36
execute as @s[scores={nbs_bergentruc=2960..3200,nbs_bergentruc_t=..36}] run function bergentruck:notes/37
