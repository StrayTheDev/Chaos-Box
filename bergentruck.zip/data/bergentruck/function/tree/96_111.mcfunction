execute as @s[scores={nbs_bergentruc=7680..8480}] run function bergentruck:tree/96_103
execute as @s[scores={nbs_bergentruc=8320..9200}] run function bergentruck:tree/104_111
