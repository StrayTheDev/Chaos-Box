execute as @s[scores={nbs_bergentruc=6400..6880}] run function bergentruck:tree/80_83
execute as @s[scores={nbs_bergentruc=6720..7280}] run function bergentruck:tree/84_87
