execute as @s[scores={nbs_bergentruc=10080..10320,nbs_bergentruc_t=..125}] run function bergentruck:notes/126
execute as @s[scores={nbs_bergentruc=10160..10400,nbs_bergentruc_t=..126}] run function bergentruck:notes/127
