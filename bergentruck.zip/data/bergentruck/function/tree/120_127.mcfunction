execute as @s[scores={nbs_bergentruc=9600..10080}] run function bergentruck:tree/120_123
execute as @s[scores={nbs_bergentruc=9920..10480}] run function bergentruck:tree/124_127
