execute as @s[scores={nbs_bergentruc=3840..4160}] run function bergentruck:tree/48_49
execute as @s[scores={nbs_bergentruc=4000..4400}] run function bergentruck:tree/50_51
