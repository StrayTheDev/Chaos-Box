execute as @s[scores={nbs_bergentruc=9280..9600}] run function bergentruck:tree/116_117
execute as @s[scores={nbs_bergentruc=9440..9840}] run function bergentruck:tree/118_119
