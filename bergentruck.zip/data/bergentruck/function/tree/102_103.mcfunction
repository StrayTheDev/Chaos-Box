execute as @s[scores={nbs_bergentruc=8160..8400,nbs_bergentruc_t=..101}] run function bergentruck:notes/102
execute as @s[scores={nbs_bergentruc=8240..8480,nbs_bergentruc_t=..102}] run function bergentruck:notes/103
