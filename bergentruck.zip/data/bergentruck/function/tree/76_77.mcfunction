execute as @s[scores={nbs_bergentruc=6080..6320,nbs_bergentruc_t=..75}] run function bergentruck:notes/76
execute as @s[scores={nbs_bergentruc=6160..6400,nbs_bergentruc_t=..76}] run function bergentruck:notes/77
