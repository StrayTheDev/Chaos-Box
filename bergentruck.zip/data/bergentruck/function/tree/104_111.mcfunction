execute as @s[scores={nbs_bergentruc=8320..8800}] run function bergentruck:tree/104_107
execute as @s[scores={nbs_bergentruc=8640..9200}] run function bergentruck:tree/108_111
