execute as @s[scores={nbs_bergentruc=3200..3440,nbs_bergentruc_t=..39}] run function bergentruck:notes/40
execute as @s[scores={nbs_bergentruc=3280..3520,nbs_bergentruc_t=..40}] run function bergentruck:notes/41
