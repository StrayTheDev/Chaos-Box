execute as @s[scores={nbs_bergentruc=5120..7840}] run function bergentruck:tree/64_95
execute as @s[scores={nbs_bergentruc=7680..10480}] run function bergentruck:tree/96_127
