execute as @s[scores={nbs_bergentruc=6400..6640,nbs_bergentruc_t=..79}] run function bergentruck:notes/80
execute as @s[scores={nbs_bergentruc=6480..6720,nbs_bergentruc_t=..80}] run function bergentruck:notes/81
