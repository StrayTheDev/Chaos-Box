execute as @s[scores={nbs_bergentruc=4480..4800}] run function bergentruck:tree/56_57
execute as @s[scores={nbs_bergentruc=4640..5040}] run function bergentruck:tree/58_59
