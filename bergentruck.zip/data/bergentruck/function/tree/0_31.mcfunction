execute as @s[scores={nbs_bergentruc=0..1440}] run function bergentruck:tree/0_15
execute as @s[scores={nbs_bergentruc=1280..2800}] run function bergentruck:tree/16_31
