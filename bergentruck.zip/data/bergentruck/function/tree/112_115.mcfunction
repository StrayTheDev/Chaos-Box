execute as @s[scores={nbs_bergentruc=8960..9280}] run function bergentruck:tree/112_113
execute as @s[scores={nbs_bergentruc=9120..9520}] run function bergentruck:tree/114_115
