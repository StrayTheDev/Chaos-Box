execute as @s[scores={nbs_bergentruc=0..240,nbs_bergentruc_t=..-1}] run function bergentruck:notes/0
