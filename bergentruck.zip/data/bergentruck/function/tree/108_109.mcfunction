execute as @s[scores={nbs_bergentruc=8640..8880,nbs_bergentruc_t=..107}] run function bergentruck:notes/108
execute as @s[scores={nbs_bergentruc=8720..8960,nbs_bergentruc_t=..108}] run function bergentruck:notes/109
