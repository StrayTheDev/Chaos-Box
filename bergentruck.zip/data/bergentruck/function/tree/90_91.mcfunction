execute as @s[scores={nbs_bergentruc=7200..7440,nbs_bergentruc_t=..89}] run function bergentruck:notes/90
execute as @s[scores={nbs_bergentruc=7280..7520,nbs_bergentruc_t=..90}] run function bergentruck:notes/91
