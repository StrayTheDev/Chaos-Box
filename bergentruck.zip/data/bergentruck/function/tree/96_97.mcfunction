execute as @s[scores={nbs_bergentruc=7680..7920,nbs_bergentruc_t=..95}] run function bergentruck:notes/96
execute as @s[scores={nbs_bergentruc=7760..8000,nbs_bergentruc_t=..96}] run function bergentruck:notes/97
