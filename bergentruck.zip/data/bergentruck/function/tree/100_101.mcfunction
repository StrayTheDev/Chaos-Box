execute as @s[scores={nbs_bergentruc=8000..8240,nbs_bergentruc_t=..99}] run function bergentruck:notes/100
execute as @s[scores={nbs_bergentruc=8080..8320,nbs_bergentruc_t=..100}] run function bergentruck:notes/101
