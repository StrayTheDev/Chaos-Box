execute as @s[scores={nbs_bergentruc=3200..3520}] run function bergentruck:tree/40_41
execute as @s[scores={nbs_bergentruc=3360..3760}] run function bergentruck:tree/42_43
