execute as @s[scores={nbs_bergentruc=3520..3760,nbs_bergentruc_t=..43}] run function bergentruck:notes/44
execute as @s[scores={nbs_bergentruc=3600..3840,nbs_bergentruc_t=..44}] run function bergentruck:notes/45
