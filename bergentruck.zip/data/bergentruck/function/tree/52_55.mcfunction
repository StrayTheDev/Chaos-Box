execute as @s[scores={nbs_bergentruc=4160..4480}] run function bergentruck:tree/52_53
execute as @s[scores={nbs_bergentruc=4320..4720}] run function bergentruck:tree/54_55
