execute as @s[scores={nbs_bergentruc=8320..8560,nbs_bergentruc_t=..103}] run function bergentruck:notes/104
execute as @s[scores={nbs_bergentruc=8400..8640,nbs_bergentruc_t=..104}] run function bergentruck:notes/105
