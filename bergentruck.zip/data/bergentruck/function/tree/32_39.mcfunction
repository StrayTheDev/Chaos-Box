execute as @s[scores={nbs_bergentruc=2560..3040}] run function bergentruck:tree/32_35
execute as @s[scores={nbs_bergentruc=2880..3440}] run function bergentruck:tree/36_39
