execute as @s[scores={nbs_bergentruc=5600..5840,nbs_bergentruc_t=..69}] run function bergentruck:notes/70
