execute as @s[scores={nbs_bergentruc=5760..6080}] run function bergentruck:tree/72_73
execute as @s[scores={nbs_bergentruc=5920..6320}] run function bergentruck:tree/74_75
