execute as @s[scores={nbs_bergentruc=4800..5040,nbs_bergentruc_t=..59}] run function bergentruck:notes/60
execute as @s[scores={nbs_bergentruc=4880..5120,nbs_bergentruc_t=..60}] run function bergentruck:notes/61
