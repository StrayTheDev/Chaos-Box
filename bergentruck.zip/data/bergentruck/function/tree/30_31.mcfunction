execute as @s[scores={nbs_bergentruc=2400..2640,nbs_bergentruc_t=..29}] run function bergentruck:notes/30
execute as @s[scores={nbs_bergentruc=2480..2720,nbs_bergentruc_t=..30}] run function bergentruck:notes/31
