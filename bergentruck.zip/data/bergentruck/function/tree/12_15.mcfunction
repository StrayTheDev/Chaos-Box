execute as @s[scores={nbs_bergentruc=960..1280}] run function bergentruck:tree/12_13
execute as @s[scores={nbs_bergentruc=1120..1520}] run function bergentruck:tree/14_15
