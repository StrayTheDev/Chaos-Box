execute as @s[scores={nbs_bergentruc=1920..2400}] run function bergentruck:tree/24_27
execute as @s[scores={nbs_bergentruc=2240..2800}] run function bergentruck:tree/28_31
