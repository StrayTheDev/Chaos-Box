execute as @s[scores={nbs_bergentruc=0..5280}] run function bergentruck:tree/0_63
execute as @s[scores={nbs_bergentruc=5120..10480}] run function bergentruck:tree/64_127
