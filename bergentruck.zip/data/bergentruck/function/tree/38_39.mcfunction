execute as @s[scores={nbs_bergentruc=3040..3280,nbs_bergentruc_t=..37}] run function bergentruck:notes/38
execute as @s[scores={nbs_bergentruc=3120..3360,nbs_bergentruc_t=..38}] run function bergentruck:notes/39
