execute as @s[scores={nbs_bergentruc=5440..5680,nbs_bergentruc_t=..67}] run function bergentruck:notes/68
execute as @s[scores={nbs_bergentruc=5520..5760,nbs_bergentruc_t=..68}] run function bergentruck:notes/69
