execute as @s[scores={nbs_bergentruc=2560..2880}] run function bergentruck:tree/32_33
execute as @s[scores={nbs_bergentruc=2720..3120}] run function bergentruck:tree/34_35
