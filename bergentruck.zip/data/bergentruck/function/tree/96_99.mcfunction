execute as @s[scores={nbs_bergentruc=7680..8000}] run function bergentruck:tree/96_97
execute as @s[scores={nbs_bergentruc=7840..8240}] run function bergentruck:tree/98_99
