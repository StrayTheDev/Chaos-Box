execute as @s[scores={nbs_bergentruc=320..560,nbs_bergentruc_t=..3}] run function bergentruck:notes/4
