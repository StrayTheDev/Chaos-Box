execute as @s[scores={nbs_bergentruc=4640..4880,nbs_bergentruc_t=..57}] run function bergentruck:notes/58
execute as @s[scores={nbs_bergentruc=4720..4960,nbs_bergentruc_t=..58}] run function bergentruck:notes/59
