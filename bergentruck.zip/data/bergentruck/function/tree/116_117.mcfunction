execute as @s[scores={nbs_bergentruc=9280..9520,nbs_bergentruc_t=..115}] run function bergentruck:notes/116
execute as @s[scores={nbs_bergentruc=9360..9600,nbs_bergentruc_t=..116}] run function bergentruck:notes/117
