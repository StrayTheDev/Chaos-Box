execute as @s[scores={nbs_bergentruc=5120..5600}] run function bergentruck:tree/64_67
execute as @s[scores={nbs_bergentruc=5440..6000}] run function bergentruck:tree/68_71
