execute as @s[scores={nbs_bergentruc=7520..7760,nbs_bergentruc_t=..93}] run function bergentruck:notes/94
execute as @s[scores={nbs_bergentruc=7600..7840,nbs_bergentruc_t=..94}] run function bergentruck:notes/95
