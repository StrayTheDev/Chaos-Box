execute as @s[scores={nbs_bergentruc=1280..1520,nbs_bergentruc_t=..15}] run function bergentruck:notes/16
execute as @s[scores={nbs_bergentruc=1360..1600,nbs_bergentruc_t=..16}] run function bergentruck:notes/17
