execute as @s[scores={nbs_bergentruc=5440..5760}] run function bergentruck:tree/68_69
execute as @s[scores={nbs_bergentruc=5600..6000}] run function bergentruck:tree/70_71
