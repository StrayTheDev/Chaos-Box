execute as @s[scores={nbs_bergentruc=3840..4080,nbs_bergentruc_t=..47}] run function bergentruck:notes/48
execute as @s[scores={nbs_bergentruc=3920..4160,nbs_bergentruc_t=..48}] run function bergentruck:notes/49
