execute as @s[scores={nbs_bergentruc=9760..10000,nbs_bergentruc_t=..121}] run function bergentruck:notes/122
execute as @s[scores={nbs_bergentruc=9840..10080,nbs_bergentruc_t=..122}] run function bergentruck:notes/123
