execute as @s[scores={nbs_bergentruc=6880..7120,nbs_bergentruc_t=..85}] run function bergentruck:notes/86
execute as @s[scores={nbs_bergentruc=6960..7200,nbs_bergentruc_t=..86}] run function bergentruck:notes/87
