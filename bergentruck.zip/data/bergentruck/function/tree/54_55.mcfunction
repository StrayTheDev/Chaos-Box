execute as @s[scores={nbs_bergentruc=4320..4560,nbs_bergentruc_t=..53}] run function bergentruck:notes/54
execute as @s[scores={nbs_bergentruc=4400..4640,nbs_bergentruc_t=..54}] run function bergentruck:notes/55
