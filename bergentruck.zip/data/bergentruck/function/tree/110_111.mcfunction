execute as @s[scores={nbs_bergentruc=8800..9040,nbs_bergentruc_t=..109}] run function bergentruck:notes/110
execute as @s[scores={nbs_bergentruc=8880..9120,nbs_bergentruc_t=..110}] run function bergentruck:notes/111
