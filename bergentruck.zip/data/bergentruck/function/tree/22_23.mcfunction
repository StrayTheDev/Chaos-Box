execute as @s[scores={nbs_bergentruc=1760..2000,nbs_bergentruc_t=..21}] run function bergentruck:notes/22
execute as @s[scores={nbs_bergentruc=1840..2080,nbs_bergentruc_t=..22}] run function bergentruck:notes/23
