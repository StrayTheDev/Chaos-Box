execute as @s[scores={nbs_bergentruc=640..960}] run function bergentruck:tree/8_9
execute as @s[scores={nbs_bergentruc=800..1200}] run function bergentruck:tree/10_11
