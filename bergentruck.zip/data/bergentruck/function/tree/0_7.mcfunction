execute as @s[scores={nbs_bergentruc=0..480}] run function bergentruck:tree/0_3
execute as @s[scores={nbs_bergentruc=320..880}] run function bergentruck:tree/4_7
