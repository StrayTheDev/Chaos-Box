execute as @s[scores={nbs_bergentruc=0..2720}] run function bergentruck:tree/0_31
execute as @s[scores={nbs_bergentruc=2560..5360}] run function bergentruck:tree/32_63
