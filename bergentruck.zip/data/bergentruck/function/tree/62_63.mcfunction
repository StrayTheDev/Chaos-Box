execute as @s[scores={nbs_bergentruc=4960..5200,nbs_bergentruc_t=..61}] run function bergentruck:notes/62
execute as @s[scores={nbs_bergentruc=5040..5280,nbs_bergentruc_t=..62}] run function bergentruck:notes/63
