execute as @s[scores={nbs_bergentruc=8960..9440}] run function bergentruck:tree/112_115
execute as @s[scores={nbs_bergentruc=9280..9840}] run function bergentruck:tree/116_119
