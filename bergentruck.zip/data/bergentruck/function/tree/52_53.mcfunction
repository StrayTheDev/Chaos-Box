execute as @s[scores={nbs_bergentruc=4160..4400,nbs_bergentruc_t=..51}] run function bergentruck:notes/52
execute as @s[scores={nbs_bergentruc=4240..4480,nbs_bergentruc_t=..52}] run function bergentruck:notes/53
