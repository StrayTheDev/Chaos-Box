execute as @s[scores={nbs_bergentruc=0..320}] run function bergentruck:tree/0_1
execute as @s[scores={nbs_bergentruc=160..560}] run function bergentruck:tree/2_3
