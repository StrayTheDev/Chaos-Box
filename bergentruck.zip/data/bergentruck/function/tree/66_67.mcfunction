execute as @s[scores={nbs_bergentruc=5280..5520,nbs_bergentruc_t=..65}] run function bergentruck:notes/66
