execute as @s[scores={nbs_bergentruc=2560..2800,nbs_bergentruc_t=..31}] run function bergentruck:notes/32
execute as @s[scores={nbs_bergentruc=2640..2880,nbs_bergentruc_t=..32}] run function bergentruck:notes/33
