execute as @s[scores={nbs_bergentruc=2240..2560}] run function bergentruck:tree/28_29
execute as @s[scores={nbs_bergentruc=2400..2800}] run function bergentruck:tree/30_31
