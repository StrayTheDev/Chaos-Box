execute as @s[scores={nbs_bergentruc=8960..9200,nbs_bergentruc_t=..111}] run function bergentruck:notes/112
execute as @s[scores={nbs_bergentruc=9040..9280,nbs_bergentruc_t=..112}] run function bergentruck:notes/113
