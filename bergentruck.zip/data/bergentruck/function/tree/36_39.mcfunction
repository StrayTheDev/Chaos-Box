execute as @s[scores={nbs_bergentruc=2880..3200}] run function bergentruck:tree/36_37
execute as @s[scores={nbs_bergentruc=3040..3440}] run function bergentruck:tree/38_39
