execute as @s[scores={nbs_bergentruc=6080..6400}] run function bergentruck:tree/76_77
execute as @s[scores={nbs_bergentruc=6240..6640}] run function bergentruck:tree/78_79
