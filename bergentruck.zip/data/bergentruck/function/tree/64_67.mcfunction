execute as @s[scores={nbs_bergentruc=5120..5440}] run function bergentruck:tree/64_65
execute as @s[scores={nbs_bergentruc=5280..5680}] run function bergentruck:tree/66_67
