execute as @s[scores={nbs_bergentruc=800..1040,nbs_bergentruc_t=..9}] run function bergentruck:notes/10
execute as @s[scores={nbs_bergentruc=880..1120,nbs_bergentruc_t=..10}] run function bergentruck:notes/11
