execute as @s[scores={nbs_bergentruc=4480..4960}] run function bergentruck:tree/56_59
execute as @s[scores={nbs_bergentruc=4800..5360}] run function bergentruck:tree/60_63
