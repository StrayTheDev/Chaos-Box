execute as @s[scores={nbs_bergentruc=2240..2480,nbs_bergentruc_t=..27}] run function bergentruck:notes/28
execute as @s[scores={nbs_bergentruc=2320..2560,nbs_bergentruc_t=..28}] run function bergentruck:notes/29
