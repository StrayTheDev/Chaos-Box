execute as @s[scores={nbs_bergentruc=5920..6160,nbs_bergentruc_t=..73}] run function bergentruck:notes/74
execute as @s[scores={nbs_bergentruc=6000..6240,nbs_bergentruc_t=..74}] run function bergentruck:notes/75
