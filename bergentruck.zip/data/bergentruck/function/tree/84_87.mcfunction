execute as @s[scores={nbs_bergentruc=6720..7040}] run function bergentruck:tree/84_85
execute as @s[scores={nbs_bergentruc=6880..7280}] run function bergentruck:tree/86_87
