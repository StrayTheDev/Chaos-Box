execute as @s[scores={nbs_bergentruc=1120..1360,nbs_bergentruc_t=..13}] run function bergentruck:notes/14
execute as @s[scores={nbs_bergentruc=1200..1440,nbs_bergentruc_t=..14}] run function bergentruck:notes/15
