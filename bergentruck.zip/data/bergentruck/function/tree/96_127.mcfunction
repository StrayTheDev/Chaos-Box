execute as @s[scores={nbs_bergentruc=7680..9120}] run function bergentruck:tree/96_111
execute as @s[scores={nbs_bergentruc=8960..10480}] run function bergentruck:tree/112_127
