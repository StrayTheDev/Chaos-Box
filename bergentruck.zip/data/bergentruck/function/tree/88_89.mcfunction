execute as @s[scores={nbs_bergentruc=7040..7280,nbs_bergentruc_t=..87}] run function bergentruck:notes/88
execute as @s[scores={nbs_bergentruc=7120..7360,nbs_bergentruc_t=..88}] run function bergentruck:notes/89
