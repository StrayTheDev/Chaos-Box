execute as @s[scores={nbs_bergentruc=9600..9840,nbs_bergentruc_t=..119}] run function bergentruck:notes/120
execute as @s[scores={nbs_bergentruc=9680..9920,nbs_bergentruc_t=..120}] run function bergentruck:notes/121
