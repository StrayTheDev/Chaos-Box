execute as @s[scores={nbs_bergentruc=9920..10240}] run function bergentruck:tree/124_125
execute as @s[scores={nbs_bergentruc=10080..10480}] run function bergentruck:tree/126_127
