execute as @s[scores={nbs_bergentruc=5760..6000,nbs_bergentruc_t=..71}] run function bergentruck:notes/72
execute as @s[scores={nbs_bergentruc=5840..6080,nbs_bergentruc_t=..72}] run function bergentruck:notes/73
