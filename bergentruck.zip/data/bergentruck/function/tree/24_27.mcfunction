execute as @s[scores={nbs_bergentruc=1920..2240}] run function bergentruck:tree/24_25
execute as @s[scores={nbs_bergentruc=2080..2480}] run function bergentruck:tree/26_27
