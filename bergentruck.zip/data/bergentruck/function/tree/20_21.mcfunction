execute as @s[scores={nbs_bergentruc=1600..1840,nbs_bergentruc_t=..19}] run function bergentruck:notes/20
execute as @s[scores={nbs_bergentruc=1680..1920,nbs_bergentruc_t=..20}] run function bergentruck:notes/21
