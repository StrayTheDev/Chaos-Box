execute as @s[scores={nbs_bergentruc=8000..8320}] run function bergentruck:tree/100_101
execute as @s[scores={nbs_bergentruc=8160..8560}] run function bergentruck:tree/102_103
