execute as @s[scores={nbs_bergentruc=2560..3360}] run function bergentruck:tree/32_39
execute as @s[scores={nbs_bergentruc=3200..4080}] run function bergentruck:tree/40_47
