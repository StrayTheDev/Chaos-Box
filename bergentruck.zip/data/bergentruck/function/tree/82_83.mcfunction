execute as @s[scores={nbs_bergentruc=6560..6800,nbs_bergentruc_t=..81}] run function bergentruck:notes/82
execute as @s[scores={nbs_bergentruc=6640..6880,nbs_bergentruc_t=..82}] run function bergentruck:notes/83
