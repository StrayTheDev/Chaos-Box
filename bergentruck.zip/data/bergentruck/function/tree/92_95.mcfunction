execute as @s[scores={nbs_bergentruc=7360..7680}] run function bergentruck:tree/92_93
execute as @s[scores={nbs_bergentruc=7520..7920}] run function bergentruck:tree/94_95
