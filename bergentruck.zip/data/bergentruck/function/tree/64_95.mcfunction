execute as @s[scores={nbs_bergentruc=5120..6560}] run function bergentruck:tree/64_79
execute as @s[scores={nbs_bergentruc=6400..7920}] run function bergentruck:tree/80_95
