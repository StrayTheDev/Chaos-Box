execute as @s[scores={nbs_bergentruc=0..800}] run function bergentruck:tree/0_7
execute as @s[scores={nbs_bergentruc=640..1520}] run function bergentruck:tree/8_15
