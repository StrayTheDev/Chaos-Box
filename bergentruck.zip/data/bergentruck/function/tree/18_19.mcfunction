execute as @s[scores={nbs_bergentruc=1440..1680,nbs_bergentruc_t=..17}] run function bergentruck:notes/18
execute as @s[scores={nbs_bergentruc=1520..1760,nbs_bergentruc_t=..18}] run function bergentruck:notes/19
