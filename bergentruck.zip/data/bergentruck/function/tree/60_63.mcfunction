execute as @s[scores={nbs_bergentruc=4800..5120}] run function bergentruck:tree/60_61
execute as @s[scores={nbs_bergentruc=4960..5360}] run function bergentruck:tree/62_63
