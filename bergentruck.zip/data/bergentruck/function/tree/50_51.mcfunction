execute as @s[scores={nbs_bergentruc=4000..4240,nbs_bergentruc_t=..49}] run function bergentruck:notes/50
execute as @s[scores={nbs_bergentruc=4080..4320,nbs_bergentruc_t=..50}] run function bergentruck:notes/51
