execute as @s[scores={nbs_bergentruc=1600..1920}] run function bergentruck:tree/20_21
execute as @s[scores={nbs_bergentruc=1760..2160}] run function bergentruck:tree/22_23
