execute as @s[scores={nbs_bergentruc=5120..5360,nbs_bergentruc_t=..63}] run function bergentruck:notes/64
execute as @s[scores={nbs_bergentruc=5200..5440,nbs_bergentruc_t=..64}] run function bergentruck:notes/65
