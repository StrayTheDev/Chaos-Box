execute as @s[scores={nbs_bergentruc=7040..7520}] run function bergentruck:tree/88_91
execute as @s[scores={nbs_bergentruc=7360..7920}] run function bergentruck:tree/92_95
