execute as @s[scores={nbs_bergentruc=1920..2160,nbs_bergentruc_t=..23}] run function bergentruck:notes/24
execute as @s[scores={nbs_bergentruc=2000..2240,nbs_bergentruc_t=..24}] run function bergentruck:notes/25
