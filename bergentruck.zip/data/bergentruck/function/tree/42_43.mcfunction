execute as @s[scores={nbs_bergentruc=3360..3600,nbs_bergentruc_t=..41}] run function bergentruck:notes/42
execute as @s[scores={nbs_bergentruc=3440..3680,nbs_bergentruc_t=..42}] run function bergentruck:notes/43
