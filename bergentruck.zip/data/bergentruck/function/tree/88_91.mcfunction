execute as @s[scores={nbs_bergentruc=7040..7360}] run function bergentruck:tree/88_89
execute as @s[scores={nbs_bergentruc=7200..7600}] run function bergentruck:tree/90_91
