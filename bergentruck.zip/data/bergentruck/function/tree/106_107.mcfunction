execute as @s[scores={nbs_bergentruc=8480..8720,nbs_bergentruc_t=..105}] run function bergentruck:notes/106
execute as @s[scores={nbs_bergentruc=8560..8800,nbs_bergentruc_t=..106}] run function bergentruck:notes/107
