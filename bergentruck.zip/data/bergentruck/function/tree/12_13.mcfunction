execute as @s[scores={nbs_bergentruc=960..1200,nbs_bergentruc_t=..11}] run function bergentruck:notes/12
execute as @s[scores={nbs_bergentruc=1040..1280,nbs_bergentruc_t=..12}] run function bergentruck:notes/13
