execute as @s[scores={nbs_bergentruc=2720..2960,nbs_bergentruc_t=..33}] run function bergentruck:notes/34
execute as @s[scores={nbs_bergentruc=2800..3040,nbs_bergentruc_t=..34}] run function bergentruck:notes/35
