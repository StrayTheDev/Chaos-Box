execute as @s[scores={nbs_bergentruc=6400..7200}] run function bergentruck:tree/80_87
execute as @s[scores={nbs_bergentruc=7040..7920}] run function bergentruck:tree/88_95
