execute as @s[scores={nbs_bergentruc=9120..9360,nbs_bergentruc_t=..113}] run function bergentruck:notes/114
execute as @s[scores={nbs_bergentruc=9200..9440,nbs_bergentruc_t=..114}] run function bergentruck:notes/115
