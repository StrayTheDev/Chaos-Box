execute as @s[scores={nbs_bergentruc=7680..8160}] run function bergentruck:tree/96_99
execute as @s[scores={nbs_bergentruc=8000..8560}] run function bergentruck:tree/100_103
