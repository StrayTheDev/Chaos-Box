execute as @s[scores={nbs_bergentruc=480..720,nbs_bergentruc_t=..5}] run function bergentruck:notes/6
