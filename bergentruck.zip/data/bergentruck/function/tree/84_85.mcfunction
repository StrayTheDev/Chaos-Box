execute as @s[scores={nbs_bergentruc=6720..6960,nbs_bergentruc_t=..83}] run function bergentruck:notes/84
execute as @s[scores={nbs_bergentruc=6800..7040,nbs_bergentruc_t=..84}] run function bergentruck:notes/85
