execute as @s[scores={nbs_bergentruc=7360..7600,nbs_bergentruc_t=..91}] run function bergentruck:notes/92
execute as @s[scores={nbs_bergentruc=7440..7680,nbs_bergentruc_t=..92}] run function bergentruck:notes/93
