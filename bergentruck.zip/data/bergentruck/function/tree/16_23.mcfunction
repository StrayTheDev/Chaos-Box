execute as @s[scores={nbs_bergentruc=1280..1760}] run function bergentruck:tree/16_19
execute as @s[scores={nbs_bergentruc=1600..2160}] run function bergentruck:tree/20_23
