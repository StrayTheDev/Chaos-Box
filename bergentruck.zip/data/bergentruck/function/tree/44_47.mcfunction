execute as @s[scores={nbs_bergentruc=3520..3840}] run function bergentruck:tree/44_45
execute as @s[scores={nbs_bergentruc=3680..4080}] run function bergentruck:tree/46_47
