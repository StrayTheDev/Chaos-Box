execute as @s[scores={nbs_bergentruc=9920..10160,nbs_bergentruc_t=..123}] run function bergentruck:notes/124
execute as @s[scores={nbs_bergentruc=10000..10240,nbs_bergentruc_t=..124}] run function bergentruck:notes/125
