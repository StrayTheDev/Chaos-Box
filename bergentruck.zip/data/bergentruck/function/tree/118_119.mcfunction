execute as @s[scores={nbs_bergentruc=9440..9680,nbs_bergentruc_t=..117}] run function bergentruck:notes/118
execute as @s[scores={nbs_bergentruc=9520..9760,nbs_bergentruc_t=..118}] run function bergentruck:notes/119
