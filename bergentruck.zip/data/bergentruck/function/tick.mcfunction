execute as @a[tag=nbs_bergentruc] run scoreboard players operation @s nbs_bergentruc += speed nbs_bergentruc
execute as @a[tag=nbs_bergentruc] at @s run function bergentruck:tree/0_127