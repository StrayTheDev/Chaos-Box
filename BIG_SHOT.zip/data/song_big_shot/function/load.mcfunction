scoreboard objectives add nbs_BIGSHOT dummy
scoreboard objectives add nbs_BIGSHOT_t dummy
scoreboard players set speed nbs_BIGSHOT 80