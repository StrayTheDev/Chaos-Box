playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0 0.943874 1
scoreboard players set @s nbs_BIGSHOT_t 1199