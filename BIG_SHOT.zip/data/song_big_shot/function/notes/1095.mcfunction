playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.29 1.781797 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.31 0.629961 1
scoreboard players set @s nbs_BIGSHOT_t 1095