playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.22 0.749154 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.22 0.749154 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.11 0.749154 1
scoreboard players set @s nbs_BIGSHOT_t 108