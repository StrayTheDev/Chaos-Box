playsound minecraft:block.note_block.banjo record @s ^0 ^ ^ 0.50 0.594604 1
scoreboard players set @s nbs_BIGSHOT_t 1400