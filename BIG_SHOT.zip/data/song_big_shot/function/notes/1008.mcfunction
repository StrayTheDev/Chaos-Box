playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 1.122462 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 0.943874 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.561231 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.49 0.561231 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.49 0.561231 1
scoreboard players set @s nbs_BIGSHOT_t 1008