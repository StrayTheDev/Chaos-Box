playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.15 0.629961 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.629961 1
scoreboard players set @s nbs_BIGSHOT_t 1058