playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.29 0.890899 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0 0.943874 1
scoreboard players set @s nbs_BIGSHOT_t 1455