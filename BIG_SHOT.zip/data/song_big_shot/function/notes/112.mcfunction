playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.26 0.561231 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.26 1.122462 1
playsound minecraft:block.note_block.bass record @s ^0 ^ ^ 0.26 0.561231 1
playsound minecraft:block.note_block.bass record @s ^0 ^ ^ 0.26 1.122462 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.17 0.749154 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.17 0.749154 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.08 0.749154 1
scoreboard players set @s nbs_BIGSHOT_t 112