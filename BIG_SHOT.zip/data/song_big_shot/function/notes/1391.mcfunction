playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 1.122462 1
scoreboard players set @s nbs_BIGSHOT_t 1391