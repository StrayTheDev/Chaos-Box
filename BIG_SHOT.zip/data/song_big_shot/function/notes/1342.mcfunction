playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 0.840896 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0 1.122462 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 1.122462 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 0.840896 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 0.840896 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 1.122462 1
scoreboard players set @s nbs_BIGSHOT_t 1342