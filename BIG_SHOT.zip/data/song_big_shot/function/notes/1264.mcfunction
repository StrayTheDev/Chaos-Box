playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 1.059463 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.46 0.629961 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 1.059463 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 1.059463 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 0.667420 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 0.793701 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.890899 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.49 0.890899 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.49 0.890899 1
scoreboard players set @s nbs_BIGSHOT_t 1264