playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.50 0.707107 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.50 0.667420 1
scoreboard players set @s nbs_BIGSHOT_t 1019