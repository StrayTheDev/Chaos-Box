playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.19 0.629961 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.19 0.629961 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.09 0.629961 1
scoreboard players set @s nbs_BIGSHOT_t 14