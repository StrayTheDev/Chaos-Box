playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.594604 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.49 0.594604 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.49 0.594604 1
scoreboard players set @s nbs_BIGSHOT_t 1014