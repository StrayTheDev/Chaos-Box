playsound minecraft:block.note_block.banjo record @s ^0 ^ ^ 0.50 0.749154 1
playsound minecraft:block.note_block.banjo record @s ^0 ^ ^ 0.50 0.943874 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 0.749154 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 0.749154 1
scoreboard players set @s nbs_BIGSHOT_t 1380