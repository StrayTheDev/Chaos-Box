playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.561231 1
scoreboard players set @s nbs_BIGSHOT_t 1010