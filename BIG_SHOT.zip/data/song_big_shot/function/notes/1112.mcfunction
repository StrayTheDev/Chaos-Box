playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 1.122462 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.46 0.749154 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.749154 1
scoreboard players set @s nbs_BIGSHOT_t 1112