playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.31 0.749154 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.629961 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.49 0.629961 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.49 0.629961 1
scoreboard players set @s nbs_BIGSHOT_t 1316