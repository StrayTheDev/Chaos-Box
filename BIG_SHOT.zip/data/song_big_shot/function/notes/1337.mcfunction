playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.46 1.122462 1
scoreboard players set @s nbs_BIGSHOT_t 1337