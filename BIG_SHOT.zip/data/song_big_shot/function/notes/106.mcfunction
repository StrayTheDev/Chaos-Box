playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.26 0.629961 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.26 1.259921 1
playsound minecraft:block.note_block.bass record @s ^0 ^ ^ 0.26 0.629961 1
playsound minecraft:block.note_block.bass record @s ^0 ^ ^ 0.26 1.259921 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.24 0.749154 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.24 0.749154 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.12 0.749154 1
scoreboard players set @s nbs_BIGSHOT_t 106