playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.62 0.749154 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.15 0.749154 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.749154 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.49 0.749154 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.49 0.749154 1
scoreboard players set @s nbs_BIGSHOT_t 1046