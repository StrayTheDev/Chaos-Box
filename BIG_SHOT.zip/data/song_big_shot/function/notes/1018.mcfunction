playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.50 0.793701 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.50 0.749154 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.594604 1
scoreboard players set @s nbs_BIGSHOT_t 1018