playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.50 0.890899 1
playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 0.50 0.840896 1
scoreboard players set @s nbs_BIGSHOT_t 1017