playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.19 0.749154 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.19 0.749154 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.09 0.749154 1
scoreboard players set @s nbs_BIGSHOT_t 110