playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 1.498307 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.46 0.749154 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.840896 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.49 0.840896 1
playsound minecraft:block.note_block.didgeridoo record @s ^0 ^ ^ 0.49 0.840896 1
scoreboard players set @s nbs_BIGSHOT_t 1116