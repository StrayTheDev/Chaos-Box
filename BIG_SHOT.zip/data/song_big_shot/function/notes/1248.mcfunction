playsound minecraft:block.note_block.pling record @s ^0 ^ ^ 1 1.259921 1
playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0.46 0.629961 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 1.259921 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 1.259921 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 0.749154 1
playsound minecraft:block.note_block.guitar record @s ^0 ^ ^ 1 1.781797 1
playsound minecraft:block.note_block.basedrum record @s ^0 ^ ^ 1 0.629961 1
scoreboard players set @s nbs_BIGSHOT_t 1248