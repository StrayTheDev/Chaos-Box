playsound minecraft:block.note_block.bit record @s ^0 ^ ^ 0 0.749154 1
scoreboard players set @s nbs_BIGSHOT_t 1323